from reference.emi03 import ensemble as e
from pathlib import Path
import gzip,json,os,re,resource,shutil,statistics,subprocess,tempfile,time
w=Path('/home/adam/emi03-work');root=Path('/home/adam/code/ohmnivore');out=w/'resident-companion97';out.mkdir(exist_ok=False)
r=Path(os.environ['RUNFILES_DIR']);np=e.metrics.np
manifest=e.study.selected_manifest('emi01-v2');candidate=next(c for c in manifest['candidates'] if c['id']=='reference');corner=next(c for c in manifest['corners'] if c['id']=='nominal');step=manifest['candidate_max_steps_s']['reference'][0]
source=e.circuits.ensemble(candidate,corner,step,'emi01-v2');source,count=re.subn(r'(?im)^(\.tran\s+\S+\s+)\S+',r'\g<1>1.03u',source);assert count==1
flat,imported=e.importer.import_archive(r/'+http_file+emi01_microchip_model/file/model.zip',source)
binaries={'cpu':r/'_main/cpp/emi03_cpu_worker','baseline81':w/'pool-worker-81','companion97':w/'block-97/worker'}
identity={'scope':'Shortened 1.03 us coupled reference/nominal Compensated companion history with correction-first solve screening only; no acceptance timing','acceptance_pass':False,'base_identity':json.loads((w/'pool-dpt-81/identity.json').read_text()),'sources':e.identities(),'binary_sha256':{k:e.study.sha(p.read_bytes()) for k,p in binaries.items()},'source_deck_sha256':e.study.sha(source.encode()),'flat_sha256':e.study.sha(flat.encode())}
e.study.write_json(out/'identity.json',identity)
(out/'candidate.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--','cuda/emi03_resident.cu','cuda/emi03_resident_device.cuh'],cwd=root),mtime=0))
rows=[]
with tempfile.TemporaryDirectory(prefix='companion97-') as temp:
 inp=Path(temp)/'input.cir';inp.write_text(flat)
 for trial,lane,profile in [(-1,'cpu',False),(-1,'baseline81',False),(-1,'companion97',False)]+[(i,lane,False) for i in range(3) for lane in (['baseline81','companion97'] if i%2==0 else ['companion97','baseline81'])]+[(3,lane,True) for lane in ['baseline81','companion97']]:
  directory=out/(lane+'-'+str(trial)+('-profile' if profile else ''));directory.mkdir();raw=directory/'output.raw';stats=directory/'stats.json'
  env=dict(os.environ);env.pop('EMI03_RESIDENT_PROFILE',None)
  if profile:env['EMI03_RESIDENT_PROFILE']='1'
  started=time.perf_counter();p=subprocess.run([str(binaries[lane]),str(inp),str(raw),str(stats)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=120);elapsed=time.perf_counter()-started
  (directory/'execution.log').write_bytes(p.stdout+p.stderr)
  row={'lane':lane,'trial':trial,'profile':profile,'wall_s':elapsed,'exit_code':p.returncode,'raw_sha256':e.study.sha(raw.read_bytes()) if raw.exists() else None};rows.append(row)
  if p.returncode:raise RuntimeError(row)
  table=e.signals.parse_raw(raw.read_bytes(),e.circuits.STUDY_NAMES,1.03*1e-6,step)
  grid=np.linspace(0,1.03*1e-6,2061)
  if lane=='cpu':reference={name:np.interp(grid,table[:,0],table[:,i]) for i,name in enumerate(e.circuits.STUDY_NAMES)}
  else:
   row['waveforms']={name:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[name],name.startswith('v('),400) for i,name in enumerate(e.circuits.STUDY_NAMES) if name!='time'}
   assert all(c['pass'] for c in row['waveforms'].values())
   gpu=json.loads(Path(str(stats)+'.gpu.json').read_text());e.validate_gpu_telemetry(gpu,str(inp))
  row['points']=len(table);row['pass']=True
  print(json.dumps({k:v for k,v in row.items() if k!='waveforms'}),flush=True)
  e.study.write_json(out/'records.json',rows)
median={lane:statistics.median(r['wall_s'] for r in rows if r['lane']==lane and r['trial']>=0 and not r['profile']) for lane in ['baseline81','companion97']}
summary={'scope':identity['scope'],'acceptance_pass':False,'waveforms_pass':all(r['pass'] for r in rows),'median_request_wall_s':median,'ratio_companion_over_baseline':median['companion97']/median['baseline81']};e.study.write_json(out/'summary.json',summary);print(json.dumps(summary),flush=True)
