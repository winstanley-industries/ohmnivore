from reference.emi03 import ensemble as e
from pathlib import Path
import json,os,re,subprocess,tempfile,time
w=Path('/home/adam/emi03-work');out=w/'resident-coupled20us97';out.mkdir(exist_ok=False);r=Path(os.environ['RUNFILES_DIR']);np=e.metrics.np
manifest=e.study.selected_manifest('emi01-v2');candidate=next(c for c in manifest['candidates'] if c['id']=='reference');corner=next(c for c in manifest['corners'] if c['id']=='nominal');step=manifest['candidate_max_steps_s']['reference'][0]
source=e.circuits.ensemble(candidate,corner,step,'emi01-v2');source,count=re.subn(r'(?im)^(\.tran\s+\S+\s+)\S+',r'\g<1>20u',source);assert count==1
flat,imported=e.importer.import_archive(r/'+http_file+emi01_microchip_model/file/model.zip',source)
binaries={'cpu':r/'_main/cpp/emi03_cpu_worker','baseline81':w/'pool-worker-81','delta96':w/'block-96/worker','companion97':w/'block-97/worker'}
identity={'scope':'Twenty-microsecond coupled reference/nominal diagnostic; no full-window spectra or acceptance timing','acceptance_pass':False,'baseline_identity':json.loads((w/'pool-dpt-81/identity.json').read_text()),'variants':{v:json.loads((w/('block-'+v)/'identity.json').read_text()) for v in ['96','97']},'binary_sha256':{k:e.study.sha(p.read_bytes()) for k,p in binaries.items()},'source_deck_sha256':e.study.sha(source.encode()),'flat_sha256':e.study.sha(flat.encode()),'cpu':e.cpu_identity(),'accelerator':e.accelerator_identity()};e.study.write_json(out/'identity.json',identity)
rows=[]
with tempfile.TemporaryDirectory(prefix='coupled20us97-') as temp:
 inp=Path(temp)/'input.cir';inp.write_text(flat)
 for lane,binary in binaries.items():
  folder=out/lane;folder.mkdir();raw=folder/'output.raw';stats=folder/'stats.json';env=dict(os.environ);env['EMI03_RESIDENT_PROFILE']='1'
  started=time.perf_counter();p=subprocess.run([str(binary),str(inp),str(raw),str(stats)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=120);elapsed=time.perf_counter()-started
  (folder/'execution.log').write_bytes(p.stdout+p.stderr);row={'lane':lane,'wall_s':elapsed,'exit_code':p.returncode};rows.append(row)
  if p.returncode:raise RuntimeError(row)
  row['raw_sha256']=e.study.sha(raw.read_bytes());table=e.signals.parse_raw(raw.read_bytes(),e.circuits.STUDY_NAMES,20*1e-6,step);grid=np.linspace(0,20*1e-6,40001)
  if lane=='cpu':reference={name:np.interp(grid,table[:,0],table[:,i]) for i,name in enumerate(e.circuits.STUDY_NAMES)}
  else:
   row['waveforms']={name:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[name],name.startswith('v('),400) for i,name in enumerate(e.circuits.STUDY_NAMES) if name!='time'};assert all(c['pass'] for c in row['waveforms'].values())
   gpu=json.loads(Path(str(stats)+'.gpu.json').read_text());e.validate_gpu_telemetry(gpu,str(inp))
  row['points']=len(table);row['pass']=True;e.study.write_json(out/'records.json',rows);print(json.dumps({k:v for k,v in row.items() if k!='waveforms'}),flush=True)
summary={'scope':identity['scope'],'acceptance_pass':False,'waveforms_pass':all(r['pass'] for r in rows),'results':rows};e.study.write_json(out/'summary.json',summary);print('Complete, all short-window waveform checks passed; EMI-03 acceptance remains false.',flush=True)
