from pathlib import Path
import gzip,hashlib,json,shutil
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-correction-equations';out.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
for name in ['resident-delta94','resident-delta95','resident-delta96','resident-companion97','pool-dpt-96','resident-coupled20us96','resident-coupled20us97']:
 source=w/name;target=out/name;target.mkdir();raws={}
 for p in source.rglob('*'):
  if not p.is_file():continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw' or p.name in ['source.csv','metrics.csv']:
   b=p.read_bytes();q=Path(str(q)+'.gz');q.write_bytes(gzip.compress(b,mtime=0))
   if p.suffix=='.raw':raws[str(q.relative_to(target))]={'raw_bytes':len(b),'raw_sha256':sha(b)}
  else:shutil.copy2(p,q)
 if raws:(target/'raw-files.json').write_text(json.dumps(raws,indent=2)+'\n')
 log=w/(name+'.log')
 if log.exists():shutil.copy2(log,target/'run.log')
for v in range(94,98):
 source=w/('block-'+str(v));target=out/('variant-'+str(v));target.mkdir()
 for name in ['identity.json','source.patch','tests.log']:
  if (source/name).exists():shutil.copy2(source/name,target/name)
 (target/'scope.json').write_text(json.dumps({'acceptance_pass':False,'scope':{94:'Correction-equation solve, rejected by unchanged certification',95:'Failure-location instrumentation of trial 94; no test or accepted timing claim',96:'Correction equation with original-equation GPU retry',97:'Trial 96 plus compensated companion history'}[v]},indent=2)+'\n')
for name in ['delta94.py','run_delta94.py','delta96.py','run_delta96.py','companion97.py','run_companion97.py','pool_dpt96.py','run_pool_dpt96.py','coupled20us96.py','run_coupled20us96.py','coupled20us97.py','run_coupled20us97.py','freeze_factor_variant.py','retain_corrections97.py']:
 if (w/name).exists():(out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
for name in ['resident-delta94-build.log','resident-delta95-build.log','resident-delta96-build.log','resident-companion97-build.log']:
 if (w/name).exists():shutil.copy2(w/name,out/name)
shutil.copy2(w/'hardware-profile-70/input.cir',out/'input.cir')
print(out)
