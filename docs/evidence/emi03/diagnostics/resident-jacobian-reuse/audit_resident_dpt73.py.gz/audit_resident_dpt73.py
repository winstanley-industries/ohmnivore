from pathlib import Path
import gzip,hashlib,io,json,os,subprocess,tarfile,tempfile
root=Path('/home/adam/code/ohmnivore');work=Path('/home/adam/emi03-work');out=root/'docs/evidence/emi03/diagnostics/resident-jacobian-reuse/dpt-refinements'
identity=json.loads((out/'identity.json').read_text());patch=gzip.decompress((out/'source.patch.gz').read_bytes())
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(patch)==identity['source_patch_sha256']
r=(root/'bazel-out/k8-opt/bin/reference/emi03/ensemble.runfiles').resolve()
with tempfile.TemporaryDirectory(prefix='resident-dpt73-audit-',dir=work/'tmp') as temporary:
 mirror=Path(temporary);scratch=mirror/'_main';scratch.mkdir()
 for entry in r.iterdir():
  if entry.name!='_main':(mirror/entry.name).symlink_to(entry)
 archive=subprocess.check_output(['git','archive',identity['base_commit'],'cpp','cuda','.bazelrc','MODULE.bazel','MODULE.bazel.lock','reference','third_party/emi_python'],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(archive)) as source:source.extractall(scratch,filter='data')
 subprocess.run(['git','apply','--'],input=patch,cwd=scratch,check=True)
 (scratch/'third_party/emi_python/libz.so.1').symlink_to(r/'_main/third_party/emi_python/libz.so.1')
 for p,expected in {**identity['source_files'],**identity['comparison_sources']}.items():assert sha((scratch/p).read_bytes())==expected,p
 assert sha((work/'resident-v73-source/emi03_resident_worker').read_bytes())==identity['gpu_binary_sha256']
 assert sha((r/'_main/cpp/emi03_cpu_worker').read_bytes())==identity['cpu_binary_sha256']
 for p,expected in json.loads((out/'raw-index.json').read_text()).items():
  encoded=(out/p).read_bytes();raw=gzip.decompress(encoded)
  assert sha(encoded)==expected['gzip_sha256'] and len(encoded)==expected['gzip_bytes']
  assert sha(raw)==expected['raw_sha256'] and len(raw)==expected['raw_bytes']
 script=scratch/'verify.py';script.write_text('''from pathlib import Path
import gzip,json,sys
from reference.emi01 import circuits,metrics,signals,study
from reference.emi03 import ensemble
out=Path(sys.argv[1]);manifest=json.loads(Path('reference/emi01/manifest-v2.json').read_text());stored=json.loads((out/'summary.json').read_text());rows={};tables={};comparisons=[];refinements=[]
for level in range(3):
 for lane in ['cpu','gpu']:
  path=out/f'q{level}-{lane}';row=json.loads((path/'record.json').read_text());rows[level,lane]=row
  assert row['status']=='qualified' and row['returncode']==0 and row['wall_s']<=120 and row['child_cpu_s']<=110
  table=signals.parse_raw(gzip.decompress((path/'output.raw.gz').read_bytes()),circuits.DPT_NAMES,16e-6,manifest['dpt_max_steps_s'][level]);tables[level,lane]=table
  assert table[-1,0]==16e-6 and len(table)==row['points'] and len(table)<=2_000_000
  assert len(table)==json.loads((path/'stats.json').read_text())['points']
  assert metrics.dpt(table,manifest['dpt_sample_steps_s'][level])==row['metrics']
  if lane=='gpu':
   native=json.loads((path/'stats.json.gpu.json').read_text())
   assert all(native[key]==0 for key in ['gpu_fallbacks','outstanding_device_bytes','cleanup_failures','allocation_failures'])
   assert native['peak_device_bytes']<=native['maximum_device_bytes']
 comparisons.append(ensemble.compare_pair(tables[level,'gpu'],rows[level,'gpu'],tables[level,'cpu'],rows[level,'cpu']))
for lane in ['cpu','gpu']:
 for level in [1,2]:refinements.append(study.dpt_compare(rows[level-1,lane]['metrics'],rows[level,lane]['metrics'],f'{lane}-q{level-1}-q{level}'))
 for dt in manifest['dpt_sample_steps_s'][:2]:refinements.append(study.dpt_compare(metrics.dpt(tables[2,lane],dt),rows[2,lane]['metrics'],f'{lane}-output-{dt}'))
assert comparisons==stored['comparisons'] and refinements==stored['refinements']
assert stored['dpt_differential_pass'] and stored['dpt_refinement_pass'] and stored['acceptance_pass'] is False
assert len(comparisons)==3 and len(refinements)==8 and all(x['pass'] for x in comparisons+refinements)
print(json.dumps({'raw_points':{f'q{k[0]}-{k[1]}':len(v) for k,v in tables.items()},'comparisons':len(comparisons),'refinements':len(refinements)}))
''')
 env=dict(os.environ,RUNFILES_DIR=str(mirror),PYTHONPATH=':'.join([str(scratch),str(r/'rules_python+'),str(next(r.glob('rules_python++pip+*'))/'site-packages')]))
 python=next(r.glob('rules_python++python+*/bin/python3'))
 result=json.loads(subprocess.check_output([str(python),str(script),str(out)],cwd=scratch,env=env))
result.update({'audit_pass':True,'acceptance_pass':False,'source_reconstruction_pass':True,'source_files':len(identity['source_files']),'comparison_sources':len(identity['comparison_sources']),'binary_identity_pass':True,'raw_reconstruction_pass':True,'all_dpt_comparisons_reproduced':True,'scope':'DPT-only checkpoint; no coupled qualification, aggregate resource or throughput acceptance.'})
(out/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
