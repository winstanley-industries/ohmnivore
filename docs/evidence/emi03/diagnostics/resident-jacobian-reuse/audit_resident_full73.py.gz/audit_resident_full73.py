from pathlib import Path
import gzip,hashlib,io,json,mmap,os,re,struct,subprocess,tarfile,tempfile
root=Path('/home/adam/code/ohmnivore')
out=root/'docs/evidence/emi03/diagnostics/resident-jacobian-reuse/full-reference'
identity=json.loads((out/'identity.json').read_text())
patch=gzip.decompress((out/'source.patch.gz').read_bytes())
assert hashlib.sha256(patch).hexdigest()==identity['source_patch_sha256']
runfiles=(root/'bazel-bin/reference/emi03/ensemble.runfiles').resolve()
with tempfile.TemporaryDirectory(prefix='resident-full-audit-',dir='/home/adam/emi03-work/tmp') as temporary:
    mirror=Path(temporary)
    scratch=mirror/'_main';scratch.mkdir()
    for entry in runfiles.iterdir():
        if entry.name!='_main':(mirror/entry.name).symlink_to(entry)
    archive=subprocess.check_output(['git','archive',identity['base_commit'],'cpp','cuda','.bazelrc','MODULE.bazel','MODULE.bazel.lock','reference','third_party/emi_python'],cwd=root)
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:
        source.extractall(scratch,filter='data')
    subprocess.run(['git','apply','--'],input=patch,cwd=scratch,check=True)
    (scratch/'third_party/emi_python/libz.so.1').symlink_to(runfiles/'_main/third_party/emi_python/libz.so.1')
    for name,expected in {**identity['source_files'],**identity['comparison_sources']}.items():
        assert hashlib.sha256((scratch/name).read_bytes()).hexdigest()==expected,name
    binary=Path('/home/adam/emi03-work/resident-v73-source/emi03_resident_worker')
    assert hashlib.sha256(binary.read_bytes()).hexdigest()==identity['gpu_binary_sha256']
    assert hashlib.sha256((runfiles/'_main/cpp/emi03_cpu_worker').read_bytes()).hexdigest()==identity['cpu_binary_sha256']
    for name,expected in json.loads((out/'raw-index.json').read_text()).items():
        encoded=(out/name).read_bytes();raw=gzip.decompress(encoded)
        assert len(encoded)==expected['gzip_bytes'] and hashlib.sha256(encoded).hexdigest()==expected['gzip_sha256']
        assert len(raw)==expected['raw_bytes'] and hashlib.sha256(raw).hexdigest()==expected['raw_sha256']
    for name,expected in json.loads((out/'scripts.json').read_text()).items():
        raw=gzip.decompress((out/(name+'.gz')).read_bytes())
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
    verifier=scratch/'verify.py'
    verifier.write_text('''from pathlib import Path
import gzip,json,sys
from reference.emi01 import circuits,metrics,signals
out=Path(sys.argv[1]);summary=json.loads((out/'summary.json').read_text())
tables={};physical={};counts={}
for lane in ['cpu','gpu']:
 table=signals.parse_raw(gzip.decompress((out/(lane+'.raw.gz')).read_bytes()),circuits.STUDY_NAMES,200*1e-6,625e-12)
 assert table[-1,0]==200*1e-6
 assert table.shape[0]==json.loads((out/(lane+'.json')).read_text())['points']
 tables[lane]=table;counts[lane]=int(table.shape[0])
 value,spectrum=metrics.evaluate(table,summary['candidate'],summary['corner'],5e-9)
 physical[lane]=value
 assert spectrum.astype('<f8').tobytes()==(out/(lane+'.spectra.f64')).read_bytes()
comparison=metrics.compare(tables['gpu'],tables['cpu'],circuits.STUDY_NAMES,5e-9,summary['corner']['bus_v'])
comparison['physical_classification_agrees']=physical['cpu']['status']==physical['gpu']['status']
comparison['pass']=bool(comparison['pass'] and comparison['physical_classification_agrees'])
stored=json.loads((out/'comparison.json').read_text())
assert comparison==stored['physical_comparison'] and physical==stored['metrics']
assert comparison['pass'] and stored['acceptance_pass'] is False
print(json.dumps(counts))
''')
    python=next(runfiles.glob('rules_python++python+*/bin/python3'))
    env=dict(os.environ,RUNFILES_DIR=str(mirror),PYTHONPATH=':'.join([str(scratch),str(runfiles/'rules_python+'),str(next(runfiles.glob('rules_python++pip+*'))/'site-packages')]))
    counts=json.loads(subprocess.check_output([str(python),str(verifier),str(out)],env=env))
summary=json.loads((out/'summary.json').read_text());gpu=summary['results']['gpu'];cpu=summary['results']['cpu']
assert gpu['program_completed'] and gpu['returncode']==0 and gpu['status']=='resource_limit'
assert gpu['wall_s']>120 and not gpu['frozen_wall_gate_pass'] and gpu['frozen_cpu_gate_pass']
assert cpu['status']=='complete' and cpu['frozen_wall_gate_pass'] and summary['acceptance_pass'] is False
native=json.loads((out/'gpu.json.gpu.json').read_text())
for name in ['gpu_fallbacks','outstanding_device_bytes','cleanup_failures','allocation_failures']:assert native[name]==0,name
assert native['peak_device_bytes']<=native['maximum_device_bytes']
record={'audit_pass':True,'acceptance_pass':False,'source_reconstruction_pass':True,'source_files':len(identity['source_files']),'comparison_sources':len(identity['comparison_sources']),'binary_identity_pass':True,'raw_reconstruction_pass':True,'physical_comparison_reproduced':True,'all_spectral_arrays_reproduced':True,'raw_point_counts':counts,'frozen_wall_gate_failure_confirmed':True,'scope':'One extended q0 reference/nominal diagnostic. No aggregate resource, full qualification, refinement or throughput pass.'}
(out/'audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
