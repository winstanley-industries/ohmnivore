import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/adam/code/ohmnivore')
out = Path('/home/adam/emi03-work/resident-validation-v73')
out.mkdir(exist_ok=True)
os.environ['TMPDIR'] = '/home/adam/emi03-work/tmp'
checks = [
    ('lint', ['bazel', 'lint'], 0),
    ('build', ['bazel', 'build', '//...'], 0),
    ('tests', ['bazel', 'test', '//...'], 0),
    ('asan', ['bazel', 'test', '--config=asan', '//...'], 0),
    ('ubsan', ['bazel', 'test', '--config=ubsan', '//...'], 0),
    ('lockfile', ['bazel', 'test', '--lockfile_mode=error', '//...'], 0),
    ('acceptance', ['bazel', 'test', '//acceptance:ngspice_acceptance_test', '//cpp:gpu01_prepared_ac_test', '//cpp:gpu01_replay_test'], 0),
    ('ac-replay', ['bazel', 'run', '-c', 'opt', '//cpp:prepared_ac_replay_benchmark', '--', '--warmups=2', '--repetitions=9'], 0),
    ('cuda', ['bazel', 'test', '-c', 'opt', '--config=cuda', '--jobs=1', '//:cuda_smoke_test', '--local_test_jobs=1', '//cuda:emi03_cuda_test', '//cuda:emi03_resident_test', '//cuda:emi03_reduction_test', '//cuda:emi03_linkage_test', '//cuda:emi03_resident_linkage_test'], 0),
    ('cuda-asan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=asan', '//cuda:smoke_test'], 1),
    ('cuda-ubsan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=ubsan', '//cuda:smoke_test'], 1),
    ('emi03-asan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=asan', '//cuda:emi03_gpu_worker'], 1),
    ('emi03-ubsan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=ubsan', '//cuda:emi03_gpu_worker'], 1),
    ('resident-asan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=asan', '//cuda:emi03_resident_worker'], 1),
    ('resident-ubsan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=ubsan', '//cuda:emi03_resident_worker'], 1),
    ('reduction-asan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=asan', '//cuda:emi03_reduction_test'], 1),
    ('reduction-ubsan-incompatible', ['bazel', 'build', '--config=cuda', '--jobs=1', '--config=ubsan', '//cuda:emi03_reduction_test'], 1),
    ('opt-gpu', ['bazel', 'build', '-c', 'opt', '--config=cuda', '--jobs=1', '//cuda:emi03_gpu_worker', '//cuda:emi03_resident_worker'], 0),
]
results = []
for name, command, expected in checks:
    started = time.time()
    print('START ' + name, flush=True)
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    passed = result.returncode == expected
    if expected:
        passed = passed and 'incompatible' in (out / (name + '.log')).read_text()
    record = dict(name=name, command=command, exit_code=result.returncode,
                  expected_exit_code=expected, pass_=passed,
                  elapsed_s=time.time()-started)
    results.append(record)
    (out / 'checks.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if not passed:
        raise SystemExit(1)
