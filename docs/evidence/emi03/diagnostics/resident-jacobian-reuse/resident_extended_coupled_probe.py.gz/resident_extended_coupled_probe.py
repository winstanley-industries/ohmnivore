from pathlib import Path
import hashlib,json,os,re,resource,shutil,struct,subprocess,sys,tempfile,time
from reference.emi02 import importer
from reference.emi01 import circuits,metrics,signals

out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
r=Path(os.environ['EMI03_RUNFILES'])
archive=r/'+http_file+emi01_microchip_model/file/model.zip'
manifest=json.loads(Path('/home/adam/code/ohmnivore/reference/emi01/manifest-v2.json').read_text())
candidate=next(c for c in manifest['candidates'] if c['id']=='reference')
corner=next(c for c in manifest['corners'] if c['id']=='nominal')
maximum=manifest['candidate_max_steps_s']['reference'][0]
source=circuits.ensemble(candidate,corner,maximum,'emi01-v2')
flat,identity=importer.import_archive(archive,source)
results={};progress=[]

def inspect_partial(path):
    if not path.exists():return {}
    with path.open('rb') as stream:
        header=stream.read(8192)
        marker=header.find(b'Binary:\n')
        if marker<0:return {}
        start=marker+len(b'Binary:\n')
        variables=int(re.search(rb'No\. Variables: (\d+)',header[:start])[1])
        size=path.stat().st_size
        points=(size-start)//(variables*8)
        if points<1:return {}
        stream.seek(start+(points-1)*variables*8)
        last=struct.unpack('<d',stream.read(8))[0]
    return {'observed_complete_records':points,'last_observed_time_s':last,'file_bytes':size}

with tempfile.TemporaryDirectory(prefix='emi03-extended-') as temp:
    directory=Path(temp);deck=directory/'input.cir';deck.write_text(flat)
    for lane,binary in [('cpu',r/'_main/cpp/emi03_cpu_worker'),('gpu',Path('/home/adam/emi03-work/bin/emi03_resident_worker'))]:
        raw=directory/(lane+'.raw');stats=directory/(lane+'.json')
        def budget():
            resource.setrlimit(resource.RLIMIT_CPU,(110,110))
            if lane=='cpu':resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
        before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter()
        process=subprocess.Popen([str(binary),str(deck),str(raw),str(stats)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=budget)
        timeout=600 if lane=='gpu' else 120
        killed=False
        while True:
            try:
                stdout,stderr=process.communicate(timeout=min(15,max(.001,timeout-(time.perf_counter()-start))))
                break
            except subprocess.TimeoutExpired:
                elapsed=time.perf_counter()-start
                row={'lane':lane,'elapsed_s':elapsed,**inspect_partial(Path(str(raw)+'.partial'))}
                progress.append(row)
                (out/'progress.json').write_text(json.dumps(progress,indent=2)+'\n')
                print(json.dumps(row),flush=True)
                if elapsed>=timeout:
                    process.kill();stdout,stderr=process.communicate();killed=True;break
        elapsed=time.perf_counter()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
        within=elapsed<=120 and cpu<=110
        row={'wall_s':elapsed,'child_cpu_s':cpu,'returncode':process.returncode,'diagnostic_timeout':killed,'program_completed':process.returncode==0,'frozen_job_wall_limit_s':120,'frozen_wall_gate_pass':elapsed<=120,'frozen_cpu_gate_pass':cpu<=110,'status':'complete' if process.returncode==0 and within else 'resource_limit' if not within or killed else 'failed','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
        for path in [raw,stats,Path(str(stats)+'.gpu.json')]:
            if path.exists():shutil.copy2(path,out/path.name)
        (out/(lane+'.stdout')).write_bytes(stdout);(out/(lane+'.stderr')).write_bytes(stderr)
        results[lane]=row
        print(json.dumps({'lane':lane,**row}),flush=True)
    summary={'scope':'Extended development diagnostic only. Any execution beyond 120 seconds FAILS the frozen wall gate even if the program later completes. No qualification or throughput admission.','diagnostic_gpu_wall_limit_s':600,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'import_identity':identity,'candidate':candidate,'corner':corner,'results':results,'acceptance_pass':False}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
if all(row['program_completed'] for row in results.values()):
    tables={};physical={}
    for lane in results:
        table=signals.parse_raw((out/(lane+'.raw')).read_bytes(),circuits.STUDY_NAMES,200*1e-6,maximum)
        tables[lane]=table
        value,spectrum=metrics.evaluate(table,candidate,corner,5e-9)
        physical[lane]=value
        spectrum.astype('<f8').tofile(out/(lane+'.spectra.f64'))
    comparison=metrics.compare(tables['gpu'],tables['cpu'],circuits.STUDY_NAMES,5e-9,corner['bus_v'])
    comparison['physical_classification_agrees']=physical['cpu']['status']==physical['gpu']['status']
    comparison['pass']=bool(comparison['pass'] and comparison['physical_classification_agrees'])
    (out/'comparison.json').write_text(json.dumps({'scope':'Numerical diagnostic only; job resource status is retained separately and no over-budget result is admitted.','physical_comparison':comparison,'metrics':physical,'acceptance_pass':False},indent=2)+'\n')
    print(json.dumps({'physical_comparison_pass':comparison['pass'],'acceptance_pass':False}),flush=True)
