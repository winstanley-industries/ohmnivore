from pathlib import Path
import subprocess,os,shutil,hashlib,json
root=Path('/home/adam/code/ohmnivore');r=root/'bazel-out/k8-opt/bin/reference/emi03/ensemble.runfiles';r=r.resolve()
env=dict(os.environ,EMI03_RUNFILES=str(r),RUNFILES_DIR=str(r),TMPDIR='/home/adam/emi03-work/tmp',EMI03_RESIDENT_PROFILE='1',PYTHONPATH=':'.join([str(r/'_main'),str(r/'rules_python+'),str(next(r.glob('rules_python++pip+*'))/'site-packages')]))
python=next(r.glob('rules_python++python+*/bin/python3'))
binary=Path('/home/adam/emi03-work/bin/emi03_resident_worker');binary.chmod(0o755);shutil.copy2(root/'bazel-bin/cuda/emi03_resident_worker',binary)
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='99494c3fdd98454755cc68807ffb733b9ecaf35518589a21710f34a5b8b40a9c'
snapshot=Path('/home/adam/emi03-work/resident-chord-68')
(snapshot/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','c6eb2ef','--','cuda'],cwd=root))
(snapshot/'identity.json').write_text(json.dumps({'base':'c6eb2ef','worker_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_patch_sha256':hashlib.sha256((snapshot/'source.patch').read_bytes()).hexdigest(),'scope':'development diagnostic, not qualification or acceptance'},indent=2)+'\n')
out=Path('/home/adam/emi03-work/resident-full-reference-68')
with out.with_suffix('.log').open('w') as log:
 p=subprocess.run([str(python),'/home/adam/emi03-work/resident_extended_coupled_probe.py',str(out)],env=env,stdout=log,stderr=subprocess.STDOUT)
print(out.with_suffix('.log').read_text());raise SystemExit(p.returncode)
