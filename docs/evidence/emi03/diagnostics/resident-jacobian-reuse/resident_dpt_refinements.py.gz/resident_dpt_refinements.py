from pathlib import Path
import hashlib,json,os,resource,subprocess,sys,tempfile,time
from reference.emi01 import circuits,metrics,signals,study
from reference.emi02 import importer
from reference.emi03 import ensemble
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
r=Path(os.environ['RUNFILES_DIR']);manifest=json.loads((r/'_main/reference/emi01/manifest-v2.json').read_text())
archive=r/'+http_file+emi01_microchip_model/file/model.zip'
binaries={'cpu':r/'_main/cpp/emi03_cpu_worker','gpu':Path('/home/adam/emi03-work/bin/emi03_resident_worker')}
records={};tables={};comparisons=[]
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def limits(lane):
 def apply():
  resource.setrlimit(resource.RLIMIT_CPU,(110,111))
  resource.setrlimit(resource.RLIMIT_FSIZE,(512*1024**2,512*1024**2))
  if lane=='cpu':resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
 return apply
for level,(step,sample) in enumerate(zip(manifest['dpt_max_steps_s'],manifest['dpt_sample_steps_s'])):
 source=circuits.dpt(step,'emi01-v2');flat,identity=importer.import_archive(archive,source)
 with tempfile.TemporaryDirectory(prefix='resident-dpt-refine-') as temporary:
  deck=Path(temporary)/'input.cir';deck.write_text(flat)
  for lane,binary in binaries.items():
   target=out/f'q{level}-{lane}';target.mkdir();raw=target/'output.raw';stats=target/'stats.json'
   before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter()
   with (target/'stdout').open('wb') as stdout,(target/'stderr').open('wb') as stderr:
    try:code=subprocess.run([str(binary),str(deck),str(raw),str(stats)],stdout=stdout,stderr=stderr,timeout=120,preexec_fn=limits(lane)).returncode
    except subprocess.TimeoutExpired:code=124
   wall=time.perf_counter()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
   row={'fixture':'dpt','id':f'q{level}-{lane}','sample_step_s':sample,'max_step_s':step,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'model':identity,'wall_s':wall,'child_cpu_s':cpu,'returncode':code,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'status':'resource_limit' if code==124 or wall>120 or cpu>110 else 'typed_failure'}
   if code==0 and wall<=120 and cpu<=110:
    table=signals.parse_raw(raw.read_bytes(),circuits.DPT_NAMES,16e-6,step)
    assert len(table)<=2_000_000 and table[-1,0]==16e-6
    measured=metrics.dpt(table,sample);row['metrics']=measured
    row['status']='qualified' if measured['pass'] else 'accuracy_failure'
    row['points']=int(len(table));tables[level,lane]=table
    if lane=='gpu':
     native=json.loads(Path(str(stats)+'.gpu.json').read_text())
     assert native['peak_device_bytes']<=native['maximum_device_bytes']
     assert all(native[k]==0 for k in ['gpu_fallbacks','outstanding_device_bytes','cleanup_failures','allocation_failures'])
   save(target/'record.json',row);records[level,lane]=row
   print(json.dumps({'level':level,'lane':lane,'status':row['status'],'wall_s':wall,'child_cpu_s':cpu,'points':row.get('points')}),flush=True)
 if all(records[level,l]['status']=='qualified' for l in binaries):
  comparisons.append(ensemble.compare_pair(tables[level,'gpu'],records[level,'gpu'],tables[level,'cpu'],records[level,'cpu']))
refinements=[]
for lane in binaries:
 if all(records[level,lane]['status']=='qualified' for level in range(3)):
  for level in [1,2]:refinements.append(study.dpt_compare(records[level-1,lane]['metrics'],records[level,lane]['metrics'],f'{lane}-q{level-1}-q{level}'))
  for dt in manifest['dpt_sample_steps_s'][:2]:refinements.append(study.dpt_compare(metrics.dpt(tables[2,lane],dt),records[2,lane]['metrics'],f'{lane}-output-{dt}'))
summary={'scope':'Fresh CPU and GPU DPT refinements only. No ngspice rerun, coupled qualification, aggregate resource gate or throughput acceptance.','acceptance_pass':False,'dpt_differential_pass':len(comparisons)==3 and all(x['pass'] for x in comparisons),'dpt_refinement_pass':len(refinements)==8 and all(x['pass'] for x in refinements),'comparisons':comparisons,'refinements':refinements,'records':list(records.values())}
save(out/'summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['comparisons','refinements','records']}),flush=True)
