from pathlib import Path
import gzip,hashlib,json,shutil
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-kernel-screening';out.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
for variant in ['serial82','outline83']:
 source=w/('resident-'+variant);target=out/variant;target.mkdir();raws={}
 for p in source.rglob('*'):
  if not p.is_file():continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw':
   b=p.read_bytes();q=q.with_suffix('.raw.gz');q.write_bytes(gzip.compress(b,mtime=0));raws[str(q.relative_to(target))]={'raw_bytes':len(b),'raw_sha256':sha(b)}
  else:shutil.copy2(p,q)
 (target/'raw-files.json').write_text(json.dumps(raws,indent=2)+'\n')
 shutil.copy2(w/('resident-'+variant+'-build.log'),target/'build.log')
 shutil.copy2(w/('resident-'+variant+'.log'),target/'run.log')
for name in ['sparse_solve82.py','run_sparse_solve82.py','outline83.py','run_outline83.py','retain_screening83.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
print(out)
