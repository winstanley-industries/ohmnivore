from pathlib import Path
import hashlib,json,re
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');old=r/'docs/evidence/emi03/diagnostics/resident-shared-addresses/prefix-corpus100';new=w/'prefix-phases106'
read=lambda p:json.loads(p.read_text())
oidentity=read(old/'identity.json');nidentity=read(new/'identity.json')
assert oidentity['binary_sha256']==nidentity['binary_sha256']
assert [s['source_sha256'] for s in read(old/'specs.json')]==[s['source_sha256'] for s in read(new/'specs.json')]
summary=read(new/'summary.json');assert all(lane['pass'] for lane in summary['lanes'].values())
ogpu=[x for x in read(old/'gpu-records.json') if x['batch']==0];ngpu=[x for x in read(new/'gpu-records.json') if x['batch']==0]
critical=max(ogpu,key=lambda x:x['process']['wall_s']);ncritical=max(ngpu,key=lambda x:x['end_offset_s']);assert critical['id']==ncritical['id']=='light-hot_high_c'
ordered=sorted(ngpu,key=lambda x:x['end_offset_s']);gap=ordered[-1]['end_offset_s']-ordered[-2]['end_offset_s'];assert gap>1
lines=(new/'gpu-workers/pool.log').read_text().splitlines();assert len(lines)==108
prefixes=['resident resources ','resident plans=','resident breakdown ','resident chord ','resident expression cache ','resident n=']
for i,line in enumerate(lines):assert line.startswith(prefixes[i%6]),(i,line)
block=lines[-6:]
values={k:int(v) for line in block for k,v in re.findall(r'([a-z_]+)=(\d+)',line)}
total=values['total'];phases={'Triangular solves, including refinement':values['triangular'],'Factorization and factor reuse checks':values['factor'],'Behavioral expressions and derivatives':values['expression'],'Linear residual and backward-error checks':values['residual']}
phases['Remaining assembly, Newton and timestep work']=total-sum(phases.values());assert all(x>0 for x in phases.values())
original_summary=read(old/'summary.json');batch=original_summary['lanes']['gpu']['batches'][1]['request_batch_wall_s'];wait=critical['gpu']['synchronization_ns']/1e9
stats=read(old/critical['directory']/'stats.json');nstats=read(new/ncritical['directory']/'stats.json');cpu=next(x for x in read(old/'cpu-records.json') if x['id']==critical['id']);cstats=read(old/cpu['directory']/'stats.json')
assert values['iterations']==nstats['transient_solver_statistics']['numeric_reuses']
result={'scope':'Read-only explanation of original 46.313-second diagnostic using exact saved timers and a fresh same-binary, same-input phase-counter replay; not frozen acceptance','acceptance_pass':False,'original_batch_s':batch,'critical_case':critical['id'],'original_critical_request_s':critical['process']['wall_s'],'original_completion_wait_s':wait,'original_other_worker_s':stats['elapsed_seconds']-wait,'original_protocol_other_s':critical['process']['wall_s']-stats['elapsed_seconds'],'original_batch_minus_critical_request_s':batch-critical['process']['wall_s'],'original_work_counts':stats,'original_cpu_work_counts':cstats,'same_cpu_gpu_binaries':True,'same_input_hashes':True,'replay_gpu_batch_s':summary['lanes']['gpu']['batches'][1]['request_batch_wall_s'],'replay_cpu_batch_s':summary['lanes']['cpu']['batches'][0]['request_batch_wall_s'],'replay_critical_record':ncritical,'replay_last_completion_gap_s':gap,'replay_phase_log':block,'replay_total_cycles':total,'replay_phases':{name:{'cycles':count,'percent_device_cycles':100*count/total,'illustrative_seconds_if_scaled_to_original_wait':wait*count/total} for name,count in phases.items()},'limits':['Completion wait includes queued GPU execution, copies, and host polling; it is not pure synchronization overhead.','Resident phase counters were not printed in the original run. Replay cycle shares are new diagnostic measurements, not exact original wall-time attribution.','Illustrative seconds merely scale device-cycle shares to original completion wait; they are not directly measured phase seconds.','The remaining device category is subtraction, not a separate detailed instrumentation region.','New replay uses a fresh CPU batch and 18 GPU outputs; all waveform and resource checks pass, but no full spectra or frozen acceptance claim.']}
(w/'prefix-breakdown106.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for g in ogpu:
 c=next(x for x in read(old/'cpu-records.json') if x['id']==g['id'])
 rows.append(f"| {g['id']} | {g['process']['wall_s']:.3f} | {c['process']['wall_s']:.3f} |")
md=f'''# Breakdown of the nine-job GPU diagnostic

The original batch took **{batch:.6f} s**, bounded by `{critical['id']}` at
**{critical['process']['wall_s']:.6f} s**. Jobs ran concurrently; their request times must not be added.

| Job | GPU request seconds | CPU request seconds |
| --- | ---: | ---: |
'''+ '\n'.join(rows)+f'''

The critical job records **{wait:.6f} s** in GPU completion waits, **{result['original_other_worker_s']:.6f} s**
in other worker activity, and **{result['original_protocol_other_s']:.6f} s** in the request wrapper/protocol remainder.
The batch exceeds the critical request duration by **{result['original_batch_minus_critical_request_s']:.6f} s**.
These are nested timer differences. Completion waits include resident GPU execution,
copy completion, queueing and event polling; they are not synchronization overhead alone.
Initialization, parsing and raw-file output are within request time; pool construction,
deck generation, waveform comparison and spectral processing are outside this diagnostic timer.

## Fresh phase replay

The exact original CPU/GPU binaries and all nine exact flattened input hashes match.
One GPU warmup and one measured batch were run with the existing device phase counters
printed at job completion. The new measured batch took **{result['replay_gpu_batch_s']:.6f} s**.
All nine fresh CPU trajectories, eighteen GPU waveform comparisons and resource checks pass.
The slowest job remains `{critical['id']}` and finishes **{gap:.3f} s** after the next job.
Its final contiguous six-line profile group is therefore isolated; its chord-iteration
count matches that job's native numerical-reuse telemetry.

| Resident GPU phase | Device-cycle share |
| --- | ---: |
'''+ '\n'.join(f'| {name} | {100*count/total:.2f}% |' for name,count in phases.items())+f'''

These are new device-cycle shares, not directly measured phase seconds from the original
46.3-second run. The remaining category is subtraction and includes nonlinear assembly,
Newton control/norms, companion/history/error-estimation work, output/state staging and
unclassified barriers. Value evaluation and AD are included together in expressions;
refinement solves are included in triangular solves, avoiding double counting.

For the original critical job, GPU made {stats['attempts']:,} timestep attempts versus
{cstats['attempts']:,} on CPU. It made {stats['transient_solver_statistics']['solves']:,}
primary linear solves and {stats['transient_solver_statistics']['iterative_refinement_solves']:,}
refinement solves. Comparable CPU counts are {cstats['transient_solver_statistics']['solves']:,}
and {cstats['transient_solver_statistics']['iterative_refinement_solves']:,}.
The dominant discrepancy is execution cost per attempt, rather than a large increase
in attempted steps.

The separately retained Nsight Compute report for selected variant 100 profiles one
reference/nominal resident chunk, not this entire batch. It reports one 256-thread
block on an 84-SM GPU, zero spills, 95.08% no-eligible issue opportunities and substantial
barrier waiting. These are supporting mechanism diagnostics, not wall-time percentages
for this nine-job run. Current execution has at most nine circuit blocks in this batch;
its triangular solve executes in one warp per circuit block.

Sources: original `{old}`, replay `{new}`, and
`{r}/docs/evidence/emi03/diagnostics/resident-shared-addresses/resident-full-counters100/metrics.txt`.
Exact derived values and caveats are in `{w}/prefix-breakdown106.json`.
'''
(w/'prefix-breakdown106.md').write_text(md)
print(json.dumps({k:result[k] for k in ['original_batch_s','original_completion_wait_s','replay_gpu_batch_s','replay_last_completion_gap_s','replay_phases']},indent=2))
