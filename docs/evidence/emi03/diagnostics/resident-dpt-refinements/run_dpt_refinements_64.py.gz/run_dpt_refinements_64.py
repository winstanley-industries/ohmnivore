from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path('/home/adam/code/ohmnivore');work=Path('/home/adam/emi03-work');r=(root/'bazel-bin/reference/emi03/ensemble.runfiles').resolve()
old=json.loads((root/'docs/evidence/emi03/diagnostics/resident-expression-cache/identity.json').read_text())
snapshot=work/'resident-v64-source';snapshot.mkdir(exist_ok=True)
identity={**old,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'v64 current diagnostic candidate before three-level DPT testing'}
for p in old['source_files']:
 target=snapshot/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/p,target);identity['source_files'][p]=hashlib.sha256(target.read_bytes()).hexdigest()
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','cpp','cuda','reference','.bazelrc','MODULE.bazel','MODULE.bazel.lock'],cwd=root)
(snapshot/'source.patch').write_bytes(patch);identity['source_patch_sha256']=hashlib.sha256(patch).hexdigest()
shutil.copy2(work/'bin/emi03_resident_worker',snapshot/'emi03_resident_worker')
identity['gpu_binary_sha256']=hashlib.sha256((snapshot/'emi03_resident_worker').read_bytes()).hexdigest();identity['cpu_binary_sha256']=hashlib.sha256((r/'_main/cpp/emi03_cpu_worker').read_bytes()).hexdigest()
(snapshot/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
env=dict(os.environ,RUNFILES_DIR=str(r),TMPDIR=str(work/'tmp'),PYTHONPATH=':'.join([str(r/'_main'),str(r/'rules_python+'),str(next(r.glob('rules_python++pip+*'))/'site-packages')]))
python=next(r.glob('rules_python++python+*/bin/python3'))
with (work/'resident-dpt-refinements-64.log').open('w') as log:
 code=subprocess.run([str(python),str(work/'resident_dpt_refinements.py'),str(work/'resident-dpt-refinements-64')],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
raise SystemExit(code)
