from reference.emi03 import ensemble as e
from pathlib import Path
import json,os,statistics,subprocess,sys,threading,time
w=Path('/home/adam/emi03-work');r=Path(os.environ['RUNFILES_DIR']);name,count,connections,measured=sys.argv[1:];count=int(count);connections=int(connections);measured=int(measured);out=w/name;out.mkdir(exist_ok=False);np=e.metrics.np
assert count in [1,4,16] and connections in [8,32]
source=(w/'hardware-profile-70/input.cir').read_bytes();(out/'input.cir').write_bytes(source);worker=w/'pool-worker-81';cpu=r/'_main/cpp/emi03_cpu_worker';env=e.worker_environment();env.update(CUDA_DEVICE_MAX_CONNECTIONS=str(connections),CUDA_DEVICE_MAX_COPY_CONNECTIONS=str(connections));e.worker_environment=lambda:dict(env)
identity={'scope':'Shortened 1.03 us actual owner-pool queue diagnostic; execution-only batch intervals, no complete-study acceptance','acceptance_pass':False,'count':count,'connections':connections,'measured':measured,'worker_environment':env,'baseline_worker_identity':json.loads((w/'pool-dpt-81/identity.json').read_text()),'worker_sha256':e.study.sha(worker.read_bytes()),'cpu_sha256':e.study.sha(cpu.read_bytes()),'input_sha256':e.study.sha(source),'cpu':e.cpu_identity(),'accelerator':e.accelerator_identity()};assert identity['worker_sha256']==identity['baseline_worker_identity']['binaries']['gpu'];e.study.write_json(out/'identity.json',identity)
p=subprocess.run([str(cpu),str(out/'input.cir'),str(out/'cpu.raw'),str(out/'cpu-stats.json')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);(out/'cpu.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
ct=e.signals.parse_raw((out/'cpu.raw').read_bytes(),e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);grid=np.linspace(0,1.03*1e-6,2061);reference={n:np.interp(grid,ct[:,0],ct[:,i]) for i,n in enumerate(e.circuits.STUDY_NAMES)}
limits=e.study.selected_manifest('emi01-v2')['limits'];pool=e.PersistentPool(worker,out/'workers',limits,True,count);records=[];batches=[]
try:
 for batch in range(-1,measured):
  paths=[]
  for index in range(count):
   d=out/f'batch-{batch}'/f'job-{index}';d.mkdir(parents=True);(d/'input.cir').write_bytes(source);paths.append(d)
  barrier=threading.Barrier(count)
  def execute(index):
   d=paths[index];owner=pool.workers[index];barrier.wait();row={'batch':batch,'owner':index,'directory':str(d.relative_to(out))}
   try:row['process']=owner.request(d/'input.cir',d/'output.raw',d/'stats.json',pool.exhausted);row['status']='complete'
   except Exception as exc:row.update(process=owner.last_process,status='failed',error=str(exc))
   return row
  start=time.perf_counter();futures=[pool.executor.submit(execute,i) for i in range(count)];rows=[f.result() for f in futures];elapsed=time.perf_counter()-start
  for row in rows:
   d=out/row['directory']
   if row['status']=='complete':
    data=(d/'output.raw').read_bytes();table=e.signals.parse_raw(data,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);row['raw_sha256']=e.study.sha(data);row['points']=len(table)
    row['waveforms']={n:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[n],n.startswith('v('),400) for i,n in enumerate(e.circuits.STUDY_NAMES) if n!='time'}
    row['gpu']=json.loads((d/'stats.json.gpu.json').read_text());e.validate_gpu_telemetry(row['gpu'],str(d/'input.cir'))
    with pool.device_lock:
     key=e.worker_key(pool.workers[row['owner']]);pool.device_peaks[key]=max(pool.device_peaks.get(key,0),row['gpu']['peak_device_bytes'])
    row['pass']=all(c['pass'] for c in row['waveforms'].values())
   else:row['pass']=False
   records.append(row)
  b={'batch':batch,'execution_wall_s':elapsed,'pass':all(x['pass'] for x in rows),'request_wall_s':[x['process']['wall_s'] for x in rows]};batches.append(b);e.study.write_json(out/'records.json',records);e.study.write_json(out/'batches.json',batches);print(json.dumps({'count':count,'connections':connections,**b}),flush=True)
  assert b['pass']
finally:
 workers=pool.close();resources=e.pool_resources(pool);e.study.write_json(out/'workers.json',workers);e.study.write_json(out/'resources.json',resources)
assert e.audit_resources(resources,records,workers,True);e.audit_worker_affinity(workers,True,count)
summary={'acceptance_pass':False,'diagnostic_pass':all(x['pass'] for x in records),'count':count,'connections':connections,'jobs':len(records),'median_execution_wall_s':statistics.median(x['execution_wall_s'] for x in batches if x['batch']>=0),'scope':identity['scope']};e.study.write_json(out/'summary.json',summary);print(json.dumps(summary),flush=True)
