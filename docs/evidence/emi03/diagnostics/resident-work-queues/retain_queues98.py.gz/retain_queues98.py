from pathlib import Path
import gzip,hashlib,json,shutil
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-work-queues';out.mkdir(exist_ok=False)
for name in ['queue98-16-8','queue98-16-32','queue98-16-8-repeat','queue98-16-32-repeat','queue98b-profile-8-data','queue98b-profile-32-data']:
 source=w/name;target=out/name;target.mkdir()
 for p in source.rglob('*'):
  if not p.is_file():continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw':q.with_suffix('.raw.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copy2(p,q)
for name in ['queue98.py','run_queue98.py','retain_queues98.py']:(out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
for name in ['queue98-hardware-summary.json','queue98-16-8.log','queue98-16-32.log','queue98-16-8-repeat.log','queue98-16-32-repeat.log']:
 shutil.copy2(w/name,out/name)
for n in [8,32]:
 for stem in ['queue98-profile-','queue98b-profile-']:
  for suffix in ['.log','.json','.nsys-rep','-export.log']:
   p=w/(stem+str(n)+suffix)
   if p.exists():shutil.copy2(p,out/p.name)
 # SQLite is derivable from the retained native report; retain an export command.
(out/'sqlite-export.txt').write_text('nsys export --type sqlite --output queue98b-profile-8.sqlite queue98b-profile-8.nsys-rep\nnsys export --type sqlite --output queue98b-profile-32.sqlite queue98b-profile-32.nsys-rep\n')
print(out)
