from reference.emi03 import ensemble as e
from pathlib import Path
import gzip, io, json, math, sqlite3, statistics, tarfile

r = Path('/home/adam/code/ohmnivore')
w = Path('/home/adam/emi03-work')
out = r / 'docs/evidence/emi03/diagnostics/resident-work-queues'
base = r / 'docs/evidence/emi03/diagnostics/resident-owner-pool'
np = e.metrics.np
names = ['queue98-16-8', 'queue98-16-32', 'queue98-16-8-repeat',
         'queue98-16-32-repeat', 'queue98b-profile-8-data', 'queue98b-profile-32-data']
with tarfile.open(base / 'sources.tar.gz', 'r:gz') as archive:
    sources = {p.name: archive.extractfile(p).read() for p in archive if p.isfile()}
checks = []
for name in names:
    folder = out / name
    identity = json.loads((folder / 'identity.json').read_text())
    for path, digest in identity['baseline_worker_identity']['sources'].items():
        assert e.study.sha(sources[path]) == digest, path
    assert identity['worker_sha256'] == identity['baseline_worker_identity']['binaries']['gpu']
    assert identity['cpu_sha256'] == identity['baseline_worker_identity']['binaries']['cpu']
    assert not identity['acceptance_pass'] and identity['count'] == 16
    source = (folder / 'input.cir').read_bytes()
    assert e.study.sha(source) == identity['input_sha256']
    for variable in ['CUDA_DEVICE_MAX_CONNECTIONS', 'CUDA_DEVICE_MAX_COPY_CONNECTIONS']:
        assert identity['worker_environment'][variable] == str(identity['connections'])
    raw = gzip.decompress((folder / 'cpu.raw.gz').read_bytes())
    table = e.signals.parse_raw(raw, e.circuits.STUDY_NAMES, 1.03 * 1e-6, 625e-12)
    grid = np.linspace(0, 1.03 * 1e-6, 2061)
    reference = {n: np.interp(grid, table[:, 0], table[:, i])
                 for i, n in enumerate(e.circuits.STUDY_NAMES)}
    cpu_digest = e.study.sha(raw)
    records = json.loads((folder / 'records.json').read_text())
    batches = json.loads((folder / 'batches.json').read_text())
    assert len(records) == 16 * (identity['measured'] + 1)
    assert {(row['batch'], row['owner']) for row in records} == {
        (batch, owner) for batch in range(-1, identity['measured']) for owner in range(16)}
    for row in records:
        assert row['status'] == 'complete' and row['pass']
        path = folder / row['directory']
        assert (path / 'input.cir').read_bytes() == source
        raw = gzip.decompress((path / 'output.raw.gz').read_bytes())
        assert e.study.sha(raw) == row['raw_sha256']
        table = e.signals.parse_raw(raw, e.circuits.STUDY_NAMES, 1.03 * 1e-6, 625e-12)
        assert len(table) == row['points']
        compared = {n: e.metrics._waveform_check(np.interp(grid, table[:, 0], table[:, i]),
                    reference[n], n.startswith('v('), 400)
                    for i, n in enumerate(e.circuits.STUDY_NAMES) if n != 'time'}
        assert compared == row['waveforms'] and all(c['pass'] for c in compared.values())
        gpu = json.loads((path / 'stats.json.gpu.json').read_text())
        assert gpu == row['gpu']
        e.validate_gpu_telemetry(gpu, row['process']['input'])
    resources = json.loads((folder / 'resources.json').read_text())
    workers = json.loads((folder / 'workers.json').read_text())
    assert e.audit_resources(resources, records, workers, True)
    e.audit_worker_affinity(workers, True, 16)
    assert len(batches) == identity['measured'] + 1 and all(b['pass'] for b in batches)
    for batch in batches:
        assert batch['request_wall_s'] == [row['process']['wall_s'] for row in records
                                        if row['batch'] == batch['batch']]
    summary = json.loads((folder / 'summary.json').read_text())
    assert summary['diagnostic_pass'] and not summary['acceptance_pass']
    assert summary['jobs'] == len(records)
    assert summary['median_execution_wall_s'] == statistics.median(
        b['execution_wall_s'] for b in batches if b['batch'] >= 0)
    checks.append({'name': name, 'gpu_jobs': len(records), 'cpu_raw_sha256': cpu_digest,
                   'median_execution_wall_s': summary['median_execution_wall_s'],
                   'resources_pass': True})

# SQLite exports are derived from the retained native reports, using sqlite-export.txt.
hardware = json.loads((out / 'queue98-hardware-summary.json').read_text())
for connections in [8, 32]:
    connection = sqlite3.connect(w / f'queue98b-profile-{connections}.sqlite')
    metadata = json.loads((out / f'queue98b-profile-{connections}.json').read_text())
    assert metadata['exit_code'] == 0 and not metadata['acceptance_pass']
    for name, expected in hardware[str(connections)]['metrics'].items():
        values = [x[0] for x in connection.execute('''
            SELECT g.value FROM GPU_METRICS g JOIN TARGET_INFO_GPU_METRICS t
            ON g.typeId=t.typeId AND g.metricId=t.metricId WHERE t.metricName=?
        ''', (name,))]
        values.sort()
        actual = {'samples': len(values), 'mean': sum(values) / len(values),
                  'median': statistics.median(values),
                  'p95': values[math.ceil(len(values) * .95) - 1], 'max': max(values)}
        assert actual == expected, (name, actual, expected)
    assert connection.execute('SELECT count(*) FROM DIAGNOSTIC_EVENT WHERE severity>1').fetchone()[0] == 0
    connection.close()
    failure_log = (out / f'queue98-profile-{connections}.log').read_text()
    assert 'libgcc_s.so.1' in failure_log and 'Traceback' in failure_log
e.study.write_json(out / 'audit.json', {
    'pass': True, 'acceptance_pass': False, 'raw_trajectories': 326,
    'gpu_waveform_checks': 320, 'baseline_source_files': len(sources),
    'hardware_reports_reconstructed': 2, 'failed_profiler_attempts_retained': 2,
    'checks': checks,
    'scope': 'Shortened diagnostic trajectories, source identities, owner/resource audits and whole-capture metrics only'})
print('326 trajectories, 320 GPU waveform comparisons, six pool audits and two hardware reports reconstructed.')
