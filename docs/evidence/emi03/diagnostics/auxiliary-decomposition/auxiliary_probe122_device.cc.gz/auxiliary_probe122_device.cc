struct Recipe { int source, begin, count; };
struct Term { int coefficient, operand; };
#define INTEGER_FIELDS(X) \
  X(full_rows) X(full_columns) X(aux) X(branches) X(retained) \
  X(response_offsets) X(response_columns) X(core_rows) X(core_columns) \
  X(aux_order) X(aux_bounds) X(response_order) X(response_bounds) X(gmin_slots)
#define RECIPE_FIELDS(X) X(response_recipes) X(offset_recipes) X(core_recipes) X(rhs_recipes)
#define TERM_FIELDS(X) X(response_terms) X(offset_terms) X(core_terms) X(rhs_terms)
struct HostPlan {
#define DECLARE(name) std::vector<int> name;
  INTEGER_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) std::vector<Recipe> name;
  RECIPE_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) std::vector<Term> name;
  TERM_FIELDS(DECLARE)
#undef DECLARE
};
struct DevicePlan {
  int n, auxiliaries, core, core_nnz, response_values, levels;
#define DECLARE(name) const int *name;
  INTEGER_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) const Recipe *name;
  RECIPE_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) const Term *name;
  TERM_FIELDS(DECLARE)
#undef DECLARE
};
struct OriginalWork {
  double *values, *rhs, *solution, *response, *reduced;
  int error;
};
DevicePlan UploadPlan(const HostPlan &h, Allocations &allocation) {
  DevicePlan p{};
  p.n=h.full_rows.size()-1;p.auxiliaries=h.aux.size();p.core=h.retained.size();
  p.core_nnz=h.core_columns.size();p.response_values=h.response_columns.size();p.levels=h.aux_bounds.size()-1;
#define UPLOAD(name) p.name=allocation.Upload(h.name);
  INTEGER_FIELDS(UPLOAD)
  RECIPE_FIELDS(UPLOAD)
  TERM_FIELDS(UPLOAD)
#undef UPLOAD
  return p;
}
__device__ double Coefficient(const double *a,int slot) {return slot<0 ? 0 : a[slot];}
__device__ void AuxiliaryResponse(DevicePlan p,const double *a,double *response,Shared &s) {
  for(int level=0;level<p.levels;++level) {
    for(int at=p.response_bounds[level]+threadIdx.x;at<p.response_bounds[level+1];at+=Threads) {
      const int index=p.response_order[at];const auto recipe=p.response_recipes[index];
      double value=-Coefficient(a,recipe.source);
      for(int j=recipe.begin;j<recipe.begin+recipe.count;++j) {
        const auto term=p.response_terms[j];value=fma(-a[term.coefficient],response[term.operand],value);
      }
      response[index]=value;if(!Bounded(value))Reject(s,Nonfinite);
    }
    __syncthreads();
  }
}
__device__ void AuxiliaryMatrix(DevicePlan p,const double *a,const double *response,double *reduced,Shared &s) {
  for(int i=threadIdx.x;i<p.core_nnz;i+=Threads) {
    const auto recipe=p.core_recipes[i];double value=Coefficient(a,recipe.source);
    for(int j=recipe.begin;j<recipe.begin+recipe.count;++j) {
      const auto term=p.core_terms[j];value=fma(a[term.coefficient],response[term.operand],value);
    }
    reduced[i]=value;if(!Bounded(value))Reject(s,Nonfinite);
  }
  __syncthreads();
}
__global__ void PrepareAuxiliaryMatrix(DevicePlan p,OriginalWork *work) {
  __shared__ Shared s;
  if(threadIdx.x==0)s.error=0;
  __syncthreads();
  auto &o=*work;
  AuxiliaryResponse(p,o.values,o.response,s);
  AuxiliaryMatrix(p,o.values,o.response,o.reduced,s);
  if(threadIdx.x==0)o.error=s.error;
}
__device__ void AuxiliaryRhs(DevicePlan p,const double *a,const double *rhs,double *offset,double *core_rhs,Shared &s) {
  for(int level=0;level<p.levels;++level) {
    for(int at=p.aux_bounds[level]+threadIdx.x;at<p.aux_bounds[level+1];at+=Threads) {
      const int index=p.aux_order[at];const auto recipe=p.offset_recipes[index];double value=rhs[recipe.source];
      for(int j=recipe.begin;j<recipe.begin+recipe.count;++j) {
        const auto term=p.offset_terms[j];value=fma(-a[term.coefficient],offset[term.operand],value);
      }
      offset[index]=value;if(!Bounded(value))Reject(s,Nonfinite);
    }
    __syncthreads();
  }
  for(int row=threadIdx.x;row<p.core;row+=Threads) {
    const auto recipe=p.rhs_recipes[row];double value=rhs[recipe.source];
    for(int j=recipe.begin;j<recipe.begin+recipe.count;++j) {
      const auto term=p.rhs_terms[j];value=fma(-a[term.coefficient],offset[term.operand],value);
    }
    core_rhs[row]=value;if(!Bounded(value))Reject(s,Nonfinite);
  }
  __syncthreads();
}
__device__ void AuxiliaryRecover(DevicePlan p,const double *a,const double *rhs,const double *response,const double *offset,const double *core,double *full,Shared &s) {
  for(int row=threadIdx.x;row<p.core;row+=Threads)full[p.retained[row]]=core[row];
  for(int row=threadIdx.x;row<p.auxiliaries;row+=Threads) {
    double value=offset[row];
    for(int j=p.response_offsets[row];j<p.response_offsets[row+1];++j)value=fma(response[j],core[p.response_columns[j]],value);
    full[p.aux[row]]=value;
    full[p.branches[row]]=fma(-a[p.gmin_slots[row]],value,rhs[p.aux[row]]);
    if(!Bounded(value)||!Bounded(full[p.branches[row]]))Reject(s,Nonfinite);
  }
  __syncthreads();
}
__device__ bool OriginalResidual(DevicePlan p,const double *a,const double *b,const double *x,double *residual,Shared &s,bool corrected) {
  double component=0,normalized=0,matrix_norm=0,rhs_norm=0,solution_norm=0,nonzero=0;
  for(int row=threadIdx.x;row<p.n;row+=Threads) {
    Sum sum;sum.Add(b[row]);double denominator=fabs(b[row]),scale=0,row_norm=0;
    for(int j=p.full_rows[row];j<p.full_rows[row+1];++j) {
      const double coefficient=a[j],value=x[p.full_columns[j]];
      sum.Product(-coefficient,value);denominator+=fabs(coefficient*value);scale=PositiveMaximum(scale,fabs(coefficient));row_norm+=fabs(coefficient);
    }
    const double r=sum.Value();residual[row]=r;
    if(!Bounded(r)||!(scale>0)||!Bounded(x[row]))Reject(s,Nonfinite);
    if(r!=0)nonzero=1;
    component=PositiveMaximum(component,denominator==0 ? (r==0 ? 0 : 1e100) : fabs(r)/denominator);
    normalized=PositiveMaximum(normalized,fabs(r)/scale);matrix_norm=PositiveMaximum(matrix_norm,row_norm/scale);rhs_norm=PositiveMaximum(rhs_norm,fabs(b[row])/scale);solution_norm=PositiveMaximum(solution_norm,fabs(x[row]));
  }
  double maxima[]{component,normalized,matrix_norm,rhs_norm,solution_norm,nonzero};ValidationMaxima(maxima,s);
  const double denominator=maxima[2]*maxima[4]+maxima[3];
  return (corrected||maxima[5]==0)&&maxima[0]<=1e-5&&(denominator==0 ? maxima[1]==0 : maxima[1]/denominator<=1e-10);
}
__global__ void AuxiliaryMatrixReplay(DevicePlan p,const Model *models,Workspace *all,OriginalWork *originals,int iterations) {
  const Model m=models[blockIdx.x];Workspace *workspace=all+blockIdx.x;auto &o=originals[blockIdx.x];
  // INITIALIZATION_FROM_SELECTED_KERNEL
  double *response=reinterpret_cast<double *>((reinterpret_cast<std::uintptr_t>(s.matrix_columns+m.nnz)+7)&~std::uintptr_t{7});
  double *offset=response+p.response_values,*full=offset+p.auxiliaries,*delta=full+p.n,*residual=delta+p.n;
  for(int iteration=0;iteration<iterations&&!s.error;++iteration) {
    AuxiliaryResponse(p,o.values,response,s);AuxiliaryMatrix(p,o.values,response,w.jacobian,s);
    if(threadIdx.x==0)s.factor_valid=false;
    __syncthreads();Factor(m,w,s);
    if(s.error)break;
    AuxiliaryRhs(p,o.values,o.rhs,offset,w.affine_rhs,s);
    if(s.error)break;
    Triangular(m,w,s,w.affine_rhs,w.solution);
    if(s.error)break;
    AuxiliaryRecover(p,o.values,o.rhs,response,offset,w.solution,full,s);
    bool accepted=false;
    for(int refinement=0;refinement<=4&&!s.error;++refinement) {
      accepted=OriginalResidual(p,o.values,o.rhs,full,residual,s,refinement>0);
      if(accepted||refinement==4)break;
      AuxiliaryRhs(p,o.values,residual,offset,w.affine_rhs,s);
      if(s.error)break;
      Triangular(m,w,s,w.affine_rhs,w.solution);
      if(s.error)break;
      AuxiliaryRecover(p,o.values,residual,response,offset,w.solution,delta,s);
      for(int i=threadIdx.x;i<p.n;i+=Threads)full[i]+=delta[i];
      if(threadIdx.x==0)++w.progress.refinements;
      __syncthreads();
    }
    if(threadIdx.x==0) {
      if(!accepted&&!s.error)Reject(s,Invalid);
      if(!s.error)++w.progress.solves;
    }
    __syncthreads();
  }
  if(!s.error)for(int i=threadIdx.x;i<p.n;i+=Threads)o.solution[i]=full[i];
  if(threadIdx.x==0){w.progress.error=s.error;workspace->progress=w.progress;o.error=s.error;}
}
