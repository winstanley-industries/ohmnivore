from pathlib import Path
import json
w=Path('/home/adam/emi03-work');proof=json.loads((w/'auxiliary-numeric121.json').read_text());aux=proof['auxiliary_order'];branch=proof['branch_order'];rest=proof['retained_indices'];position={v:i for i,v in enumerate(aux)}
m=json.loads((w/'schur-snapshots107/boundary-fast_low_lc/matrices.jsonl').read_text().splitlines()[0]);rows=m['rows'];cols=m['columns'];slot={(r,cols[k]):k for r in range(m['n']) for k in range(rows[r],rows[r+1])}
for path in (w/'schur-snapshots107').glob('*/matrices.jsonl'):
 for line in path.read_text().splitlines():
  other=json.loads(line);assert other['rows']==rows and other['columns']==cols
levels=[];support=[];deps=[]
for i,b in enumerate(branch):
 parents=[j for j in range(i) if (b,aux[j]) in slot];assert not any((b,aux[j]) in slot for j in range(i+1,len(aux)))
 deps.append(parents);levels.append(1+max([levels[j] for j in parents],default=-1))
 reachable={j for j,r in enumerate(rest) if (b,r) in slot}
 for parent in parents:reachable|=support[parent]
 support.append(reachable)
response_offsets=[0];response_columns=[];rs={}
for i,columns in enumerate(support):
 for col in sorted(columns):rs[i,col]=len(response_columns);response_columns.append(col)
 response_offsets.append(len(response_columns))
recipes=[];terms=[]
for i,b in enumerate(branch):
 for col in sorted(support[i]):
  begin=len(terms)
  for j in deps[i]:
   if col in support[j]:terms.append([slot[b,aux[j]],rs[j,col]])
  recipes.append([slot.get((b,rest[col]),-1),begin,len(terms)-begin])
offset_recipes=[];offset_terms=[]
for i,b in enumerate(branch):
 begin=len(offset_terms)
 for j in deps[i]:offset_terms.append([slot[b,aux[j]],j])
 offset_recipes.append([b,begin,len(offset_terms)-begin])
core_rows=[0];core_columns=[];core_recipes=[];core_terms=[];rhs_recipes=[];rhs_terms=[]
for r in rest:
 reachable={j for j,c in enumerate(rest) if (r,c) in slot}
 touching=[i for i,v in enumerate(aux) if (r,v) in slot]
 for i in touching:reachable|=support[i]
 for j in sorted(reachable):
  core_columns.append(j);begin=len(core_terms)
  for i in touching:
   if j in support[i]:core_terms.append([slot[r,aux[i]],rs[i,j]])
  core_recipes.append([slot.get((r,rest[j]),-1),begin,len(core_terms)-begin])
 core_rows.append(len(core_columns));begin=len(rhs_terms)
 for i in touching:rhs_terms.append([slot[r,aux[i]],i])
 rhs_recipes.append([r,begin,len(rhs_terms)-begin])
order=[];bounds=[0];rorder=[];rbounds=[0]
for level in range(max(levels)+1):
 for i,l in enumerate(levels):
  if l==level:order.append(i);rorder.extend(range(response_offsets[i],response_offsets[i+1]))
 bounds.append(len(order));rbounds.append(len(rorder))
p={'full_rows':rows,'full_columns':cols,'aux':aux,'branches':branch,'retained':rest,'response_offsets':response_offsets,'response_columns':response_columns,'response_recipes':recipes,'response_terms':terms,'offset_recipes':offset_recipes,'offset_terms':offset_terms,'core_rows':core_rows,'core_columns':core_columns,'core_recipes':core_recipes,'core_terms':core_terms,'rhs_recipes':rhs_recipes,'rhs_terms':rhs_terms,'aux_order':order,'aux_bounds':bounds,'response_order':rorder,'response_bounds':rbounds,'gmin_slots':[slot[v,v] for v in aux]}
(w/'auxiliary-plan122.json').write_text(json.dumps(p,indent=2)+'\n')
fields=[]
for name,values in p.items():
 typ='Recipe' if name.endswith('_recipes') else 'Term' if name.endswith('_terms') else 'int'
 val=','.join(('{'+','.join(str(x) for x in v)+'}') if isinstance(v,list) else str(v) for v in values)
 fields.append(f'  p.{name} = {{{val}}};')
(w/'auxiliary-generated122.inc').write_text('HostPlan GeneratedHostPlan() {\n  HostPlan p;\n'+'\n'.join(fields)+'\n  return p;\n}\n')
print({'unknowns':m['n'],'core_unknowns':len(rest),'auxiliaries':len(aux),'levels':len(bounds)-1,'original_nnz':len(cols),'core_nnz':len(core_columns),'response_values':len(response_columns),'response_terms':len(terms),'matrix_terms':len(core_terms),'rhs_terms':len(rhs_terms)})
