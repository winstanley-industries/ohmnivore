  // Experimental exact projection of isolated algebraic voltage drivers.
  // Admission uses the compiled graph, not device names or workload indices.
  std::vector<int> candidate(m.n, -1), level(programs.size(), -1);
  for (std::size_t index = 0; index < programs.size(); ++index) {
    const auto &descriptor = system.behavioral_descriptors[index];
    if (!descriptor.is_voltage || !descriptor.positive_node_index ||
        descriptor.negative_node_index || !descriptor.branch_index)
      continue;
    const int node = *descriptor.positive_node_index;
    const int branch = *descriptor.branch_index;
    bool valid = descriptor.rows.size() == 1 &&
                 descriptor.rows[0].row == static_cast<std::size_t>(branch) &&
                 descriptor.rows[0].coefficient == -1 &&
                 system.b_dc[node] == 0 && system.b_dc[branch] == 0;
    int stamps = 0;
    for (int row = 0; row < m.n; ++row) {
      for (auto k = system.g.row_offsets[row]; k < system.g.row_offsets[row + 1]; ++k) {
        const int col = system.g.column_indices[k];
        const double value = system.g.values[k];
        if (value == 0 || (row != node && row != branch && col != node && col != branch)) continue;
        valid &= ((row == node && col == node && value == kGminSiemens) ||
                  (row == node && col == branch && value == 1) ||
                  (row == branch && col == node && value == 1));
        ++stamps;
      }
      for (auto k = system.c.row_offsets[row]; k < system.c.row_offsets[row + 1]; ++k) {
        const int col = system.c.column_indices[k];
        if (system.c.values[k] != 0 && (row == node || row == branch || col == node || col == branch)) valid = false;
      }
    }
    valid &= stamps == 3;
    for (std::size_t other = 0; other < programs.size(); ++other) {
      const auto &program = programs[other];
      for (unsigned j = 0; j < program.dependency_count; ++j)
        if (dependencies[program.dependency_offset + j] == static_cast<unsigned>(branch)) valid = false;
      if (other != index)
        for (const auto &row : system.behavioral_descriptors[other].rows)
          if (row.row == static_cast<std::size_t>(node) || row.row == static_cast<std::size_t>(branch)) valid = false;
    }
    for (const auto &source : system.transient_sources)
      for (const auto &stamp : source.rhs_stamps)
        if (stamp.index == static_cast<std::size_t>(node) || stamp.index == static_cast<std::size_t>(branch)) valid = false;
    for (const auto &cap : system.capacitor_initial_constraints)
      if (cap.positive_node_index == static_cast<std::size_t>(node) || cap.negative_node_index == static_cast<std::size_t>(node)) valid = false;
    for (const auto &ind : system.inductor_initial_constraints)
      if (ind.branch_index == static_cast<std::size_t>(branch)) valid = false;
    if (valid) candidate[node] = index;
  }
  std::vector<int> visiting(programs.size());
  std::function<bool(int)> visit = [&](int index) {
    if (level[index] >= 0) return true;
    if (visiting[index]) return false;
    visiting[index] = 1;
    int result = 0;
    const auto &program = programs[index];
    for (unsigned j = 0; j < program.dependency_count; ++j) {
      const int parent = candidate[dependencies[program.dependency_offset + j]];
      if (parent < 0) continue;
      if (!visit(parent)) return false;
      result = std::max(result, level[parent] + 1);
    }
    visiting[index] = 0; level[index] = result; return true;
  };
  bool acyclic = true;
  for (int index : candidate) if (index >= 0) acyclic &= visit(index);
  // An unsupported cycle keeps the existing full Newton path.
  if (acyclic) {
    std::vector<AuxiliaryDriver> drivers;
    std::vector<int> bounds{0};
    const int levels = *std::max_element(level.begin(), level.end()) + 1;
    for (int current = 0; current < levels; ++current) {
      for (int node = 0; node < m.n; ++node) {
        const int index = candidate[node];
        if (index >= 0 && level[index] == current)
          drivers.push_back({index, node, static_cast<int>(*system.behavioral_descriptors[index].branch_index)});
      }
      bounds.push_back(drivers.size());
    }
    m.auxiliary_levels = levels;
    m.auxiliary_drivers = allocation.Upload(drivers);
    m.auxiliary_bounds = allocation.Upload(bounds);
    m.original_nodes = allocation.Upload(nodes);
    workspace.auxiliary_stack = allocation.Allocate<std::uint32_t>(m.programs * 65);
    workspace.auxiliary_stage = allocation.Allocate<unsigned char>(m.programs * 65);
    std::fprintf(stderr, "auxiliary projection %zu drivers %d levels\n", drivers.size(), levels);
  }
