__device__ void ProjectAuxiliary(const Model &m, Workspace &w, Shared &s, double *state) {
  if (!m.auxiliary_levels) return;
  if (threadIdx.x == 0) {
    s.expression_cache_valid = false;
    s.expression_cache_derivatives = false;
  }
  __syncthreads();
  for (int level = 0; level < m.auxiliary_levels && !s.error; ++level) {
    for (int at = m.auxiliary_bounds[level] + threadIdx.x; at < m.auxiliary_bounds[level + 1]; at += Threads) {
      const auto driver = m.auxiliary_drivers[at];
      EvaluateProgram(driver.program, m.program, m.programs, m.original_nodes, nullptr,
                      m.dependencies, state, w.expressions, w.gradients,
                      s.expression_values, s.expression_adjoints, w.auxiliary_stack,
                      w.auxiliary_stage, false);
      const auto result = w.expressions[driver.program];
      if (result.status) Reject(s, result.status == 1 ? Nonfinite : Invalid);
      else {
        state[driver.node] = result.value;
        state[driver.branch] = -1e-12 * result.value;
        if (!Bounded(state[driver.branch])) Reject(s, Nonfinite);
      }
    }
    __syncthreads();
  }
}
