from pathlib import Path
import subprocess
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work')
# Start from the selected implementation; only these two files are experimental.
for name in ['cuda/emi03_resident.cu','cuda/emi03_resident_device.cuh']:
 text=subprocess.check_output(['git','show','HEAD:'+name],cwd=r,text=True)
 (w/('projection129-base-'+Path(name).name)).write_text(text)
 if name.endswith('.cuh'):
  text=text.replace('struct Model {','struct AuxiliaryDriver { int program, node, branch; };\nstruct Model {\n  int auxiliary_levels = 0;\n  const AuxiliaryDriver *auxiliary_drivers = nullptr;\n  const int *auxiliary_bounds = nullptr;\n  const internal::ExportedExpressionNode *original_nodes = nullptr;')
  text=text.replace('struct Workspace {','struct Workspace {\n  std::uint32_t *auxiliary_stack = nullptr;\n  unsigned char *auxiliary_stage = nullptr;')
  text=text.replace('__device__ void Newton(', (w/'projection129_device.cc').read_text()+'\n__device__ void Newton(')
  text=text.replace('  bool chord = s.factor_valid && s.active_scale == s.factored_scale;', '  ProjectAuxiliary(m, w, s, w.current);\n  if (s.error) return;\n  bool chord = s.factor_valid && s.active_scale == s.factored_scale;')
  text=text.replace('      if (!s.error)\n        Assemble(m, w, s, w.proposed, false);','      if (!s.error) ProjectAuxiliary(m, w, s, w.proposed);\n      if (!s.error)\n        Assemble(m, w, s, w.proposed, false);')
 else:
  text=text.replace('  m.dependencies = allocation.Upload(dependencies);','  m.dependencies = allocation.Upload(dependencies);\n'+(w/'projection129_host.cc').read_text())
 (r/name).write_text(text)
