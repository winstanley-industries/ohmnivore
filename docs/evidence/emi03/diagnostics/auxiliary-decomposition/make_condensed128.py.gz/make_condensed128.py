from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'condensed126.cu').read_text();a=s.index('__device__ void Interface(');b=s.index('template <bool Cluster>',a);f=s[a:b]
f=f.replace('bool correction) {','bool correction, bool ordered) {')
a0=f.index('    for (int at = lane; at < p.ports * p.ports; at += 32) {');b0=f.index('  }\n  double *values',a0)
loop=f[a0:b0];loop=loop[:loop.index('    if (!Factor')]
loop=loop.replace('const int original = p.port[at / p.ports], col = at % p.ports;','const int row = reuse ? permutation[at / p.ports] : at / p.ports;\n      const int original = p.port[row], col = at % p.ports;').replace('p.interface_offsets[at / p.ports]','p.interface_offsets[row]').replace('p.interface_offsets[at / p.ports + 1]','p.interface_offsets[row + 1]')
f=f[:a0]+'    for(int attempt=0;attempt<2;++attempt) {\n      const bool reuse=ordered && attempt==0;\n'+loop+'''      if(reuse) { if(OrderedFactor(lu,p.ports,masks))break; }
      else { if(!Factor(lu,p.ports,permutation,w,-1,masks))return; break; }
    }
'''+f[b0:]
s=s[:a]+f+s[b:];s=s.replace('masks + G * L * 2, pass != 0);','masks + G * L * 2, pass != 0, iteration > 0);');assert 'pass != 0, iteration > 0);' in s
(r/'cuda/emi03_schur_probe.cu').write_text(s)
