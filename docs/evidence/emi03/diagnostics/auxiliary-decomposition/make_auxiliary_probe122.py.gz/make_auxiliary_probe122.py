from pathlib import Path
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work')
s=(w/'selected119b.cu').read_text()
prefix=s[:s.index('__global__ void SelectedMatrixReplay')]
init=s[s.index('  __shared__ Shared s;',s.index('__global__ void SelectedMatrixReplay')):s.index('  for (int i = threadIdx.x; i < m.n; i += Threads)\n    w.affine_rhs[i] = workspace->affine_rhs[i];')]
device=(w/'auxiliary_probe122_device.cc').read_text().replace('  // INITIALIZATION_FROM_SELECTED_KERNEL',init).replace('AuxiliaryMatrix(p,o.values,response,w.jacobian,s);','AuxiliaryMatrix(p,o.values,response,w.jacobian,s);\n    if(s.error)break;')
common=s[s.index('template <class T> T ProbeChecked'):s.index('int MatrixProbe')]
host=(w/'auxiliary_probe122_host.cc').read_text().replace('auto *dm=allocation.Upload(models),*unused_model=dm;static_cast<void>(unused_model);','auto *dm=allocation.Upload(models);')
(r/'cuda/emi03_auxiliary_matrix_probe.cu').write_text(prefix+device+common+(w/'auxiliary-generated122.inc').read_text()+host)
p=r/'cuda/BUILD.bazel';s=p.read_text()
if 'name = "emi03_auxiliary_matrix_probe_impl"' not in s:
 s+='''
cuda_library(
    name = "emi03_auxiliary_matrix_probe_impl",
    testonly = True,
    srcs = ["emi03_auxiliary_matrix_probe.cu"],
    copts = ["-std=c++20", "--fmad=false", "-lineinfo", "-Xcompiler=-Wall", "-Xcompiler=-Werror", "-Xcompiler=-Wextra"],
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_cuda", "@suitesparse_7_12_3//:klu"],
)
cc_binary(
    name = "emi03_auxiliary_matrix_probe",
    testonly = True,
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_auxiliary_matrix_probe_impl"],
)
'''
 p.write_text(s)
