from pathlib import Path
import json
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'auxiliary122.cu').read_text();plan=json.loads((w/'condensed-plan126.json').read_text());q=[i for g in plan['groups'] for i in g]+plan['ports'];assert sorted(q)==list(range(105))
s='#include <cstdlib>\n'+s
s=s.replace('  common.ordering =\n      1;', '  const std::string mode = std::getenv("EMI03_AUX_ORDER") ? std::getenv("EMI03_AUX_ORDER") : "colamd";\n  common.ordering =\n      mode == "amd" ? 0 : 1;')
s=s.replace('  symbolic.reset();','  symbolic.reset();\n  if(model.n==105 && mode=="block") { q = {'+','.join(map(str,q))+'}; structural_rows = q; }')
s=s.replace('  model.factor_levels =\n', '  model.factor_levels =\n')
s=s.replace('  m.row_offsets = allocation.Upload(', '  std::cerr << "core_plan " << m.n << " " << m.factor_nonzeros << " " << m.factor_levels << " " << m.forward_levels << " " << m.backward_levels << "\\n";\n  m.row_offsets = allocation.Upload(')
assert 'mode ==' in s
(r/'cuda/emi03_auxiliary_matrix_probe.cu').write_text(s)
