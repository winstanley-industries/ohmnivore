from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore')
s=(w/'auxiliary122.cu').read_text();h=(r/'cuda/emi03_resident_device.cuh').read_text()
a=h.index('__device__ void FactorImpl(');b=h.index('__device__ void Factor(const ',a);f=h[a:b]
f=f.replace('FactorImpl(', 'AuxiliaryFactor(')
start=f.index('  for (int level = 0; level < m.factor_levels')
end=f.index('  if (threadIdx.x == 0 && s.pivot_failure)',start)
loop=f[start:end].replace('threadIdx.x;','threadIdx.x;').replace('at += Threads','at += 32').replace('__syncthreads();','__syncwarp();')
f=f[:start]+'  if(threadIdx.x < 32) {\n'+loop+'  }\n  __syncthreads();\n'+f[end:]
s=s.replace('__global__ void AuxiliaryMatrixReplay(',f+'\n__global__ void AuxiliaryMatrixReplay(')
s=s.replace('    Factor(m, w, s);','    AuxiliaryFactor(m, w, s);')
# Emit dependency widths for interpreting the screen.
s=s.replace('  PrepareFactorPlan(system, analysis, std::vector<double>(n), m, allocation);','  PrepareFactorPlan(system, analysis, std::vector<double>(n), m, allocation);\n  std::cerr << "core_plan " << m.n << " " << m.factor_nonzeros << " " << m.factor_levels << " " << m.forward_levels << " " << m.backward_levels << "\\n";')
(r/'cuda/emi03_auxiliary_matrix_probe.cu').write_text(s)
