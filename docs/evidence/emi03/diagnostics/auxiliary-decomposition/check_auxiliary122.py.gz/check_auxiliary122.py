from pathlib import Path
import json,statistics,hashlib,subprocess,time,os
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore')
rows=[json.loads(s) for s in (w/'auxiliary122-run.jsonl').read_text().splitlines()]
timings=[x for x in rows if x['kind']=='auxiliary_timing'];validation=[x for x in rows if x['kind']=='auxiliary_validation']
summary={'matrix_checks':len(validation[:288]),'all_validation_rows':len(validation),'max_klu':max(x['scaled_klu_difference'] for x in validation),'max_componentwise':max(x['componentwise'] for x in validation),'timings':{str(n):{'median_us':statistics.median(x['device_ms']*1000/x['iterations'] for x in timings if x['count']==n and x['repetition']>=0)} for n in [1,9,16]},'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [w/'auxiliary122-binary',w/'auxiliary122.cu',w/'auxiliary-plan122.json',w/'schur-replay117.txt']}}
(w/'auxiliary122-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
sanitizer=w/'pinned-profiler-bazel/external/+http_archive+compute_sanitizer_current/compute-sanitizer/compute-sanitizer'
checks=[]
for tool in ['memcheck','racecheck','synccheck','initcheck']:
 cmd=[str(sanitizer),'--tool',tool,'--error-exitcode','99',str(w/'auxiliary122-binary'),str(w/'schur-replay117.txt'),'--validate-only'];t=time.time()
 with (w/f'auxiliary122-{tool}.log').open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(w/'tmp')}).returncode
 checks.append({'tool':tool,'command':cmd,'exit_code':code,'seconds':time.time()-t});print(checks[-1],flush=True)
 (w/'auxiliary122-sanitizers.json').write_text(json.dumps(checks,indent=2)+'\n')
 if code:raise SystemExit(code)
