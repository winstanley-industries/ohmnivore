from pathlib import Path
import json
w=Path('/home/adam/emi03-work');p=json.loads((w/'auxiliary-plan122.json').read_text())
exec((w/'analyze_structure.py').read_text().split('@lru_cache(None)')[0])
rest=p['retained'];ri={v:i for i,v in enumerate(rest)};ai={v:i for i,v in enumerate(p['aux'])};affected=set();details=[]
for id,d in desc.items():
 if id in candidates.values():continue
 rows={ri[r] for r in d['rows'] if r in ri};columns=set()
 for v in d['dependencies']:
  if v in ri:columns.add(ri[v])
  elif v in ai:columns.update(p['response_columns'][p['response_offsets'][ai[v]]:p['response_offsets'][ai[v]+1]])
  else:raise Exception(('unexpected dependency',v))
 affected.update(rows|columns);details.append({'program':id,'rows':sorted(rows),'columns':sorted(columns)})
# Every behavioral driver can influence any original row touching its voltage,
# through its recursively reachable retained voltage columns.
for r,recipe in enumerate(p['rhs_recipes']):
 for term in p['rhs_terms'][recipe[1]:recipe[1]+recipe[2]]:
  j=term[1];affected.add(r);affected.update(p['response_columns'][p['response_offsets'][j]:p['response_offsets'][j+1]])
ports=sorted(affected);linear=sorted(set(range(len(rest)))-affected)
result={'scope':'Structural candidate for exact linear-interior condensation after auxiliary elimination; unqualified','core_unknowns':len(rest),'ports':[{'core':i,'original':rest[i],'name':nodes.get(rest[i],branches.get(rest[i]))} for i in ports],'linear':[{'core':i,'original':rest[i],'name':nodes.get(rest[i],branches.get(rest[i]))} for i in linear],'nonlinear_programs':details}
(w/'auxiliary-static124.json').write_text(json.dumps(result,indent=2)+'\n')
print('ports',len(ports),'linear',len(linear));print([(x['original'],x['name']) for x in result['ports']]);print([(x['original'],x['name']) for x in result['linear']])
