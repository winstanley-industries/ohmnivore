from reference.emi03 import ensemble as e
from pathlib import Path
import json,hashlib
np=e.metrics.np;w=Path('/home/adam/emi03-work')
exec((w/'analyze_structure.py').read_text().split('@lru_cache(None)')[0])
aux=np.array(order);current=np.array([desc[candidates[v]]['branch'] for v in order]);rest=np.array(sorted(set(range(size))-set(aux)-set(current)));position={int(v):i for i,v in enumerate(aux)}
records=[]
def residual(a,b,x):
 aa=a.astype(np.longdouble);bb=b.astype(np.longdouble);xx=x.astype(np.longdouble)
 r=bb-aa@xx;denom=abs(bb)+abs(aa)@abs(xx);scale=np.maximum(abs(aa).max(axis=1),abs(bb));scale[scale==0]=1
 component=np.max(np.divide(abs(r),denom,out=np.zeros_like(r),where=denom!=0));norm=np.max(abs(r)/scale)/(np.max(abs(aa).sum(axis=1)/scale)*np.max(abs(xx))+np.max(abs(bb)/scale))
 return r.astype(float),float(norm),float(component)
for folder in sorted((w/'schur-snapshots107').glob('*-*')):
 if not folder.is_dir():continue
 for line in (folder/'matrices.jsonl').read_text().splitlines():
  m=json.loads(line);n=m['n'];a=np.zeros((n,n));b=np.array(m['rhs']);oracle=np.array(m['oracle'])
  for i in range(n):a[i,np.array(m['columns'][m['rows'][i]:m['rows'][i+1]])]=m['values'][m['rows'][i]:m['rows'][i+1]]
  row={'case':folder.name,'sample':m['sample'],'alpha':m['alpha']}
  try:
   assert n==185 and len(aux)==40 and len(rest)==105
   for v,branch in zip(aux,current):
    assert m['names'][v]==nodes[v] and m['names'][branch]==branches[branch]
    assert a[v,v]==1e-12 and a[v,branch]==1 and a[branch,v]==1
    assert np.count_nonzero(a[v])==2 and np.count_nonzero(a[:,branch])==1
    assert not np.any(a[branch,current])
    assert not np.any(a[branch,aux[position[int(v)]+1:]])
   assert not np.any(a[np.ix_(rest,current)])
   response=np.zeros((len(aux),len(rest)))
   for i,branch in enumerate(current):
    response[i]=-a[branch,rest]
    for j in range(i):response[i]-=a[branch,aux[j]]*response[j]
   reduced=a[np.ix_(rest,rest)]+a[np.ix_(rest,aux)]@response
   scale=abs(reduced).max(axis=1);assert np.all(scale>0)
   def solve(rhs):
    offset=np.zeros(len(aux))
    for i,branch in enumerate(current):
     offset[i]=rhs[branch]
     for j in range(i):offset[i]-=a[branch,aux[j]]*offset[j]
    rb=rhs[rest]-a[np.ix_(rest,aux)]@offset
    x=np.empty(n);x[rest]=np.linalg.solve(reduced/scale[:,None],rb/scale)
    x[aux]=offset+response@x[rest]
    x[current]=rhs[aux]-1e-12*x[aux]
    return x
   x=solve(b);history=[]
   for attempt in range(5):
    r,norm,comp=residual(a,b,x);history.append({'normwise':norm,'componentwise':comp})
    if not np.any(r) or (attempt>0 and norm<=1e-10 and comp<=1e-5):break
    if attempt<4:x+=solve(r)
   row.update(status='pass' if norm<=1e-10 and comp<=1e-5 else 'residual_failure',refinements=len(history)-1,residual_history=history,relative_klu_difference=float(max(abs(x-oracle))/max(1,max(abs(oracle)))),reduced_nonzero_count=int(np.count_nonzero(reduced)),reduced_condition_inf=float(np.linalg.cond(reduced/scale[:,None],np.inf)))
  except (AssertionError,np.linalg.LinAlgError) as error:row.update(status='failure',error=str(error))
  records.append(row)
result={'scope':'Exact algebraic elimination of 40 grounded isolated acyclic voltage drivers and reconstruction of all 185 unknowns; no AST expansion or physical-model change; offline matrix feasibility, not GPU or transient qualification','original_unknowns':185,'reduced_unknowns':105,'auxiliary_order':aux.tolist(),'branch_order':current.tolist(),'retained_indices':rest.tolist(),'passed':sum(r['status']=='pass' for r in records),'failed':sum(r['status']!='pass' for r in records),'records':records}
(w/'auxiliary-numeric121.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['records','auxiliary_order','branch_order','retained_indices']},indent=2))
if result['failed']:print(json.dumps([r for r in records if r['status']!='pass'],indent=2))
else:print('max relative KLU',max(r['relative_klu_difference'] for r in records),'max refinements',max(r['refinements'] for r in records),'max condition',max(r['reduced_condition_inf'] for r in records))
raise SystemExit(bool(result['failed']))
