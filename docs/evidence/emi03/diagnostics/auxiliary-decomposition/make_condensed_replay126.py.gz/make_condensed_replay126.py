from pathlib import Path
import json
w=Path('/home/adam/emi03-work');p=json.loads((w/'auxiliary-plan122.json').read_text());s=json.loads((w/'schur-structure117.json').read_text());q=json.loads((w/'auxiliary-static124b.json').read_text());rest=p['retained'];ri={v:i for i,v in enumerate(rest)};groups=[[ri[i] for i in g['indices'] if i in ri] for g in s['groups']];ports=[ri[x['index']] for x in s['interface']]
nonlinear_rows={r for d in q['nonlinear_programs'] for r in d['rows']};nonlinear_rows|={r for r,recipe in enumerate(p['rhs_recipes']) if recipe[2]}
constant=[not (set(g)&nonlinear_rows) for g in groups];print('constant',constant,'sizes',[len(g) for g in groups]);(w/'condensed-plan126.json').write_text(json.dumps({'ports':ports,'groups':groups,'constant':constant},indent=2)+'\n')
matrices=[(folder.name,json.loads(line)) for folder in sorted((w/'schur-snapshots107').glob('*-*')) if folder.is_dir() for line in (folder/'matrices.jsonl').read_text().splitlines()]
with (w/'condensed-replay126.txt').open('w') as f:
 def line(*x):f.write(' '.join(str(v) for v in x)+'\n')
 line('EMI03_SCHUR_REPLAY_1');line(len(rest),len(ports),len(groups),len(matrices));line(*ports)
 for g in groups:line(len(g),*g)
 for case,m in matrices:
  a=m['values'];b=m['rhs'];response=[0.]*len(p['response_columns']);offset=[0.]*len(p['aux'])
  for i,(source,begin,count) in enumerate(p['response_recipes']):response[i]=-(a[source] if source>=0 else 0)-sum(a[c]*response[o] for c,o in p['response_terms'][begin:begin+count])
  for i,(source,begin,count) in enumerate(p['offset_recipes']):offset[i]=b[source]-sum(a[c]*offset[o] for c,o in p['offset_terms'][begin:begin+count])
  reduced=[(a[source] if source>=0 else 0)+sum(a[c]*response[o] for c,o in p['core_terms'][begin:begin+count]) for source,begin,count in p['core_recipes']]
  rb=[b[source]-sum(a[c]*offset[o] for c,o in p['rhs_terms'][begin:begin+count]) for source,begin,count in p['rhs_recipes']]
  line(case+'-s'+str(m['sample'])+'-a'+str(int(m['alpha'])),len(reduced));line(*p['core_rows']);line(*p['core_columns']);line(*reduced);line(*rb);line(*[m['oracle'][i] for i in rest])
r=Path('/home/adam/code/ohmnivore');source=(w/'schur118.cu').read_text();source=source.replace('  int n = 0, ports = 0, groups = 0, storage = 0;','  int n = 0, ports = 0, groups = 0, storage = 0;\n  bool constant[G]{};')
a=source.index('__device__ void Interior(');b=source.index('__device__ void Interface(',a);interior=source[a:b].replace('if (!correction) {','if (!correction && !(ordered && p.constant[group])) {').replace('const int count = correction ? 1 : coupled + 1;','const int count = (correction || (ordered && p.constant[group])) ? 1 : coupled + 1;');source=source[:a]+interior+source[b:]
source=source.replace('    std::vector<Sample> samples(count);','    if(p.n != 105 || p.groups != 15 || p.ports != 14) throw std::runtime_error("frozen reduced replay dimensions changed");\n'+''.join(f'    p.constant[{i}] = {str(v).lower()};\n' for i,v in enumerate(constant))+'    std::vector<Sample> samples(count);')
(r/'cuda/emi03_schur_probe.cu').write_text(source)
