#include "cuda/emi03_cuda_internal.h"
#include "cuda/emi03_expression_device.cuh"
#include "cuda/emi03_real_solver.h"
#include "cuda/emi03_reduction.cuh"
#include "cuda/emi03_resident.h"
#include "ohmnivore/behavioral.h"
#include "ohmnivore/nonlinear.h"
#include "ohmnivore/solver.h"
#include "ohmnivore/waveform.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>

#include <klu.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <limits>
#include <memory>
#include <thread>
#include <utility>
#include <vector>

namespace ohmnivore {
namespace {
using namespace emi03_device;
using emi03_cuda_internal::BackendError;
using emi03_cuda_internal::CheckCuda;
#define Emi03Advance UnusedAdvanceInMatrixProbe
#include "cuda/emi03_resident_device.cuh"
#undef Emi03Advance

class HostStaging {
public:
  static constexpr std::size_t kBytes = Chunk * (N + 1) * sizeof(double);
  HostStaging() {
    CheckCuda(cudaHostAlloc(&data_, kBytes, cudaHostAllocDefault),
              "resident private pinned transfer staging");
  }
  HostStaging(const HostStaging &) = delete;
  HostStaging &operator=(const HostStaging &) = delete;
  ~HostStaging() {
    if (data_ && cudaFreeHost(data_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
  }
  void *data() const { return data_; }

private:
  void *data_ = nullptr;
};
class Allocations {
public:
  explicit Allocations(HostStaging &staging, cudaStream_t consumer = nullptr)
      : staging_(staging), consumer_(consumer) {
    CheckCuda(cudaStreamCreateWithFlags(&stream_, cudaStreamNonBlocking),
              "resident stream creation");
  }
  Allocations(const Allocations &) = delete;
  Allocations &operator=(const Allocations &) = delete;
  cudaStream_t stream() const { return stream_; }
  HostStaging &staging() const { return staging_; }
  void Copy(void *destination, const void *source, std::size_t bytes,
            cudaMemcpyKind kind) {
    if (kind != cudaMemcpyHostToDevice && kind != cudaMemcpyDeviceToHost)
      throw BackendError(ErrorCode::kUnsupported, "resident copy direction");
    // Pageable asynchronous copies can spin in the driver before returning.
    // Keep bounded pinned staging private to each job. Every copy completes
    // before another stream within this job uses that storage. Completion
    // queries sleep between attempts: blocking event waits still consumed a CPU
    // core on the measured WSL driver. All waiting remains in charged wall
    // time.
    if (!completed_)
      CheckCuda(
          cudaEventCreateWithFlags(&completed_, cudaEventBlockingSync |
                                                    cudaEventDisableTiming),
          "resident blocking completion event");
    for (std::size_t offset = 0; offset < bytes;
         offset += HostStaging::kBytes) {
      const auto count = std::min(HostStaging::kBytes, bytes - offset);
      auto *target = static_cast<unsigned char *>(destination) + offset;
      const auto *input = static_cast<const unsigned char *>(source) + offset;
      if (kind == cudaMemcpyHostToDevice)
        std::memcpy(staging_.data(), input, count);
      CheckCuda(cudaMemcpyAsync(
                    kind == cudaMemcpyHostToDevice ? target : staging_.data(),
                    kind == cudaMemcpyHostToDevice ? staging_.data() : input,
                    count, kind, stream_),
                "resident stream copy");
      CheckCuda(cudaEventRecord(completed_, stream_),
                "resident completion event record");
      const auto start = std::chrono::steady_clock::now();
      auto status = cudaEventQuery(completed_);
      while (status == cudaErrorNotReady) {
        std::this_thread::sleep_for(std::chrono::microseconds(250));
        status = cudaEventQuery(completed_);
      }
      emi03_cuda_internal::Statistics().synchronization_ns +=
          std::chrono::duration_cast<std::chrono::nanoseconds>(
              std::chrono::steady_clock::now() - start)
              .count();
      CheckCuda(status, "resident completion query");
      if (kind == cudaMemcpyDeviceToHost)
        std::memcpy(target, staging_.data(), count);
    }
  }
  ~Allocations() {
    // Factor metadata is uploaded on this owner's stream, but read by the
    // resident simulation stream. Both must finish before asynchronous release,
    // including exceptional exits before the normal output-copy completion.
    if (consumer_ && consumer_ != stream_ &&
        cudaStreamSynchronize(consumer_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
    if (cudaStreamSynchronize(stream_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
    for (auto it = owned_.rbegin(); it != owned_.rend(); ++it)
      emi03_cuda_internal::FreeDevice(it->first, it->second);
    if (completed_ && cudaEventDestroy(completed_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
    if (cudaStreamDestroy(stream_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
  }
  template <class T> T *Allocate(std::size_t count) {
    const auto bytes = std::max<std::size_t>(1, count) * sizeof(T);
    void *p = emi03_cuda_internal::AllocateDevice(bytes);
    try {
      owned_.emplace_back(p, bytes);
    } catch (...) {
      emi03_cuda_internal::FreeDevice(p, bytes);
      throw;
    }
    return static_cast<T *>(p);
  }
  template <class T> T *Upload(const std::vector<T> &values) {
    auto *result = Allocate<T>(values.size());
    if (!values.empty()) {
      Copy(result, values.data(), values.size() * sizeof(T),
           cudaMemcpyHostToDevice);
      emi03_cuda_internal::Statistics().upload_bytes +=
          values.size() * sizeof(T);
    }
    return result;
  }

private:
  cudaStream_t stream_ = nullptr;
  cudaEvent_t completed_ = nullptr;
  HostStaging &staging_;
  cudaStream_t consumer_ = nullptr;
  std::vector<std::pair<void *, std::size_t>> owned_;
};
void PrepareFactorPlan(const MnaSystem &system, const TranAnalysis &analysis,
                       const std::vector<double> &initial, Model &model,
                       Allocations &allocation,
                       const std::vector<double> *refresh = nullptr) {
  // The replay already contains the complete actual Jacobian. Preserve the
  // selected structural ordering and GPU pivot discovery without reassembling
  // it.
  static_cast<void>(analysis);
  static_cast<void>(initial);
  auto matrix = system.g;
  if (refresh) {
    if (refresh->size() != matrix.values.size())
      throw BackendError(ErrorCode::kInvalidStructure,
                         "resident refresh structure changed");
    matrix.values = *refresh;
  }
  auto converted = ConvertCsrToSolverCsc(matrix);
  if (!converted.ok())
    throw BackendError(converted.error().code, converted.error().message);
  auto csc = converted.TakeValue();
  klu_common common;
  klu_defaults(&common);
  common.ordering =
      1; // COLAMD: structural ordering only, never a CPU numeric solve.
  const auto release_symbolic = [&common](klu_symbolic *value) {
    if (value)
      klu_free_symbolic(&value, &common);
  };
  std::unique_ptr<klu_symbolic, decltype(release_symbolic)> symbolic(
      klu_analyze(model.n, csc.column_offsets.data(), csc.row_indices.data(),
                  &common),
      release_symbolic);
  if (!symbolic)
    throw BackendError(ErrorCode::kSingular,
                       "resident symbolic ordering failed");
  std::vector<int> q(symbolic->Q, symbolic->Q + model.n);
  std::vector<int> structural_rows(symbolic->P, symbolic->P + model.n);
  symbolic.reset();
  std::vector<int> qi(model.n), p(model.n), pi(model.n);
  for (int j = 0; j < model.n; ++j)
    qi[q[j]] = j;
  {
    Allocations temporary(allocation.staging());
    auto w = std::make_unique<Workspace>();
    std::vector<int> dense_offsets, dense_columns;
    std::vector<double> ordered_values;
    dense_offsets.push_back(0);
    for (int row : structural_rows) {
      for (auto k = matrix.row_offsets[row]; k < matrix.row_offsets[row + 1];
           ++k) {
        dense_columns.push_back(qi[matrix.column_indices[k]]);
        ordered_values.push_back(matrix.values[k]);
      }
      dense_offsets.push_back(static_cast<int>(dense_columns.size()));
    }
    w->jacobian = temporary.Upload(ordered_values);
    w->lu = temporary.Allocate<double>(model.n * N);
    w->equil = temporary.Allocate<double>(model.n);
    w->permutation = temporary.Allocate<int>(model.n);
    auto *device = temporary.Allocate<Workspace>(1);
    auto *error = temporary.Allocate<int>(1);
    auto ordering = model;
    ordering.row_offsets = temporary.Upload(dense_offsets);
    ordering.columns = temporary.Upload(dense_columns);
    temporary.Copy(device, w.get(), sizeof(Workspace), cudaMemcpyHostToDevice);
    DiscoverPivots<<<1, Threads, 0, temporary.stream()>>>(
        ordering, device, error, refresh == nullptr);
    CheckCuda(cudaGetLastError(), "resident pivot discovery launch");
    int status = 0;
    temporary.Copy(&status, error, sizeof(int), cudaMemcpyDeviceToHost);
    if (status)
      throw BackendError(static_cast<ErrorCode>(status - 1),
                         "resident initial GPU pivot discovery failed");
    temporary.Copy(p.data(), w->permutation, model.n * sizeof(int),
                   cudaMemcpyDeviceToHost);
    for (auto &row : p)
      row = structural_rows[row];
    auto &stats = emi03_cuda_internal::Statistics();
    stats.upload_bytes += sizeof(Workspace);
    stats.readback_bytes += (model.n + 1) * sizeof(int);
    ++stats.factorizations;
  }
  for (int j = 0; j < model.n; ++j)
    pi[p[j]] = j;
  std::vector<unsigned char> pattern(model.n * model.n, 0);
  for (int row = 0; row < model.n; ++row)
    for (auto k = matrix.row_offsets[row]; k < matrix.row_offsets[row + 1]; ++k)
      pattern[pi[row] * model.n + qi[matrix.column_indices[k]]] = 1;
  for (int k = 0; k < model.n; ++k)
    for (int row = k + 1; row < model.n; ++row)
      if (pattern[row * model.n + k])
        for (int col = k + 1; col < model.n; ++col)
          pattern[row * model.n + col] |= pattern[k * model.n + col];
  std::vector<int> offsets{0}, columns, diagonal, slots(model.n * model.n, -1);
  for (int row = 0; row < model.n; ++row) {
    for (int col = 0; col < model.n; ++col)
      if (pattern[row * model.n + col]) {
        slots[row * model.n + col] = static_cast<int>(columns.size());
        columns.push_back(col);
      }
    if (slots[row * model.n + row] < 0)
      throw BackendError(ErrorCode::kSingular,
                         "resident missing symbolic pivot");
    diagonal.push_back(slots[row * model.n + row]);
    offsets.push_back(static_cast<int>(columns.size()));
  }
  std::vector<int> inputs;
  for (int row = 0; row < model.n; ++row)
    for (auto k = matrix.row_offsets[row]; k < matrix.row_offsets[row + 1]; ++k)
      inputs.push_back(slots[pi[row] * model.n + qi[matrix.column_indices[k]]]);
  std::vector<FactorEntry> entries(columns.size());
  std::vector<FactorTerm> terms;
  std::vector<int> entry_levels(columns.size(), 0);
  for (int row = 0; row < model.n; ++row)
    for (int slot = offsets[row]; slot < offsets[row + 1]; ++slot) {
      const int col = columns[slot];
      auto &entry = entries[slot];
      if (terms.size() >= (1U << 24))
        throw BackendError(ErrorCode::kUnsupportedSize,
                           "resident factor term encoding bound");
      entry.begin = terms.size();
      entry.diagonal = row > col ? col : -1;
      entry.pivot = row == col ? row : -1;
      for (int k = 0; k < std::min(row, col); ++k) {
        const int lower = slots[row * model.n + k],
                  upper = slots[k * model.n + col];
        if (lower >= 0 && upper >= 0) {
          terms.push_back(FactorTerm{static_cast<std::uint16_t>(lower),
                                     static_cast<std::uint16_t>(upper)});
          entry_levels[slot] =
              std::max(entry_levels[slot],
                       std::max(entry_levels[lower], entry_levels[upper]) + 1);
        }
      }
      if (row > col)
        entry_levels[slot] =
            std::max(entry_levels[slot], entry_levels[diagonal[col]] + 1);
      if (terms.size() - entry.begin > 255)
        throw BackendError(ErrorCode::kUnsupportedSize,
                           "resident factor count encoding bound");
      entry.count = terms.size() - entry.begin;
    }
  model.factor_levels =
      *std::max_element(entry_levels.begin(), entry_levels.end()) + 1;
  std::vector<int> factor_order, factor_starts{0};
  for (int level = 0; level < model.factor_levels; ++level) {
    for (int slot = 0; slot < static_cast<int>(entries.size()); ++slot)
      if (entry_levels[slot] == level)
        factor_order.push_back(slot);
    factor_starts.push_back(static_cast<int>(factor_order.size()));
  }
  model.factor_entries = allocation.Upload(entries);
  model.factor_term = allocation.Upload(terms);
  model.factor_order = allocation.Upload(factor_order);
  model.factor_level_offsets = allocation.Upload(factor_starts);
  model.factor_terms = static_cast<int>(terms.size());
  std::vector<int> forward(model.n, 0), backward(model.n, 0);
  for (int row = 0; row < model.n; ++row)
    for (int j = offsets[row]; j < diagonal[row]; ++j)
      forward[row] = std::max(forward[row], forward[columns[j]] + 1);
  for (int row = model.n - 1; row >= 0; --row)
    for (int j = diagonal[row] + 1; j < offsets[row + 1]; ++j)
      backward[row] = std::max(backward[row], backward[columns[j]] + 1);
  const auto levels = [&](const std::vector<int> &level, const int *&rows,
                          const int *&bounds) {
    const int count = *std::max_element(level.begin(), level.end()) + 1;
    std::vector<int> ordered, starts{0};
    for (int i = 0; i < count; ++i) {
      for (int row = 0; row < model.n; ++row)
        if (level[row] == i)
          ordered.push_back(row);
      starts.push_back(static_cast<int>(ordered.size()));
    }
    rows = allocation.Upload(ordered);
    bounds = allocation.Upload(starts);
    return count;
  };
  model.forward_levels =
      levels(forward, model.forward_rows, model.forward_offsets);
  model.backward_levels =
      levels(backward, model.backward_rows, model.backward_offsets);
  model.factor_nonzeros = static_cast<int>(columns.size());
  model.factor_rows = allocation.Upload(offsets);
  model.factor_columns = allocation.Upload(columns);
  model.factor_diagonal = allocation.Upload(diagonal);
  model.factor_input_slots = allocation.Upload(inputs);
  model.row_permutation = allocation.Upload(p);
  model.column_permutation = allocation.Upload(q);
}
struct Recipe {
  int source, begin, count;
};
struct Term {
  int coefficient, operand;
};
#define INTEGER_FIELDS(X)                                                      \
  X(full_rows)                                                                 \
  X(full_columns)                                                              \
  X(aux) X(branches) X(retained) X(response_offsets) X(response_columns)       \
      X(core_rows) X(core_columns) X(aux_order) X(aux_bounds)                  \
          X(response_order) X(response_bounds) X(gmin_slots)
#define RECIPE_FIELDS(X)                                                       \
  X(response_recipes) X(offset_recipes) X(core_recipes) X(rhs_recipes)
#define TERM_FIELDS(X)                                                         \
  X(response_terms) X(offset_terms) X(core_terms) X(rhs_terms)
struct HostPlan {
#define DECLARE(name) std::vector<int> name;
  INTEGER_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) std::vector<Recipe> name;
  RECIPE_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) std::vector<Term> name;
  TERM_FIELDS(DECLARE)
#undef DECLARE
};
struct DevicePlan {
  int n, auxiliaries, core, core_nnz, response_values, levels;
#define DECLARE(name) const int *name;
  INTEGER_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) const Recipe *name;
  RECIPE_FIELDS(DECLARE)
#undef DECLARE
#define DECLARE(name) const Term *name;
  TERM_FIELDS(DECLARE)
#undef DECLARE
};
struct OriginalWork {
  double *values, *rhs, *solution, *response, *reduced;
  int error;
};
DevicePlan UploadPlan(const HostPlan &h, Allocations &allocation) {
  DevicePlan p{};
  p.n = h.full_rows.size() - 1;
  p.auxiliaries = h.aux.size();
  p.core = h.retained.size();
  p.core_nnz = h.core_columns.size();
  p.response_values = h.response_columns.size();
  p.levels = h.aux_bounds.size() - 1;
#define UPLOAD(name) p.name = allocation.Upload(h.name);
  INTEGER_FIELDS(UPLOAD)
  RECIPE_FIELDS(UPLOAD)
  TERM_FIELDS(UPLOAD)
#undef UPLOAD
  return p;
}
__device__ double Coefficient(const double *a, int slot) {
  return slot < 0 ? 0 : a[slot];
}
__device__ void AuxiliaryResponse(DevicePlan p, const double *a,
                                  double *response, Shared &s) {
  for (int level = 0; level < p.levels; ++level) {
    for (int at = p.response_bounds[level] + threadIdx.x;
         at < p.response_bounds[level + 1]; at += Threads) {
      const int index = p.response_order[at];
      const auto recipe = p.response_recipes[index];
      double value = -Coefficient(a, recipe.source);
      for (int j = recipe.begin; j < recipe.begin + recipe.count; ++j) {
        const auto term = p.response_terms[j];
        value = fma(-a[term.coefficient], response[term.operand], value);
      }
      response[index] = value;
      if (!Bounded(value))
        Reject(s, Nonfinite);
    }
    __syncthreads();
  }
}
__device__ void AuxiliaryMatrix(DevicePlan p, const double *a,
                                const double *response, double *reduced,
                                Shared &s) {
  for (int i = threadIdx.x; i < p.core_nnz; i += Threads) {
    const auto recipe = p.core_recipes[i];
    double value = Coefficient(a, recipe.source);
    for (int j = recipe.begin; j < recipe.begin + recipe.count; ++j) {
      const auto term = p.core_terms[j];
      value = fma(a[term.coefficient], response[term.operand], value);
    }
    reduced[i] = value;
    if (!Bounded(value))
      Reject(s, Nonfinite);
  }
  __syncthreads();
}
__global__ void PrepareAuxiliaryMatrix(DevicePlan p, OriginalWork *work) {
  __shared__ Shared s;
  if (threadIdx.x == 0)
    s.error = 0;
  __syncthreads();
  auto &o = *work;
  AuxiliaryResponse(p, o.values, o.response, s);
  AuxiliaryMatrix(p, o.values, o.response, o.reduced, s);
  if (threadIdx.x == 0)
    o.error = s.error;
}
__device__ void AuxiliaryRhs(DevicePlan p, const double *a, const double *rhs,
                             double *offset, double *core_rhs, Shared &s) {
  for (int level = 0; level < p.levels; ++level) {
    for (int at = p.aux_bounds[level] + threadIdx.x;
         at < p.aux_bounds[level + 1]; at += Threads) {
      const int index = p.aux_order[at];
      const auto recipe = p.offset_recipes[index];
      double value = rhs[recipe.source];
      for (int j = recipe.begin; j < recipe.begin + recipe.count; ++j) {
        const auto term = p.offset_terms[j];
        value = fma(-a[term.coefficient], offset[term.operand], value);
      }
      offset[index] = value;
      if (!Bounded(value))
        Reject(s, Nonfinite);
    }
    __syncthreads();
  }
  for (int row = threadIdx.x; row < p.core; row += Threads) {
    const auto recipe = p.rhs_recipes[row];
    double value = rhs[recipe.source];
    for (int j = recipe.begin; j < recipe.begin + recipe.count; ++j) {
      const auto term = p.rhs_terms[j];
      value = fma(-a[term.coefficient], offset[term.operand], value);
    }
    core_rhs[row] = value;
    if (!Bounded(value))
      Reject(s, Nonfinite);
  }
  __syncthreads();
}
__device__ void AuxiliaryRecover(DevicePlan p, const double *a,
                                 const double *rhs, const double *response,
                                 const double *offset, const double *core,
                                 double *full, Shared &s) {
  for (int row = threadIdx.x; row < p.core; row += Threads)
    full[p.retained[row]] = core[row];
  for (int row = threadIdx.x; row < p.auxiliaries; row += Threads) {
    double value = offset[row];
    for (int j = p.response_offsets[row]; j < p.response_offsets[row + 1]; ++j)
      value = fma(response[j], core[p.response_columns[j]], value);
    full[p.aux[row]] = value;
    full[p.branches[row]] = fma(-a[p.gmin_slots[row]], value, rhs[p.aux[row]]);
    if (!Bounded(value) || !Bounded(full[p.branches[row]]))
      Reject(s, Nonfinite);
  }
  __syncthreads();
}
__device__ bool OriginalResidual(DevicePlan p, const double *a, const double *b,
                                 const double *x, double *residual, Shared &s,
                                 bool corrected) {
  double component = 0, normalized = 0, matrix_norm = 0, rhs_norm = 0,
         solution_norm = 0, nonzero = 0;
  for (int row = threadIdx.x; row < p.n; row += Threads) {
    Sum sum;
    sum.Add(b[row]);
    double denominator = fabs(b[row]), scale = 0, row_norm = 0;
    for (int j = p.full_rows[row]; j < p.full_rows[row + 1]; ++j) {
      const double coefficient = a[j], value = x[p.full_columns[j]];
      sum.Product(-coefficient, value);
      denominator += fabs(coefficient * value);
      scale = PositiveMaximum(scale, fabs(coefficient));
      row_norm += fabs(coefficient);
    }
    const double r = sum.Value();
    residual[row] = r;
    if (!Bounded(r) || !(scale > 0) || !Bounded(x[row]))
      Reject(s, Nonfinite);
    if (r != 0)
      nonzero = 1;
    component =
        PositiveMaximum(component, denominator == 0 ? (r == 0 ? 0 : 1e100)
                                                    : fabs(r) / denominator);
    normalized = PositiveMaximum(normalized, fabs(r) / scale);
    matrix_norm = PositiveMaximum(matrix_norm, row_norm / scale);
    rhs_norm = PositiveMaximum(rhs_norm, fabs(b[row]) / scale);
    solution_norm = PositiveMaximum(solution_norm, fabs(x[row]));
  }
  double maxima[]{component, normalized,    matrix_norm,
                  rhs_norm,  solution_norm, nonzero};
  ValidationMaxima(maxima, s);
  const double denominator = maxima[2] * maxima[4] + maxima[3];
  return (corrected || maxima[5] == 0) && maxima[0] <= 1e-5 &&
         (denominator == 0 ? maxima[1] == 0 : maxima[1] / denominator <= 1e-10);
}
__device__ void AuxiliaryFactor(const Model &m, Workspace &w, Shared &s) {
  const auto prepare_start = clock64();
  if (threadIdx.x == 0)
    s.sparse_factor = m.factor_nonzeros > 0;
  __syncthreads();
  if (!s.sparse_factor) {
    DenseFactor(m, w, s);
    return;
  }
  const unsigned factors =
      static_cast<unsigned>(__cvta_generic_to_shared(s.factor));
  const unsigned inverse =
      static_cast<unsigned>(__cvta_generic_to_shared(s.inverse));
  for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
    StoreSharedDouble(factors + i * 8, 0);
  __syncthreads();
  for (int row = threadIdx.x; row < m.n; row += Threads) {
    double scale = 0;
    for (int k = s.matrix_rows[row]; k < s.matrix_rows[row + 1]; ++k)
      scale = PositiveMaximum(scale, fabs(w.jacobian[k]));
    if (!(scale > 0) || !Bounded(scale)) {
      Reject(s, Singular);
      scale = 1;
    }
    w.equil[row] = scale;
    w.inverse_equil[row] = __drcp_rn(scale);
    double row_norm = 0;
    for (int k = s.matrix_rows[row]; k < s.matrix_rows[row + 1]; ++k) {
      const double original = w.jacobian[k];
      const double scaled = isfinite(w.inverse_equil[row])
                                ? original * w.inverse_equil[row]
                                : original / scale;
      row_norm += fabs(original);
      if (original != 0 && scaled == 0)
        Reject(s, Nonfinite);
      StoreSharedDouble(factors + m.factor_input_slots[k] * 8, scaled);
    }
    w.linear_row_norm[row] = isfinite(w.inverse_equil[row])
                                 ? row_norm * w.inverse_equil[row]
                                 : row_norm / scale;
  }
  __syncthreads();
  if (threadIdx.x == 0) {
    s.pivot_failure = 0;
    w.progress.factor_prepare_cycles += clock64() - prepare_start;
  }
  __syncthreads();
  if (threadIdx.x < 32) {
    for (int level = 0; level < m.factor_levels && !s.error; ++level) {
      for (int at = s.factor_level_offsets[level] + threadIdx.x;
           at < s.factor_level_offsets[level + 1]; at += 32) {
        const int slot = s.factor_order[at];
        const auto entry = s.factor_entries[slot];
        double value = SharedDouble(factors + slot * 8);
        for (int j = entry.begin; j < entry.begin + entry.count; ++j) {
          const auto term = s.factor_term[j];
          value = fma(-SharedDouble(factors + term.lower * 8),
                      SharedDouble(factors + term.upper * 8), value);
        }
        if (entry.diagonal >= 0)
          value *= SharedDouble(inverse + entry.diagonal * 8);
        StoreSharedDouble(factors + slot * 8, value);
        if (!Bounded(value))
          atomicExch(&s.pivot_failure, 1);
        if (entry.pivot >= 0) {
          if (!(fabs(value) >= 2.2250738585072014e-308))
            atomicExch(&s.pivot_failure, 1);
          const double reciprocal = __drcp_rn(value);
          StoreSharedDouble(inverse + entry.pivot * 8, reciprocal);
          if (!isfinite(reciprocal))
            atomicExch(&s.pivot_failure, 1);
        }
      }
      __syncwarp();
      if (s.pivot_failure)
        break;
    }
  }
  __syncthreads();
  if (threadIdx.x == 0 && s.pivot_failure)
    s.sparse_factor = false;
  if (threadIdx.x == 0)
    ++w.progress.factors;
  __syncthreads();
  if (!s.sparse_factor && !s.error)
    DenseFactor(m, w, s);
}

__global__ void AuxiliaryMatrixReplay(DevicePlan p, const Model *models,
                                      Workspace *all, OriginalWork *originals,
                                      int iterations) {
  const Model m = models[blockIdx.x];
  Workspace *workspace = all + blockIdx.x;
  auto &o = originals[blockIdx.x];
  __shared__ Shared s;
  auto &w = s.runtime;
  extern __shared__ double probe_storage[];
  if (threadIdx.x == 0) {
    w = *workspace;
    s.error = 0;
    s.factor_valid = false;
    s.active_scale = 0;
    s.factored_scale = -1;
    s.expression_cache_valid = false;
    s.expression_cache_derivatives = false;
    w.progress.output_count = 0;
    s.factor = probe_storage;
    s.triangular = probe_storage + m.factor_nonzeros;
    s.inverse = s.triangular + m.n;
    double *vectors = s.inverse + m.n;
    w.state = vectors + 0 * m.n;
    w.full = vectors + 1 * m.n;
    w.half = vectors + 2 * m.n;
    w.current = vectors + 3 * m.n;
    w.proposed = vectors + 4 * m.n;
    w.delta = vectors + 5 * m.n;
    w.companion_rhs = vectors + 6 * m.n;
    w.affine_rhs = vectors + 7 * m.n;
    w.residual = vectors + 8 * m.n;
    w.row_scale = vectors + 9 * m.n;
    w.solution = vectors + 10 * m.n;
    w.equil = vectors + 11 * m.n;
    w.inverse_equil = vectors + 12 * m.n;
    w.linear_row_norm = vectors + 13 * m.n;
    s.expression_state = vectors + 14 * m.n;
    // Linear correction/forward work finish before the next nonlinear assembly
    // replaces residual/scale. The second half-step result is the final Newton
    // proposal and survives until its error/history checks have consumed it.
    w.correction = w.residual;
    w.work = w.row_scale;
    w.second = w.proposed;
    w.history_current = vectors + 15 * m.n;
    w.history_older = w.history_current + m.reactive;
    w.history_trial = w.history_older + m.reactive;
    w.base = w.history_trial + m.reactive;
    w.jacobian = w.base + m.nnz;
    w.gradients = w.jacobian + m.nnz;
    w.expressions =
        reinterpret_cast<DeviceResult *>(w.gradients + m.dependency_count);
    s.expression_values =
        reinterpret_cast<double *>(w.expressions + m.programs);
    s.expression_adjoints = s.expression_values + m.expression_node_count;
    s.expression_active = reinterpret_cast<unsigned char *>(
        s.expression_adjoints + m.expression_node_count);
    s.factor_columns = reinterpret_cast<int *>(
        (reinterpret_cast<std::uintptr_t>(s.expression_active +
                                          m.expression_node_count) +
         7) &
        ~std::uintptr_t{7});
    s.factor_order = s.factor_columns + m.factor_nonzeros;
    s.factor_level_offsets = s.factor_order + m.factor_nonzeros;
    s.factor_entries = m.factor_entries;
    s.factor_term = m.factor_term;
    auto end = (reinterpret_cast<std::uintptr_t>(s.factor_level_offsets +
                                                 m.factor_levels + 1) +
                7) &
               ~std::uintptr_t{7};
    if (m.shared_factor_metadata) {
      s.factor_entries = reinterpret_cast<const FactorEntry *>(end);
      s.factor_term = reinterpret_cast<const FactorTerm *>(s.factor_entries +
                                                           m.factor_nonzeros);
      end = (reinterpret_cast<std::uintptr_t>(s.factor_term + m.factor_terms) +
             7) &
            ~std::uintptr_t{7};
    }
    s.expression_nodes =
        m.shared_expression_metadata
            ? reinterpret_cast<const PackedExpressionNode *>(end)
            : m.parallel_nodes;
    if (m.shared_expression_metadata)
      end += m.expression_node_count * sizeof(PackedExpressionNode);
    s.matrix_rows =
        m.shared_structure ? reinterpret_cast<const int *>(end) : m.row_offsets;
    s.matrix_columns = m.shared_structure ? s.matrix_rows + m.n + 1 : m.columns;
  }
  __syncthreads();
  if (m.shared_structure) {
    for (int i = threadIdx.x; i <= m.n; i += Threads)
      const_cast<int *>(s.matrix_rows)[i] = m.row_offsets[i];
    for (int i = threadIdx.x; i < m.nnz; i += Threads)
      const_cast<int *>(s.matrix_columns)[i] = m.columns[i];
  }
  for (int i = threadIdx.x; i < m.n; i += Threads) {
    w.state[i] = workspace->state[i];
    if (i < m.reactive) {
      w.history_current[i] = workspace->history_current[i];
      w.history_older[i] = workspace->history_older[i];
      w.history_trial[i] = workspace->history_trial[i];
    }
    s.factor_diagonal[i] = m.factor_diagonal[i];
    s.row_permutation[i] = m.row_permutation[i];
    s.column_permutation[i] = m.column_permutation[i];
    s.forward_rows[i] = m.forward_rows[i];
    s.backward_rows[i] = m.backward_rows[i];
  }
  for (int i = threadIdx.x; i <= m.n; i += Threads) {
    s.factor_rows[i] = m.factor_rows[i];
  }
  for (int i = threadIdx.x; i <= m.forward_levels; i += Threads)
    s.forward_offsets[i] = m.forward_offsets[i];
  for (int i = threadIdx.x; i <= m.backward_levels; i += Threads)
    s.backward_offsets[i] = m.backward_offsets[i];
  for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
    s.factor_columns[i] = m.factor_columns[i];
  for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
    s.factor_order[i] = m.factor_order[i];
  for (int i = threadIdx.x; i <= m.factor_levels; i += Threads)
    s.factor_level_offsets[i] = m.factor_level_offsets[i];
  __syncthreads();
  if (m.shared_factor_metadata) {
    for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
      const_cast<FactorEntry *>(s.factor_entries)[i] = m.factor_entries[i];
    for (int i = threadIdx.x; i < m.factor_terms; i += Threads)
      const_cast<FactorTerm *>(s.factor_term)[i] = m.factor_term[i];
  }
  if (m.shared_expression_metadata)
    for (int index = threadIdx.x; index < m.expression_node_count;
         index += Threads)
      const_cast<PackedExpressionNode *>(s.expression_nodes)[index] =
          m.parallel_nodes[index];
  __syncthreads();

  double *response = reinterpret_cast<double *>(
      (reinterpret_cast<std::uintptr_t>(s.matrix_columns + m.nnz) + 7) &
      ~std::uintptr_t{7});
  double *offset = response + p.response_values, *full = offset + p.auxiliaries,
         *delta = full + p.n, *residual = delta + p.n;
  for (int iteration = 0; iteration < iterations && !s.error; ++iteration) {
    AuxiliaryResponse(p, o.values, response, s);
    AuxiliaryMatrix(p, o.values, response, w.jacobian, s);
    if (s.error)
      break;
    if (threadIdx.x == 0)
      s.factor_valid = false;
    __syncthreads();
    AuxiliaryFactor(m, w, s);
    if (s.error)
      break;
    AuxiliaryRhs(p, o.values, o.rhs, offset, w.affine_rhs, s);
    if (s.error)
      break;
    Triangular(m, w, s, w.affine_rhs, w.solution);
    if (s.error)
      break;
    AuxiliaryRecover(p, o.values, o.rhs, response, offset, w.solution, full, s);
    bool accepted = false;
    for (int refinement = 0; refinement <= 4 && !s.error; ++refinement) {
      accepted = OriginalResidual(p, o.values, o.rhs, full, residual, s,
                                  refinement > 0);
      if (accepted || refinement == 4)
        break;
      AuxiliaryRhs(p, o.values, residual, offset, w.affine_rhs, s);
      if (s.error)
        break;
      Triangular(m, w, s, w.affine_rhs, w.solution);
      if (s.error)
        break;
      AuxiliaryRecover(p, o.values, residual, response, offset, w.solution,
                       delta, s);
      for (int i = threadIdx.x; i < p.n; i += Threads)
        full[i] += delta[i];
      if (threadIdx.x == 0)
        ++w.progress.refinements;
      __syncthreads();
    }
    if (threadIdx.x == 0) {
      if (!accepted && !s.error)
        Reject(s, Invalid);
      if (!s.error)
        ++w.progress.solves;
    }
    __syncthreads();
  }
  if (!s.error)
    for (int i = threadIdx.x; i < p.n; i += Threads)
      o.solution[i] = full[i];
  if (threadIdx.x == 0) {
    w.progress.error = s.error;
    workspace->progress = w.progress;
    o.error = s.error;
  }
}
template <class T> T ProbeChecked(Result<T> result) {
  if (!result.ok())
    throw std::runtime_error(result.error().message);
  return result.TakeValue();
}
struct ProbeSample {
  std::string name;
  CsrMatrix a;
  std::vector<double> b, oracle;
};
std::vector<ProbeSample> ReadProbe(const char *path) {
  std::ifstream input(path);
  std::string magic;
  int n = 0, ports = 0, groups = 0, count = 0;
  input >> magic >> n >> ports >> groups >> count;
  if (!input || magic != "EMI03_SCHUR_REPLAY_1" || n != 185 || ports != 14 ||
      groups != 15 || count != 144)
    throw std::runtime_error("invalid frozen replay");
  int ignored;
  for (int i = 0; i < ports; ++i)
    input >> ignored;
  for (int g = 0; g < groups; ++g) {
    int size = 0;
    input >> size;
    if (size < 1 || size > 64)
      throw std::runtime_error("bad group");
    for (int i = 0; i < size; ++i)
      input >> ignored;
  }
  std::vector<ProbeSample> samples(count);
  for (auto &s : samples) {
    std::size_t nnz = 0;
    input >> s.name >> nnz;
    if (!input || nnz > static_cast<std::size_t>(n * n))
      throw std::runtime_error("bad matrix");
    s.a.rows = s.a.columns = n;
    s.a.row_offsets.resize(n + 1);
    s.a.column_indices.resize(nnz);
    s.a.values.resize(nnz);
    s.b.resize(n);
    s.oracle.resize(n);
    for (auto &x : s.a.row_offsets)
      input >> x;
    for (auto &x : s.a.column_indices)
      input >> x;
    for (auto &x : s.a.values)
      input >> x;
    for (auto &x : s.b)
      input >> x;
    for (auto &x : s.oracle)
      input >> x;
    if (!input)
      throw std::runtime_error("truncated matrix");
    ProbeChecked(ValidateSparseSolution(s.a, s.b, s.oracle));
  }
  return samples;
}
std::size_t ProbePrepare(const ProbeSample &sample, Allocations &allocation,
                         Model &m, Workspace &w) {
  const int n = sample.a.rows;
  MnaSystem system;
  system.g = sample.a;
  system.c.rows = system.c.columns = n;
  system.c.row_offsets.resize(n + 1);
  system.b_dc.resize(n);
  system.b_ac.resize(n);
  for (int i = 0; i < n; ++i)
    system.node_names.push_back("v" + std::to_string(i));
  TranAnalysis analysis{1, 1, 0, false};
  m.n = m.nodes = n;
  m.nnz = sample.a.values.size();
  PrepareFactorPlan(system, analysis, std::vector<double>(n), m, allocation);
  std::cerr << "core_plan " << m.n << " " << m.factor_nonzeros << " "
            << m.factor_levels << " " << m.forward_levels << " "
            << m.backward_levels << "\n";
  m.row_offsets = allocation.Upload(std::vector<int>(
      sample.a.row_offsets.begin(), sample.a.row_offsets.end()));
  m.columns = allocation.Upload(std::vector<int>(
      sample.a.column_indices.begin(), sample.a.column_indices.end()));
  w.state = allocation.Upload(std::vector<double>(n));
  w.affine_rhs = allocation.Upload(sample.b);
  w.jacobian = allocation.Upload(sample.a.values);
  w.solution = allocation.Allocate<double>(n);
  w.factored_jacobian = allocation.Allocate<double>(m.nnz);
  w.lu = allocation.Allocate<double>(n * N);
  w.permutation = allocation.Allocate<int>(n);
  w.last_dynamic_jacobian = nullptr;
  std::size_t bytes =
      ((m.factor_nonzeros + 17 * n + 2 * m.nnz) * sizeof(double) + 7) / 8 * 8 +
      (2 * m.factor_nonzeros + m.factor_levels + 1) * sizeof(int);
  bytes = (bytes + 7) / 8 * 8;
  m.shared_factor_metadata = true;
  m.shared_structure = true;
  bytes = (bytes + m.factor_nonzeros * sizeof(FactorEntry) +
           m.factor_terms * sizeof(FactorTerm) + 7) /
          8 * 8;
  bytes += (n + 1 + m.nnz) * sizeof(int);
  return bytes;
}
HostPlan GeneratedHostPlan() {
  HostPlan p;
  p.full_rows = {
      0,   3,   6,   11,  23,  27,  32,  36,  40,  49,  55,  58,  60,  63,  67,
      79,  83,  88,  92,  95,  104, 107, 109, 112, 116, 119, 122, 131, 134, 137,
      141, 148, 151, 154, 157, 161, 173, 177, 182, 186, 190, 199, 205, 208, 210,
      213, 217, 229, 233, 238, 242, 245, 254, 257, 259, 262, 266, 269, 272, 275,
      278, 282, 289, 292, 295, 298, 303, 306, 310, 313, 315, 317, 319, 321, 323,
      325, 327, 329, 331, 333, 335, 337, 339, 341, 343, 345, 347, 349, 351, 353,
      355, 357, 359, 361, 363, 365, 367, 369, 371, 373, 375, 377, 379, 381, 383,
      385, 387, 389, 391, 393, 394, 397, 399, 402, 405, 407, 409, 411, 414, 417,
      419, 421, 423, 424, 427, 431, 433, 437, 439, 442, 445, 447, 449, 451, 454,
      457, 459, 461, 463, 464, 467, 471, 473, 477, 480, 482, 485, 488, 491, 493,
      495, 499, 501, 503, 507, 511, 514, 517, 520, 522, 524, 528, 530, 532, 536,
      540, 543, 546, 549, 551, 553, 557, 559, 561, 565, 569, 572, 575, 578, 580,
      582, 586, 588, 590, 594, 598};
  p.full_columns = {
      0,   1,   109, 0,   1,   110, 2,   26,  110, 111, 127, 3,   5,   8,   10,
      11,  12,  72,  77,  78,  111, 114, 115, 4,   5,   6,   112, 3,   4,   5,
      8,   114, 4,   6,   24,  112, 7,   8,   9,   113, 3,   5,   7,   8,   13,
      72,  77,  78,  113, 7,   9,   26,  27,  116, 121, 3,   10,  114, 3,   11,
      3,   12,  115, 3,   8,   13,  115, 14,  16,  19,  20,  21,  22,  82,  87,
      88,  116, 119, 120, 15,  16,  17,  117, 14,  15,  16,  19,  119, 15,  17,
      25,  117, 18,  19,  118, 14,  16,  18,  19,  23,  82,  87,  88,  118, 14,
      20,  119, 14,  21,  14,  22,  120, 14,  19,  23,  120, 6,   24,  121, 17,
      25,  122, 2,   9,   26,  31,  34,  41,  62,  65,  68,  9,   27,  123, 28,
      29,  123, 28,  29,  30,  124, 29,  30,  31,  61,  66,  124, 125, 26,  30,
      31,  32,  33,  125, 32,  33,  126, 26,  34,  67,  126, 35,  37,  40,  42,
      43,  44,  92,  97,  98,  127, 130, 131, 36,  37,  38,  128, 35,  36,  37,
      40,  130, 36,  38,  56,  128, 39,  40,  41,  129, 35,  37,  39,  40,  45,
      92,  97,  98,  129, 26,  39,  41,  58,  132, 137, 35,  42,  130, 35,  43,
      35,  44,  131, 35,  40,  45,  131, 46,  48,  51,  52,  53,  54,  102, 107,
      108, 132, 135, 136, 47,  48,  49,  133, 46,  47,  48,  51,  135, 47,  49,
      57,  133, 50,  51,  134, 46,  48,  50,  51,  55,  102, 107, 108, 134, 46,
      52,  135, 46,  53,  46,  54,  136, 46,  51,  55,  136, 38,  56,  137, 49,
      57,  138, 41,  58,  139, 59,  60,  139, 59,  60,  61,  140, 30,  60,  61,
      62,  66,  140, 141, 26,  61,  62,  63,  64,  141, 63,  64,  142, 26,  65,
      67,  142, 143, 30,  61,  66,  34,  65,  67,  143, 26,  68,  144, 69,  145,
      70,  146, 71,  147, 72,  148, 73,  149, 74,  150, 75,  151, 76,  152, 77,
      153, 78,  154, 79,  155, 80,  156, 81,  157, 82,  158, 83,  159, 84,  160,
      85,  161, 86,  162, 87,  163, 88,  164, 89,  165, 90,  166, 91,  167, 92,
      168, 93,  169, 94,  170, 95,  171, 96,  172, 97,  173, 98,  174, 99,  175,
      100, 176, 101, 177, 102, 178, 103, 179, 104, 180, 105, 181, 106, 182, 107,
      183, 108, 184, 0,   1,   2,   110, 2,   3,   4,   6,   112, 7,   8,   113,
      5,   10,  12,  13,  9,   14,  15,  17,  117, 18,  19,  118, 16,  20,  22,
      23,  9,   24,  25,  27,  28,  123, 29,  30,  124, 140, 30,  32,  33,  34,
      126, 142, 2,   35,  36,  38,  128, 39,  40,  129, 37,  42,  44,  45,  41,
      46,  47,  49,  133, 50,  51,  134, 48,  52,  54,  55,  41,  56,  57,  58,
      59,  139, 60,  61,  124, 140, 61,  63,  64,  65,  126, 142, 65,  67,  143,
      68,  144, 3,   8,   69,  5,   8,   70,  3,   5,   71,  69,  72,  69,  73,
      69,  73,  74,  75,  70,  75,  71,  76,  69,  70,  74,  77,  69,  71,  76,
      78,  14,  19,  79,  16,  19,  80,  14,  16,  81,  79,  82,  79,  83,  79,
      83,  84,  85,  80,  85,  81,  86,  79,  80,  84,  87,  79,  81,  86,  88,
      35,  40,  89,  37,  40,  90,  35,  37,  91,  89,  92,  89,  93,  89,  93,
      94,  95,  90,  95,  91,  96,  89,  90,  94,  97,  89,  91,  96,  98,  46,
      51,  99,  48,  51,  100, 46,  48,  101, 99,  102, 99,  103, 99,  103, 104,
      105, 100, 105, 101, 106, 99,  100, 104, 107, 99,  101, 106, 108};
  p.aux = {69, 70, 71, 72,  73,  75,  74,  76,  77,  78,  79,  80, 81, 82,
           83, 85, 84, 86,  87,  88,  89,  90,  91,  92,  93,  95, 94, 96,
           97, 98, 99, 100, 101, 102, 103, 105, 104, 106, 107, 108};
  p.branches = {145, 146, 147, 148, 149, 151, 150, 152, 153, 154,
                155, 156, 157, 158, 159, 161, 160, 162, 163, 164,
                165, 166, 167, 168, 169, 171, 170, 172, 173, 174,
                175, 176, 177, 178, 179, 181, 180, 182, 183, 184};
  p.retained = {0,   1,   2,   3,   4,   5,   6,   7,   8,   9,   10,  11,
                12,  13,  14,  15,  16,  17,  18,  19,  20,  21,  22,  23,
                24,  25,  26,  27,  28,  29,  30,  31,  32,  33,  34,  35,
                36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,
                48,  49,  50,  51,  52,  53,  54,  55,  56,  57,  58,  59,
                60,  61,  62,  63,  64,  65,  66,  67,  68,  109, 110, 111,
                112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123,
                124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135,
                136, 137, 138, 139, 140, 141, 142, 143, 144};
  p.response_offsets = {0,  2,  4,  6,  8,  10, 12, 15, 17, 20, 23, 25, 27, 29,
                        31, 33, 35, 38, 40, 43, 46, 48, 50, 52, 54, 56, 58, 61,
                        63, 66, 69, 71, 73, 75, 77, 79, 81, 84, 86, 89, 92};
  p.response_columns = {3,  8,  5,  8,  3,  5,  3,  8,  3,  8,  5,  8,  3,  5,
                        8,  3,  5,  3,  5,  8,  3,  5,  8,  14, 19, 16, 19, 14,
                        16, 14, 19, 14, 19, 16, 19, 14, 16, 19, 14, 16, 14, 16,
                        19, 14, 16, 19, 35, 40, 37, 40, 35, 37, 35, 40, 35, 40,
                        37, 40, 35, 37, 40, 35, 37, 35, 37, 40, 35, 37, 40, 46,
                        51, 48, 51, 46, 48, 46, 51, 46, 51, 48, 51, 46, 48, 51,
                        46, 48, 46, 48, 51, 46, 48, 51};
  p.response_recipes = {
      {482, 0, 0},  {483, 0, 0},  {485, 0, 0},  {486, 0, 0},  {488, 0, 0},
      {489, 0, 0},  {-1, 0, 1},   {-1, 1, 1},   {-1, 2, 1},   {-1, 3, 1},
      {-1, 4, 1},   {-1, 5, 1},   {-1, 6, 2},   {-1, 8, 1},   {-1, 9, 3},
      {-1, 12, 1},  {-1, 13, 1},  {-1, 14, 2},  {-1, 16, 2},  {-1, 18, 3},
      {-1, 21, 3},  {-1, 24, 2},  {-1, 26, 1},  {511, 27, 0}, {512, 27, 0},
      {514, 27, 0}, {515, 27, 0}, {517, 27, 0}, {518, 27, 0}, {-1, 27, 1},
      {-1, 28, 1},  {-1, 29, 1},  {-1, 30, 1},  {-1, 31, 1},  {-1, 32, 1},
      {-1, 33, 2},  {-1, 35, 1},  {-1, 36, 3},  {-1, 39, 1},  {-1, 40, 1},
      {-1, 41, 2},  {-1, 43, 2},  {-1, 45, 3},  {-1, 48, 3},  {-1, 51, 2},
      {-1, 53, 1},  {540, 54, 0}, {541, 54, 0}, {543, 54, 0}, {544, 54, 0},
      {546, 54, 0}, {547, 54, 0}, {-1, 54, 1},  {-1, 55, 1},  {-1, 56, 1},
      {-1, 57, 1},  {-1, 58, 1},  {-1, 59, 1},  {-1, 60, 2},  {-1, 62, 1},
      {-1, 63, 3},  {-1, 66, 1},  {-1, 67, 1},  {-1, 68, 2},  {-1, 70, 2},
      {-1, 72, 3},  {-1, 75, 3},  {-1, 78, 2},  {-1, 80, 1},  {569, 81, 0},
      {570, 81, 0}, {572, 81, 0}, {573, 81, 0}, {575, 81, 0}, {576, 81, 0},
      {-1, 81, 1},  {-1, 82, 1},  {-1, 83, 1},  {-1, 84, 1},  {-1, 85, 1},
      {-1, 86, 1},  {-1, 87, 2},  {-1, 89, 1},  {-1, 90, 3},  {-1, 93, 1},
      {-1, 94, 1},  {-1, 95, 2},  {-1, 97, 2},  {-1, 99, 3},  {-1, 102, 3},
      {-1, 105, 2}, {-1, 107, 1}};
  p.response_terms = {
      {491, 0},  {491, 1},  {493, 0},  {493, 1},  {499, 2},  {499, 3},
      {495, 0},  {496, 8},  {498, 10}, {495, 1},  {496, 9},  {498, 11},
      {501, 4},  {501, 5},  {503, 0},  {505, 12}, {504, 2},  {505, 13},
      {503, 1},  {504, 3},  {505, 14}, {507, 0},  {508, 4},  {509, 15},
      {508, 5},  {509, 16}, {507, 1},  {520, 23}, {520, 24}, {522, 23},
      {522, 24}, {528, 25}, {528, 26}, {524, 23}, {525, 31}, {527, 33},
      {524, 24}, {525, 32}, {527, 34}, {530, 27}, {530, 28}, {532, 23},
      {534, 35}, {533, 25}, {534, 36}, {532, 24}, {533, 26}, {534, 37},
      {536, 23}, {537, 27}, {538, 38}, {537, 28}, {538, 39}, {536, 24},
      {549, 46}, {549, 47}, {551, 46}, {551, 47}, {557, 48}, {557, 49},
      {553, 46}, {554, 54}, {556, 56}, {553, 47}, {554, 55}, {556, 57},
      {559, 50}, {559, 51}, {561, 46}, {563, 58}, {562, 48}, {563, 59},
      {561, 47}, {562, 49}, {563, 60}, {565, 46}, {566, 50}, {567, 61},
      {566, 51}, {567, 62}, {565, 47}, {578, 69}, {578, 70}, {580, 69},
      {580, 70}, {586, 71}, {586, 72}, {582, 69}, {583, 77}, {585, 79},
      {582, 70}, {583, 78}, {585, 80}, {588, 73}, {588, 74}, {590, 69},
      {592, 81}, {591, 71}, {592, 82}, {590, 70}, {591, 72}, {592, 83},
      {594, 69}, {595, 73}, {596, 84}, {595, 74}, {596, 85}, {594, 70}};
  p.offset_recipes = {
      {145, 0, 0},  {146, 0, 0},  {147, 0, 0},  {148, 0, 1},  {149, 1, 1},
      {151, 2, 1},  {150, 3, 3},  {152, 6, 1},  {153, 7, 3},  {154, 10, 3},
      {155, 13, 0}, {156, 13, 0}, {157, 13, 0}, {158, 13, 1}, {159, 14, 1},
      {161, 15, 1}, {160, 16, 3}, {162, 19, 1}, {163, 20, 3}, {164, 23, 3},
      {165, 26, 0}, {166, 26, 0}, {167, 26, 0}, {168, 26, 1}, {169, 27, 1},
      {171, 28, 1}, {170, 29, 3}, {172, 32, 1}, {173, 33, 3}, {174, 36, 3},
      {175, 39, 0}, {176, 39, 0}, {177, 39, 0}, {178, 39, 1}, {179, 40, 1},
      {181, 41, 1}, {180, 42, 3}, {182, 45, 1}, {183, 46, 3}, {184, 49, 3}};
  p.offset_terms = {
      {491, 0},  {493, 0},  {499, 1},  {495, 0},  {496, 4},  {498, 5},
      {501, 2},  {503, 0},  {504, 1},  {505, 6},  {507, 0},  {508, 2},
      {509, 7},  {520, 10}, {522, 10}, {528, 11}, {524, 10}, {525, 14},
      {527, 15}, {530, 12}, {532, 10}, {533, 11}, {534, 16}, {536, 10},
      {537, 12}, {538, 17}, {549, 20}, {551, 20}, {557, 21}, {553, 20},
      {554, 24}, {556, 25}, {559, 22}, {561, 20}, {562, 21}, {563, 26},
      {565, 20}, {566, 22}, {567, 27}, {578, 30}, {580, 30}, {586, 31},
      {582, 30}, {583, 34}, {585, 35}, {588, 32}, {590, 30}, {591, 31},
      {592, 36}, {594, 30}, {595, 32}, {596, 37}};
  p.core_rows = {0,   3,   6,   11,  20,  24,  29,  33,  37,  43,  49,  52,
                 54,  57,  61,  70,  74,  79,  83,  86,  92,  95,  97,  100,
                 104, 107, 110, 119, 122, 125, 129, 136, 139, 142, 145, 149,
                 158, 162, 167, 171, 175, 181, 187, 190, 192, 195, 199, 208,
                 212, 217, 221, 224, 230, 233, 235, 238, 242, 245, 248, 251,
                 254, 258, 265, 268, 271, 274, 279, 282, 286, 289, 290, 293,
                 295, 298, 301, 303, 305, 307, 310, 313, 315, 317, 319, 320,
                 323, 327, 329, 333, 335, 338, 341, 343, 345, 347, 350, 353,
                 355, 357, 359, 360, 363, 367, 369, 373, 376, 378};
  p.core_columns = {
      0,   1,   69, 0,  1,   70,  2,   26,  70,  71, 87, 3,  5,   8,   10,  11,
      12,  71,  74, 75, 4,   5,   6,   72,  3,   4,  5,  8,  74,  4,   6,   24,
      72,  7,   8,  9,  73,  3,   5,   7,   8,   13, 73, 7,  9,   26,  27,  76,
      81,  3,   10, 74, 3,   11,  3,   12,  75,  3,  8,  13, 75,  14,  16,  19,
      20,  21,  22, 76, 79,  80,  15,  16,  17,  77, 14, 15, 16,  19,  79,  15,
      17,  25,  77, 18, 19,  78,  14,  16,  18,  19, 23, 78, 14,  20,  79,  14,
      21,  14,  22, 80, 14,  19,  23,  80,  6,   24, 81, 17, 25,  82,  2,   9,
      26,  31,  34, 41, 62,  65,  68,  9,   27,  83, 28, 29, 83,  28,  29,  30,
      84,  29,  30, 31, 61,  66,  84,  85,  26,  30, 31, 32, 33,  85,  32,  33,
      86,  26,  34, 67, 86,  35,  37,  40,  42,  43, 44, 87, 90,  91,  36,  37,
      38,  88,  35, 36, 37,  40,  90,  36,  38,  56, 88, 39, 40,  41,  89,  35,
      37,  39,  40, 45, 89,  26,  39,  41,  58,  92, 97, 35, 42,  90,  35,  43,
      35,  44,  91, 35, 40,  45,  91,  46,  48,  51, 52, 53, 54,  92,  95,  96,
      47,  48,  49, 93, 46,  47,  48,  51,  95,  47, 49, 57, 93,  50,  51,  94,
      46,  48,  50, 51, 55,  94,  46,  52,  95,  46, 53, 46, 54,  96,  46,  51,
      55,  96,  38, 56, 97,  49,  57,  98,  41,  58, 99, 59, 60,  99,  59,  60,
      61,  100, 30, 60, 61,  62,  66,  100, 101, 26, 61, 62, 63,  64,  101, 63,
      64,  102, 26, 65, 67,  102, 103, 30,  61,  66, 34, 65, 67,  103, 26,  68,
      104, 0,   1,  2,  70,  2,   3,   4,   6,   72, 7,  8,  73,  5,   10,  12,
      13,  9,   14, 15, 17,  77,  18,  19,  78,  16, 20, 22, 23,  9,   24,  25,
      27,  28,  83, 29, 30,  84,  100, 30,  32,  33, 34, 86, 102, 2,   35,  36,
      38,  88,  39, 40, 89,  37,  42,  44,  45,  41, 46, 47, 49,  93,  50,  51,
      94,  48,  52, 54, 55,  41,  56,  57,  58,  59, 99, 60, 61,  84,  100, 61,
      63,  64,  65, 86, 102, 65,  67,  103, 68,  104};
  p.core_recipes = {
      {0, 0, 0},    {1, 0, 0},    {2, 0, 0},    {3, 0, 0},    {4, 0, 0},
      {5, 0, 0},    {6, 0, 0},    {7, 0, 0},    {8, 0, 0},    {9, 0, 0},
      {10, 0, 0},   {11, 0, 3},   {12, 3, 2},   {13, 5, 3},   {14, 8, 0},
      {15, 8, 0},   {16, 8, 0},   {20, 8, 0},   {21, 8, 0},   {22, 8, 0},
      {23, 8, 0},   {24, 8, 0},   {25, 8, 0},   {26, 8, 0},   {27, 8, 0},
      {28, 8, 0},   {29, 8, 0},   {30, 8, 0},   {31, 8, 0},   {32, 8, 0},
      {33, 8, 0},   {34, 8, 0},   {35, 8, 0},   {36, 8, 0},   {37, 8, 0},
      {38, 8, 0},   {39, 8, 0},   {40, 8, 3},   {41, 11, 2},  {42, 13, 0},
      {43, 13, 3},  {44, 16, 0},  {48, 16, 0},  {49, 16, 0},  {50, 16, 0},
      {51, 16, 0},  {52, 16, 0},  {53, 16, 0},  {54, 16, 0},  {55, 16, 0},
      {56, 16, 0},  {57, 16, 0},  {58, 16, 0},  {59, 16, 0},  {60, 16, 0},
      {61, 16, 0},  {62, 16, 0},  {63, 16, 0},  {64, 16, 0},  {65, 16, 0},
      {66, 16, 0},  {67, 16, 3},  {68, 19, 2},  {69, 21, 3},  {70, 24, 0},
      {71, 24, 0},  {72, 24, 0},  {76, 24, 0},  {77, 24, 0},  {78, 24, 0},
      {79, 24, 0},  {80, 24, 0},  {81, 24, 0},  {82, 24, 0},  {83, 24, 0},
      {84, 24, 0},  {85, 24, 0},  {86, 24, 0},  {87, 24, 0},  {88, 24, 0},
      {89, 24, 0},  {90, 24, 0},  {91, 24, 0},  {92, 24, 0},  {93, 24, 0},
      {94, 24, 0},  {95, 24, 3},  {96, 27, 2},  {97, 29, 0},  {98, 29, 3},
      {99, 32, 0},  {103, 32, 0}, {104, 32, 0}, {105, 32, 0}, {106, 32, 0},
      {107, 32, 0}, {108, 32, 0}, {109, 32, 0}, {110, 32, 0}, {111, 32, 0},
      {112, 32, 0}, {113, 32, 0}, {114, 32, 0}, {115, 32, 0}, {116, 32, 0},
      {117, 32, 0}, {118, 32, 0}, {119, 32, 0}, {120, 32, 0}, {121, 32, 0},
      {122, 32, 0}, {123, 32, 0}, {124, 32, 0}, {125, 32, 0}, {126, 32, 0},
      {127, 32, 0}, {128, 32, 0}, {129, 32, 0}, {130, 32, 0}, {131, 32, 0},
      {132, 32, 0}, {133, 32, 0}, {134, 32, 0}, {135, 32, 0}, {136, 32, 0},
      {137, 32, 0}, {138, 32, 0}, {139, 32, 0}, {140, 32, 0}, {141, 32, 0},
      {142, 32, 0}, {143, 32, 0}, {144, 32, 0}, {145, 32, 0}, {146, 32, 0},
      {147, 32, 0}, {148, 32, 0}, {149, 32, 0}, {150, 32, 0}, {151, 32, 0},
      {152, 32, 0}, {153, 32, 0}, {154, 32, 0}, {155, 32, 0}, {156, 32, 0},
      {157, 32, 0}, {158, 32, 0}, {159, 32, 0}, {160, 32, 0}, {161, 32, 3},
      {162, 35, 2}, {163, 37, 3}, {164, 40, 0}, {165, 40, 0}, {166, 40, 0},
      {170, 40, 0}, {171, 40, 0}, {172, 40, 0}, {173, 40, 0}, {174, 40, 0},
      {175, 40, 0}, {176, 40, 0}, {177, 40, 0}, {178, 40, 0}, {179, 40, 0},
      {180, 40, 0}, {181, 40, 0}, {182, 40, 0}, {183, 40, 0}, {184, 40, 0},
      {185, 40, 0}, {186, 40, 0}, {187, 40, 0}, {188, 40, 0}, {189, 40, 0},
      {190, 40, 3}, {191, 43, 2}, {192, 45, 0}, {193, 45, 3}, {194, 48, 0},
      {198, 48, 0}, {199, 48, 0}, {200, 48, 0}, {201, 48, 0}, {202, 48, 0},
      {203, 48, 0}, {204, 48, 0}, {205, 48, 0}, {206, 48, 0}, {207, 48, 0},
      {208, 48, 0}, {209, 48, 0}, {210, 48, 0}, {211, 48, 0}, {212, 48, 0},
      {213, 48, 0}, {214, 48, 0}, {215, 48, 0}, {216, 48, 0}, {217, 48, 3},
      {218, 51, 2}, {219, 53, 3}, {220, 56, 0}, {221, 56, 0}, {222, 56, 0},
      {226, 56, 0}, {227, 56, 0}, {228, 56, 0}, {229, 56, 0}, {230, 56, 0},
      {231, 56, 0}, {232, 56, 0}, {233, 56, 0}, {234, 56, 0}, {235, 56, 0},
      {236, 56, 0}, {237, 56, 0}, {238, 56, 0}, {239, 56, 0}, {240, 56, 0},
      {241, 56, 0}, {242, 56, 0}, {243, 56, 0}, {244, 56, 0}, {245, 56, 3},
      {246, 59, 2}, {247, 61, 0}, {248, 61, 3}, {249, 64, 0}, {253, 64, 0},
      {254, 64, 0}, {255, 64, 0}, {256, 64, 0}, {257, 64, 0}, {258, 64, 0},
      {259, 64, 0}, {260, 64, 0}, {261, 64, 0}, {262, 64, 0}, {263, 64, 0},
      {264, 64, 0}, {265, 64, 0}, {266, 64, 0}, {267, 64, 0}, {268, 64, 0},
      {269, 64, 0}, {270, 64, 0}, {271, 64, 0}, {272, 64, 0}, {273, 64, 0},
      {274, 64, 0}, {275, 64, 0}, {276, 64, 0}, {277, 64, 0}, {278, 64, 0},
      {279, 64, 0}, {280, 64, 0}, {281, 64, 0}, {282, 64, 0}, {283, 64, 0},
      {284, 64, 0}, {285, 64, 0}, {286, 64, 0}, {287, 64, 0}, {288, 64, 0},
      {289, 64, 0}, {290, 64, 0}, {291, 64, 0}, {292, 64, 0}, {293, 64, 0},
      {294, 64, 0}, {295, 64, 0}, {296, 64, 0}, {297, 64, 0}, {298, 64, 0},
      {299, 64, 0}, {300, 64, 0}, {301, 64, 0}, {302, 64, 0}, {303, 64, 0},
      {304, 64, 0}, {305, 64, 0}, {306, 64, 0}, {307, 64, 0}, {308, 64, 0},
      {309, 64, 0}, {310, 64, 0}, {311, 64, 0}, {312, 64, 0}, {393, 64, 0},
      {394, 64, 0}, {395, 64, 0}, {396, 64, 0}, {397, 64, 0}, {398, 64, 0},
      {399, 64, 0}, {400, 64, 0}, {401, 64, 0}, {402, 64, 0}, {403, 64, 0},
      {404, 64, 0}, {405, 64, 0}, {406, 64, 0}, {407, 64, 0}, {408, 64, 0},
      {409, 64, 0}, {410, 64, 0}, {411, 64, 0}, {412, 64, 0}, {413, 64, 0},
      {414, 64, 0}, {415, 64, 0}, {416, 64, 0}, {417, 64, 0}, {418, 64, 0},
      {419, 64, 0}, {420, 64, 0}, {421, 64, 0}, {422, 64, 0}, {423, 64, 0},
      {424, 64, 0}, {425, 64, 0}, {426, 64, 0}, {427, 64, 0}, {428, 64, 0},
      {429, 64, 0}, {430, 64, 0}, {431, 64, 0}, {432, 64, 0}, {433, 64, 0},
      {434, 64, 0}, {435, 64, 0}, {436, 64, 0}, {437, 64, 0}, {438, 64, 0},
      {439, 64, 0}, {440, 64, 0}, {441, 64, 0}, {442, 64, 0}, {443, 64, 0},
      {444, 64, 0}, {445, 64, 0}, {446, 64, 0}, {447, 64, 0}, {448, 64, 0},
      {449, 64, 0}, {450, 64, 0}, {451, 64, 0}, {452, 64, 0}, {453, 64, 0},
      {454, 64, 0}, {455, 64, 0}, {456, 64, 0}, {457, 64, 0}, {458, 64, 0},
      {459, 64, 0}, {460, 64, 0}, {461, 64, 0}, {462, 64, 0}, {463, 64, 0},
      {464, 64, 0}, {465, 64, 0}, {466, 64, 0}, {467, 64, 0}, {468, 64, 0},
      {469, 64, 0}, {470, 64, 0}, {471, 64, 0}, {472, 64, 0}, {473, 64, 0},
      {474, 64, 0}, {475, 64, 0}, {476, 64, 0}, {477, 64, 0}, {478, 64, 0},
      {479, 64, 0}, {480, 64, 0}, {481, 64, 0}};
  p.core_terms = {
      {17, 6},   {18, 17},  {19, 20},  {18, 18},  {19, 21},  {17, 7},
      {18, 19},  {19, 22},  {45, 6},   {46, 17},  {47, 20},  {46, 18},
      {47, 21},  {45, 7},   {46, 19},  {47, 22},  {73, 29},  {74, 40},
      {75, 43},  {74, 41},  {75, 44},  {73, 30},  {74, 42},  {75, 45},
      {100, 29}, {101, 40}, {102, 43}, {101, 41}, {102, 44}, {100, 30},
      {101, 42}, {102, 45}, {167, 52}, {168, 63}, {169, 66}, {168, 64},
      {169, 67}, {167, 53}, {168, 65}, {169, 68}, {195, 52}, {196, 63},
      {197, 66}, {196, 64}, {197, 67}, {195, 53}, {196, 65}, {197, 68},
      {223, 75}, {224, 86}, {225, 89}, {224, 87}, {225, 90}, {223, 76},
      {224, 88}, {225, 91}, {250, 75}, {251, 86}, {252, 89}, {251, 87},
      {252, 90}, {250, 76}, {251, 88}, {252, 91}};
  p.rhs_recipes = {
      {0, 0, 0},    {1, 0, 0},    {2, 0, 0},    {3, 0, 3},    {4, 3, 0},
      {5, 3, 0},    {6, 3, 0},    {7, 3, 0},    {8, 3, 3},    {9, 6, 0},
      {10, 6, 0},   {11, 6, 0},   {12, 6, 0},   {13, 6, 0},   {14, 6, 3},
      {15, 9, 0},   {16, 9, 0},   {17, 9, 0},   {18, 9, 0},   {19, 9, 3},
      {20, 12, 0},  {21, 12, 0},  {22, 12, 0},  {23, 12, 0},  {24, 12, 0},
      {25, 12, 0},  {26, 12, 0},  {27, 12, 0},  {28, 12, 0},  {29, 12, 0},
      {30, 12, 0},  {31, 12, 0},  {32, 12, 0},  {33, 12, 0},  {34, 12, 0},
      {35, 12, 3},  {36, 15, 0},  {37, 15, 0},  {38, 15, 0},  {39, 15, 0},
      {40, 15, 3},  {41, 18, 0},  {42, 18, 0},  {43, 18, 0},  {44, 18, 0},
      {45, 18, 0},  {46, 18, 3},  {47, 21, 0},  {48, 21, 0},  {49, 21, 0},
      {50, 21, 0},  {51, 21, 3},  {52, 24, 0},  {53, 24, 0},  {54, 24, 0},
      {55, 24, 0},  {56, 24, 0},  {57, 24, 0},  {58, 24, 0},  {59, 24, 0},
      {60, 24, 0},  {61, 24, 0},  {62, 24, 0},  {63, 24, 0},  {64, 24, 0},
      {65, 24, 0},  {66, 24, 0},  {67, 24, 0},  {68, 24, 0},  {109, 24, 0},
      {110, 24, 0}, {111, 24, 0}, {112, 24, 0}, {113, 24, 0}, {114, 24, 0},
      {115, 24, 0}, {116, 24, 0}, {117, 24, 0}, {118, 24, 0}, {119, 24, 0},
      {120, 24, 0}, {121, 24, 0}, {122, 24, 0}, {123, 24, 0}, {124, 24, 0},
      {125, 24, 0}, {126, 24, 0}, {127, 24, 0}, {128, 24, 0}, {129, 24, 0},
      {130, 24, 0}, {131, 24, 0}, {132, 24, 0}, {133, 24, 0}, {134, 24, 0},
      {135, 24, 0}, {136, 24, 0}, {137, 24, 0}, {138, 24, 0}, {139, 24, 0},
      {140, 24, 0}, {141, 24, 0}, {142, 24, 0}, {143, 24, 0}, {144, 24, 0}};
  p.rhs_terms = {{17, 3},   {18, 8},   {19, 9},   {45, 3},   {46, 8},
                 {47, 9},   {73, 13},  {74, 18},  {75, 19},  {100, 13},
                 {101, 18}, {102, 19}, {167, 23}, {168, 28}, {169, 29},
                 {195, 23}, {196, 28}, {197, 29}, {223, 33}, {224, 38},
                 {225, 39}, {250, 33}, {251, 38}, {252, 39}};
  p.aux_order = {0, 1, 2,  10, 11, 12, 20, 21, 22, 30, 31, 32, 3,  4,
                 5, 7, 13, 14, 15, 17, 23, 24, 25, 27, 33, 34, 35, 37,
                 6, 9, 16, 19, 26, 29, 36, 39, 8,  18, 28, 38};
  p.aux_bounds = {0, 12, 28, 36, 40};
  p.response_order = {0,  1,  2,  3,  4,  5,  23, 24, 25, 26, 27, 28, 46, 47,
                      48, 49, 50, 51, 69, 70, 71, 72, 73, 74, 6,  7,  8,  9,
                      10, 11, 15, 16, 29, 30, 31, 32, 33, 34, 38, 39, 52, 53,
                      54, 55, 56, 57, 61, 62, 75, 76, 77, 78, 79, 80, 84, 85,
                      12, 13, 14, 20, 21, 22, 35, 36, 37, 43, 44, 45, 58, 59,
                      60, 66, 67, 68, 81, 82, 83, 89, 90, 91, 17, 18, 19, 40,
                      41, 42, 63, 64, 65, 86, 87, 88};
  p.response_bounds = {0, 24, 56, 80, 92};
  p.gmin_slots = {313, 315, 317, 319, 321, 325, 323, 327, 329, 331,
                  333, 335, 337, 339, 341, 345, 343, 347, 349, 351,
                  353, 355, 357, 359, 361, 365, 363, 367, 369, 371,
                  373, 375, 377, 379, 381, 385, 383, 387, 389, 391};
  return p;
}
void CheckAuxiliaryStructure(const HostPlan &h, const ProbeSample &sample) {
  const auto &a = sample.a;
  if (std::vector<int>(a.row_offsets.begin(), a.row_offsets.end()) !=
          h.full_rows ||
      std::vector<int>(a.column_indices.begin(), a.column_indices.end()) !=
          h.full_columns)
    throw std::runtime_error(
        "auxiliary probe requires the frozen structural pattern");
  const auto dense = a.ToDense();
  const int n = a.rows;
  for (std::size_t i = 0; i < h.aux.size(); ++i) {
    const int node = h.aux[i], branch = h.branches[i];
    if (dense[node * n + branch] != 1 || dense[branch * n + node] != 1)
      throw std::runtime_error("driver identity coefficient changed");
    for (int j = 0; j < n; ++j) {
      if (j != node && j != branch && dense[node * n + j] != 0)
        throw std::runtime_error("coupled auxiliary node");
      if (j != node && dense[j * n + branch] != 0)
        throw std::runtime_error(
            "driver current used outside isolated equation");
    }
    for (std::size_t j = i + 1; j < h.aux.size(); ++j)
      if (dense[branch * n + h.aux[j]] != 0)
        throw std::runtime_error("nontriangular auxiliary dependency");
  }
}
std::size_t PrepareAuxiliary(const HostPlan &h, DevicePlan p,
                             const ProbeSample &sample, Allocations &allocation,
                             Model &m, Workspace &workspace,
                             OriginalWork &original) {
  CheckAuxiliaryStructure(h, sample);
  original.values = allocation.Upload(sample.a.values);
  original.rhs = allocation.Upload(sample.b);
  original.solution = allocation.Allocate<double>(p.n);
  original.response = allocation.Allocate<double>(p.response_values);
  original.reduced = allocation.Allocate<double>(p.core_nnz);
  original.error = 0;
  auto *device = allocation.Upload(std::vector<OriginalWork>{original});
  PrepareAuxiliaryMatrix<<<1, Threads, 0, allocation.stream()>>>(p, device);
  CheckCuda(cudaGetLastError(), "auxiliary reduction setup");
  allocation.Copy(&original, device, sizeof(original), cudaMemcpyDeviceToHost);
  if (original.error)
    throw std::runtime_error("auxiliary matrix construction failed");
  ProbeSample core;
  core.name = sample.name;
  core.a.rows = core.a.columns = p.core;
  core.a.row_offsets =
      std::vector<std::size_t>(h.core_rows.begin(), h.core_rows.end());
  core.a.column_indices =
      std::vector<std::size_t>(h.core_columns.begin(), h.core_columns.end());
  core.a.values.resize(p.core_nnz);
  core.b.resize(p.core);
  core.oracle.resize(p.core);
  allocation.Copy(core.a.values.data(), original.reduced,
                  p.core_nnz * sizeof(double), cudaMemcpyDeviceToHost);
  auto bytes = ProbePrepare(core, allocation, m, workspace);
  return (bytes + 7) / 8 * 8 +
         (p.response_values + p.auxiliaries + 3 * p.n) * sizeof(double);
}
void CheckFullSolution(const ProbeSample &sample, const OriginalWork &o,
                       Allocations &allocation, bool zero) {
  if (o.error)
    throw std::runtime_error(sample.name + " auxiliary GPU error " +
                             std::to_string(o.error));
  std::vector<double> x(sample.a.rows);
  allocation.Copy(x.data(), o.solution, x.size() * sizeof(double),
                  cudaMemcpyDeviceToHost);
  auto rhs = sample.b;
  if (zero)
    std::fill(rhs.begin(), rhs.end(), 0);
  const double error = ProbeChecked(ValidateSparseSolution(sample.a, rhs, x));
  double difference = 0, norm = 1;
  for (std::size_t i = 0; i < x.size(); ++i) {
    const double oracle = zero ? 0 : sample.oracle[i];
    difference = std::max(difference, std::abs(x[i] - oracle));
    norm = std::max(norm, std::abs(oracle));
  }
  if (difference / norm > 2e-10)
    throw std::runtime_error("auxiliary original-state KLU mismatch");
  std::cout << "{\"kind\":\"auxiliary_validation\",\"case\":\"" << sample.name
            << "\",\"zero_rhs\":" << zero << ",\"componentwise\":" << error
            << ",\"scaled_klu_difference\":" << difference / norm << "}\n";
}
void ValidateAuxiliary(const HostPlan &h,
                       const std::vector<ProbeSample> &samples) {
  for (std::size_t start = 0; start < samples.size(); start += 16) {
    HostStaging staging;
    Allocations allocation(staging);
    const auto p = UploadPlan(h, allocation);
    const int count = std::min<std::size_t>(16, samples.size() - start);
    std::vector<Model> models(count);
    std::vector<Workspace> workspace(count);
    std::vector<OriginalWork> original(count);
    std::size_t bytes = 0;
    for (int i = 0; i < count; ++i)
      bytes = std::max(bytes,
                       PrepareAuxiliary(h, p, samples[start + i], allocation,
                                        models[i], workspace[i], original[i]));
    auto *dm = allocation.Upload(models);
    auto *dw = allocation.Upload(workspace);
    auto *doriginal = allocation.Upload(original);
    CheckCuda(cudaFuncSetAttribute(AuxiliaryMatrixReplay,
                                   cudaFuncAttributeMaxDynamicSharedMemorySize,
                                   bytes),
              "auxiliary shared memory");
    for (bool zero : {false, true}) {
      if (zero)
        for (int i = 0; i < count; ++i)
          allocation.Copy(original[i].rhs, std::vector<double>(p.n).data(),
                          p.n * sizeof(double), cudaMemcpyHostToDevice);
      AuxiliaryMatrixReplay<<<count, Threads, bytes, allocation.stream()>>>(
          p, dm, dw, doriginal, 1);
      CheckCuda(cudaGetLastError(), "auxiliary validation launch");
      allocation.Copy(original.data(), doriginal, count * sizeof(OriginalWork),
                      cudaMemcpyDeviceToHost);
      for (int i = 0; i < count; ++i)
        CheckFullSolution(samples[start + i], original[i], allocation, zero);
    }
    if (start == 0) {
      auto singular = samples[0].a.values;
      const int row = h.retained[0];
      for (int j = h.full_rows[row]; j < h.full_rows[row + 1]; ++j)
        singular[j] = 0;
      allocation.Copy(original[0].values, singular.data(),
                      singular.size() * sizeof(double), cudaMemcpyHostToDevice);
      AuxiliaryMatrixReplay<<<1, Threads, bytes, allocation.stream()>>>(
          p, dm, dw, doriginal, 1);
      CheckCuda(cudaGetLastError(), "auxiliary singular zero RHS launch");
      allocation.Copy(original.data(), doriginal, sizeof(OriginalWork),
                      cudaMemcpyDeviceToHost);
      if (original[0].error != Singular)
        throw std::runtime_error(
            "singular actual reduced Jacobian with zero RHS not rejected");
      std::cout << "{\"kind\":\"auxiliary_hostile\",\"singular_actual_zero_rhs_"
                   "rejected\":true}\n";
    }
  }
}
void BenchmarkAuxiliary(const HostPlan &h,
                        const std::vector<ProbeSample> &samples) {
  HostStaging staging;
  Allocations allocation(staging);
  const auto p = UploadPlan(h, allocation);
  std::vector<Model> models(16);
  std::vector<Workspace> workspace(16);
  std::vector<OriginalWork> original(16);
  std::size_t bytes = 0;
  for (int i = 0; i < 16; ++i)
    bytes = std::max(bytes, PrepareAuxiliary(h, p, samples[(i % 9) * 16 + 4],
                                             allocation, models[i],
                                             workspace[i], original[i]));
  auto *dm = allocation.Upload(models);
  auto *dw = allocation.Upload(workspace);
  auto *doriginal = allocation.Upload(original);
  CheckCuda(cudaFuncSetAttribute(AuxiliaryMatrixReplay,
                                 cudaFuncAttributeMaxDynamicSharedMemorySize,
                                 bytes),
            "auxiliary benchmark shared memory");
  cudaEvent_t begin, end;
  CheckCuda(cudaEventCreate(&begin), "auxiliary event");
  CheckCuda(cudaEventCreate(&end), "auxiliary event");
  for (int count : {1, 9, 16})
    for (int repetition = -1; repetition < 9; ++repetition) {
      constexpr int iterations = 100;
      CheckCuda(cudaEventRecord(begin, allocation.stream()), "auxiliary event");
      AuxiliaryMatrixReplay<<<count, Threads, bytes, allocation.stream()>>>(
          p, dm, dw, doriginal, iterations);
      CheckCuda(cudaGetLastError(), "auxiliary benchmark launch");
      CheckCuda(cudaEventRecord(end, allocation.stream()), "auxiliary event");
      CheckCuda(cudaEventSynchronize(end), "auxiliary event");
      float ms = 0;
      CheckCuda(cudaEventElapsedTime(&ms, begin, end), "auxiliary timing");
      std::vector<Workspace> result(count);
      allocation.Copy(result.data(), dw, count * sizeof(Workspace),
                      cudaMemcpyDeviceToHost);
      allocation.Copy(original.data(), doriginal, count * sizeof(OriginalWork),
                      cudaMemcpyDeviceToHost);
      std::uint64_t solves = 0, factors = 0, refinements = 0, dense = 0;
      for (int i = 0; i < count; ++i) {
        CheckFullSolution(samples[(i % 9) * 16 + 4], original[i], allocation,
                          false);
        solves += result[i].progress.solves;
        factors += result[i].progress.factors;
        refinements += result[i].progress.refinements;
        dense += result[i].progress.dense_factors;
        result[i].progress = {};
      }
      allocation.Copy(dw, result.data(), count * sizeof(Workspace),
                      cudaMemcpyHostToDevice);
      std::cout << "{\"kind\":\"auxiliary_timing\",\"count\":" << count
                << ",\"repetition\":" << repetition
                << ",\"iterations\":" << iterations << ",\"device_ms\":" << ms
                << ",\"solves\":" << solves << ",\"factors\":" << factors
                << ",\"refinements\":" << refinements
                << ",\"dense_factors\":" << dense << "}\n";
    }
  CheckCuda(cudaEventDestroy(begin), "auxiliary event release");
  CheckCuda(cudaEventDestroy(end), "auxiliary event release");
}
int AuxiliaryProbe(const char *path, bool validation_only) {
  const auto samples = ReadProbe(path);
  const auto h = GeneratedHostPlan();
  ProbeChecked(BeginEmi03CudaJob("auxiliary-matrix-probe"));
  ValidateAuxiliary(h, samples);
  if (!validation_only)
    BenchmarkAuxiliary(h, samples);
  const auto ended = ProbeChecked(EndEmi03CudaJob());
  if (ended.outstanding_device_bytes || ended.cleanup_failures)
    throw std::runtime_error("auxiliary probe cleanup failure");
  return 0;
}
} // namespace
} // namespace ohmnivore
int main(int argc, char **argv) {
  try {
    if (argc < 2 || argc > 3)
      return 2;
    if (argc == 3 && std::string(argv[2]) != "--validate-only")
      return 2;
    std::cout << std::setprecision(17);
    return ohmnivore::AuxiliaryProbe(argv[1], argc == 3);
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
