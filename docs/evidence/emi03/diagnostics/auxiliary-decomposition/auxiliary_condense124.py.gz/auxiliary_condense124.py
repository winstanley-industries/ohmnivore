from reference.emi03 import ensemble as e
from pathlib import Path
import json
np=e.metrics.np;w=Path('/home/adam/emi03-work');p=json.loads((w/'auxiliary-plan122.json').read_text());q=json.loads((w/'auxiliary-static124.json').read_text());ports=set(x['core'] for x in q['ports']);n=len(p['retained']);edges={(r,p['core_columns'][j]) for r in range(n) for j in range(p['core_rows'][r],p['core_rows'][r+1])}
def matching(group):
 match={}
 def augment(row,seen):
  for col in sorted(group):
   if col in seen or (row,col) not in edges:continue
   seen.add(col)
   if col not in match or augment(match[col],seen):match[col]=row;return True
  return False
 return [row for row in sorted(group) if not augment(row,set())]
promoted=[]
while True:
 bad=matching(set(range(n))-ports)
 if not bad:break
 ports.update(bad);promoted.extend(bad)
print('promoted',promoted,'ports',len(ports),flush=True)
port=np.array(sorted(ports));interior=np.array(sorted(set(range(n))-ports));records=[]
for path in sorted((w/'schur-snapshots107').glob('*/matrices.jsonl')):
 for line in path.read_text().splitlines():
  m=json.loads(line);a=np.array(m['values']);b=np.array(m['rhs']);response=np.zeros(len(p['response_columns']));offset=np.zeros(len(p['aux']))
  for level in range(len(p['aux_bounds'])-1):
   for i in p['response_order'][p['response_bounds'][level]:p['response_bounds'][level+1]]:
    source,begin,count=p['response_recipes'][i];response[i]=-(a[source] if source>=0 else 0)-sum(a[c]*response[o] for c,o in p['response_terms'][begin:begin+count])
   for i in p['aux_order'][p['aux_bounds'][level]:p['aux_bounds'][level+1]]:
    source,begin,count=p['offset_recipes'][i];offset[i]=b[source]-sum(a[c]*offset[o] for c,o in p['offset_terms'][begin:begin+count])
  reduced=np.zeros((n,n));rhs=np.zeros(n)
  for r in range(n):
   source,begin,count=p['rhs_recipes'][r];rhs[r]=b[source]-sum(a[c]*offset[o] for c,o in p['rhs_terms'][begin:begin+count])
   for j in range(p['core_rows'][r],p['core_rows'][r+1]):
    source,begin,count=p['core_recipes'][j];reduced[r,p['core_columns'][j]]=(a[source] if source>=0 else 0)+sum(a[c]*response[o] for c,o in p['core_terms'][begin:begin+count])
  record={'case':path.parent.name,'sample':m['sample'],'alpha':m['alpha']}
  try:
   d=reduced[np.ix_(interior,interior)];ee=reduced[np.ix_(interior,port)];ff=reduced[np.ix_(port,interior)];cc=reduced[np.ix_(port,port)]
   scale=abs(d).max(axis=1);pp=np.linalg.solve(d/scale[:,None],ee/scale[:,None]);qq=np.linalg.solve(d/scale[:,None],rhs[interior]/scale)
   ss=cc-ff@pp;gg=rhs[port]-ff@qq;x=np.zeros(n);x[port]=np.linalg.solve(ss,gg);x[interior]=qq-pp@x[port]
   oracle=np.array(m['oracle'])[p['retained']];difference=max(abs(x-oracle))/max(1,max(abs(oracle)))
   record.update(status='pass' if difference<2e-10 else 'failure',scaled_klu_difference=float(difference),interior_condition=float(np.linalg.cond(d/scale[:,None],np.inf)),interface_condition=float(np.linalg.cond(ss/abs(ss).max(axis=1)[:,None],np.inf)))
  except np.linalg.LinAlgError as ex:record.update(status='singular',reason=str(ex))
  records.append(record)
result={'scope':'Offline reduced-matrix linear-interior condensation screen; no full original residual correction or GPU timing','core':n,'ports':port.tolist(),'interior':interior.tolist(),'promoted':promoted,'records':records}
(w/'auxiliary-condense124.json').write_text(json.dumps(result,indent=2)+'\n');print({status:sum(r['status']==status for r in records) for status in set(r['status'] for r in records)},flush=True)
print('maxdiff',max([r.get('scaled_klu_difference',0) for r in records]),flush=True)
