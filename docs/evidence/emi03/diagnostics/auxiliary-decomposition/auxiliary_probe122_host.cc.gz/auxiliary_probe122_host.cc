void CheckAuxiliaryStructure(const HostPlan &h,const ProbeSample &sample) {
  const auto &a=sample.a;
  if(std::vector<int>(a.row_offsets.begin(),a.row_offsets.end())!=h.full_rows||std::vector<int>(a.column_indices.begin(),a.column_indices.end())!=h.full_columns)
    throw std::runtime_error("auxiliary probe requires the frozen structural pattern");
  const auto dense=a.ToDense();const int n=a.rows;
  for(std::size_t i=0;i<h.aux.size();++i) {
    const int node=h.aux[i],branch=h.branches[i];
    if(dense[node*n+branch]!=1||dense[branch*n+node]!=1)throw std::runtime_error("driver identity coefficient changed");
    for(int j=0;j<n;++j) {
      if(j!=node&&j!=branch&&dense[node*n+j]!=0)throw std::runtime_error("coupled auxiliary node");
      if(j!=node&&dense[j*n+branch]!=0)throw std::runtime_error("driver current used outside isolated equation");
    }
    for(std::size_t j=i+1;j<h.aux.size();++j)
      if(dense[branch*n+h.aux[j]]!=0)throw std::runtime_error("nontriangular auxiliary dependency");
  }
}
std::size_t PrepareAuxiliary(const HostPlan &h,DevicePlan p,const ProbeSample &sample,Allocations &allocation,Model &m,Workspace &workspace,OriginalWork &original) {
  CheckAuxiliaryStructure(h,sample);
  original.values=allocation.Upload(sample.a.values);original.rhs=allocation.Upload(sample.b);
  original.solution=allocation.Allocate<double>(p.n);original.response=allocation.Allocate<double>(p.response_values);original.reduced=allocation.Allocate<double>(p.core_nnz);original.error=0;
  auto *device=allocation.Upload(std::vector<OriginalWork>{original});
  PrepareAuxiliaryMatrix<<<1,Threads,0,allocation.stream()>>>(p,device);
  CheckCuda(cudaGetLastError(),"auxiliary reduction setup");
  allocation.Copy(&original,device,sizeof(original),cudaMemcpyDeviceToHost);
  if(original.error)throw std::runtime_error("auxiliary matrix construction failed");
  ProbeSample core;core.name=sample.name;core.a.rows=core.a.columns=p.core;
  core.a.row_offsets=std::vector<std::size_t>(h.core_rows.begin(),h.core_rows.end());core.a.column_indices=std::vector<std::size_t>(h.core_columns.begin(),h.core_columns.end());core.a.values.resize(p.core_nnz);core.b.resize(p.core);core.oracle.resize(p.core);
  allocation.Copy(core.a.values.data(),original.reduced,p.core_nnz*sizeof(double),cudaMemcpyDeviceToHost);
  auto bytes=ProbePrepare(core,allocation,m,workspace);
  return (bytes+7)/8*8+(p.response_values+p.auxiliaries+3*p.n)*sizeof(double);
}
void CheckFullSolution(const ProbeSample &sample,const OriginalWork &o,Allocations &allocation,bool zero) {
  if(o.error)throw std::runtime_error(sample.name+" auxiliary GPU error "+std::to_string(o.error));
  std::vector<double> x(sample.a.rows);allocation.Copy(x.data(),o.solution,x.size()*sizeof(double),cudaMemcpyDeviceToHost);
  auto rhs=sample.b;if(zero)std::fill(rhs.begin(),rhs.end(),0);
  const double error=ProbeChecked(ValidateSparseSolution(sample.a,rhs,x));
  double difference=0,norm=1;
  for(std::size_t i=0;i<x.size();++i){const double oracle=zero?0:sample.oracle[i];difference=std::max(difference,std::abs(x[i]-oracle));norm=std::max(norm,std::abs(oracle));}
  if(difference/norm>2e-10)throw std::runtime_error("auxiliary original-state KLU mismatch");
  std::cout<<"{\"kind\":\"auxiliary_validation\",\"case\":\""<<sample.name<<"\",\"zero_rhs\":"<<zero<<",\"componentwise\":"<<error<<",\"scaled_klu_difference\":"<<difference/norm<<"}\n";
}
void ValidateAuxiliary(const HostPlan &h,const std::vector<ProbeSample> &samples) {
  for(std::size_t start=0;start<samples.size();start+=16) {
    HostStaging staging;Allocations allocation(staging);const auto p=UploadPlan(h,allocation);
    const int count=std::min<std::size_t>(16,samples.size()-start);
    std::vector<Model> models(count);std::vector<Workspace> workspace(count);std::vector<OriginalWork> original(count);std::size_t bytes=0;
    for(int i=0;i<count;++i)bytes=std::max(bytes,PrepareAuxiliary(h,p,samples[start+i],allocation,models[i],workspace[i],original[i]));
    auto *dm=allocation.Upload(models),*unused_model=dm;static_cast<void>(unused_model);
    auto *dw=allocation.Upload(workspace);auto *doriginal=allocation.Upload(original);
    CheckCuda(cudaFuncSetAttribute(AuxiliaryMatrixReplay,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"auxiliary shared memory");
    for(bool zero:{false,true}) {
      if(zero)for(int i=0;i<count;++i)allocation.Copy(original[i].rhs,std::vector<double>(p.n).data(),p.n*sizeof(double),cudaMemcpyHostToDevice);
      AuxiliaryMatrixReplay<<<count,Threads,bytes,allocation.stream()>>>(p,dm,dw,doriginal,1);
      CheckCuda(cudaGetLastError(),"auxiliary validation launch");
      allocation.Copy(original.data(),doriginal,count*sizeof(OriginalWork),cudaMemcpyDeviceToHost);
      for(int i=0;i<count;++i)CheckFullSolution(samples[start+i],original[i],allocation,zero);
    }
    if(start==0) {
      auto singular=samples[0].a.values;const int row=h.retained[0];
      for(int j=h.full_rows[row];j<h.full_rows[row+1];++j)singular[j]=0;
      allocation.Copy(original[0].values,singular.data(),singular.size()*sizeof(double),cudaMemcpyHostToDevice);
      AuxiliaryMatrixReplay<<<1,Threads,bytes,allocation.stream()>>>(p,dm,dw,doriginal,1);
      CheckCuda(cudaGetLastError(),"auxiliary singular zero RHS launch");
      allocation.Copy(original.data(),doriginal,sizeof(OriginalWork),cudaMemcpyDeviceToHost);
      if(original[0].error!=Singular)throw std::runtime_error("singular actual reduced Jacobian with zero RHS not rejected");
      std::cout<<"{\"kind\":\"auxiliary_hostile\",\"singular_actual_zero_rhs_rejected\":true}\n";
    }
  }
}
void BenchmarkAuxiliary(const HostPlan &h,const std::vector<ProbeSample> &samples) {
  HostStaging staging;Allocations allocation(staging);const auto p=UploadPlan(h,allocation);
  std::vector<Model> models(16);std::vector<Workspace> workspace(16);std::vector<OriginalWork> original(16);std::size_t bytes=0;
  for(int i=0;i<16;++i)bytes=std::max(bytes,PrepareAuxiliary(h,p,samples[(i%9)*16+4],allocation,models[i],workspace[i],original[i]));
  auto *dm=allocation.Upload(models);auto *dw=allocation.Upload(workspace);auto *doriginal=allocation.Upload(original);
  CheckCuda(cudaFuncSetAttribute(AuxiliaryMatrixReplay,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"auxiliary benchmark shared memory");
  cudaEvent_t begin,end;CheckCuda(cudaEventCreate(&begin),"auxiliary event");CheckCuda(cudaEventCreate(&end),"auxiliary event");
  for(int count:{1,9,16})for(int repetition=-1;repetition<9;++repetition) {
    constexpr int iterations=100;
    CheckCuda(cudaEventRecord(begin,allocation.stream()),"auxiliary event");
    AuxiliaryMatrixReplay<<<count,Threads,bytes,allocation.stream()>>>(p,dm,dw,doriginal,iterations);
    CheckCuda(cudaGetLastError(),"auxiliary benchmark launch");CheckCuda(cudaEventRecord(end,allocation.stream()),"auxiliary event");CheckCuda(cudaEventSynchronize(end),"auxiliary event");
    float ms=0;CheckCuda(cudaEventElapsedTime(&ms,begin,end),"auxiliary timing");
    std::vector<Workspace> result(count);allocation.Copy(result.data(),dw,count*sizeof(Workspace),cudaMemcpyDeviceToHost);allocation.Copy(original.data(),doriginal,count*sizeof(OriginalWork),cudaMemcpyDeviceToHost);
    std::uint64_t solves=0,factors=0,refinements=0,dense=0;
    for(int i=0;i<count;++i){CheckFullSolution(samples[(i%9)*16+4],original[i],allocation,false);solves+=result[i].progress.solves;factors+=result[i].progress.factors;refinements+=result[i].progress.refinements;dense+=result[i].progress.dense_factors;result[i].progress={};}
    allocation.Copy(dw,result.data(),count*sizeof(Workspace),cudaMemcpyHostToDevice);
    std::cout<<"{\"kind\":\"auxiliary_timing\",\"count\":"<<count<<",\"repetition\":"<<repetition<<",\"iterations\":"<<iterations<<",\"device_ms\":"<<ms<<",\"solves\":"<<solves<<",\"factors\":"<<factors<<",\"refinements\":"<<refinements<<",\"dense_factors\":"<<dense<<"}\n";
  }
  CheckCuda(cudaEventDestroy(begin),"auxiliary event release");CheckCuda(cudaEventDestroy(end),"auxiliary event release");
}
int AuxiliaryProbe(const char *path,bool validation_only) {
  const auto samples=ReadProbe(path);const auto h=GeneratedHostPlan();
  ProbeChecked(BeginEmi03CudaJob("auxiliary-matrix-probe"));
  ValidateAuxiliary(h,samples);
  if(!validation_only)BenchmarkAuxiliary(h,samples);
  const auto ended=ProbeChecked(EndEmi03CudaJob());
  if(ended.outstanding_device_bytes||ended.cleanup_failures)throw std::runtime_error("auxiliary probe cleanup failure");
  return 0;
}
} // namespace
} // namespace ohmnivore
int main(int argc,char **argv) { try {if(argc<2||argc>3)return 2;if(argc==3&&std::string(argv[2])!="--validate-only")return 2;std::cout<<std::setprecision(17);return ohmnivore::AuxiliaryProbe(argv[1],argc==3);}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;} }
