from reference.emi03 import ensemble as e
from pathlib import Path
import json
np=e.metrics.np;w=Path('/home/adam/emi03-work')
# Reuse only the algebraic reconstruction/residual helper from the prior proof.
exec((w/'auxiliary_numeric121.py').read_text().split('for folder in sorted')[0])
p=json.loads((w/'auxiliary-plan122.json').read_text());q=json.loads((w/'auxiliary-static124b.json').read_text());ports=set(x['core'] for x in q['ports']);n=len(rest);edges={(r,p['core_columns'][j]) for r in range(n) for j in range(p['core_rows'][r],p['core_rows'][r+1])}
def matching(group):
 match={}
 def augment(row,seen):
  for col in sorted(group):
   if col in seen or (row,col) not in edges:continue
   seen.add(col)
   if col not in match or augment(match[col],seen):match[col]=row;return True
  return False
 return [row for row in sorted(group) if not augment(row,set())]
promoted=[]
while True:
 bad=matching(set(range(n))-ports)
 if not bad:break
 ports.update(bad);promoted.extend(bad)
port=np.array(sorted(ports));interior=np.array(sorted(set(range(n))-ports));print('ports',len(port),'interior',len(interior),'promoted',promoted,flush=True)
# Assert all possible nonlinear stamps after auxiliary propagation remain in C.
for d in q['nonlinear_programs']:assert set(d['rows'])<=ports and set(d['columns'])<=ports
for r in range(n):
 for j in range(p['core_rows'][r],p['core_rows'][r+1]):
  if p['core_recipes'][j][2]:assert r in ports and p['core_columns'][j] in ports
records=[]
for folder in sorted((w/'schur-snapshots107').glob('*-*')):
 if not folder.is_dir():continue
 for line in (folder/'matrices.jsonl').read_text().splitlines():
  m=json.loads(line);a=np.zeros((m['n'],m['n']));b=np.array(m['rhs']);oracle=np.array(m['oracle'])
  for i in range(m['n']):a[i,np.array(m['columns'][m['rows'][i]:m['rows'][i+1]])]=m['values'][m['rows'][i]:m['rows'][i+1]]
  response=np.zeros((len(aux),n))
  for i,branch in enumerate(current):
   response[i]=-a[branch,rest]
   for j in range(i):response[i]-=a[branch,aux[j]]*response[j]
  reduced=a[np.ix_(rest,rest)]+a[np.ix_(rest,aux)]@response
  d=reduced[np.ix_(interior,interior)];ee=reduced[np.ix_(interior,port)];ff=reduced[np.ix_(port,interior)];cc=reduced[np.ix_(port,port)]
  row={'case':folder.name,'sample':m['sample'],'alpha':m['alpha']}
  try:
   ds=abs(d).max(axis=1);pp=np.linalg.solve(d/ds[:,None],ee/ds[:,None]);ss=cc-ff@pp;sc=abs(ss).max(axis=1)
   def solve(rhs):
    offset=np.zeros(len(aux))
    for i,branch in enumerate(current):
     offset[i]=rhs[branch]
     for j in range(i):offset[i]-=a[branch,aux[j]]*offset[j]
    rb=rhs[rest]-a[np.ix_(rest,aux)]@offset
    qq=np.linalg.solve(d/ds[:,None],rb[interior]/ds);xx=np.empty(n);xx[port]=np.linalg.solve(ss/sc[:,None],(rb[port]-ff@qq)/sc);xx[interior]=qq-pp@xx[port]
    x=np.empty(m['n']);x[rest]=xx;x[aux]=offset+response@xx;x[current]=rhs[aux]-1e-12*x[aux];return x
   x=solve(b);history=[]
   for attempt in range(5):
    r,norm,comp=residual(a,b,x);history.append({'normwise':norm,'componentwise':comp})
    if not np.any(r) or (attempt>0 and norm<=1e-10 and comp<=1e-5):break
    if attempt<4:x+=solve(r)
   difference=float(max(abs(x-oracle))/max(1,max(abs(oracle))))
   row.update(status='pass' if norm<=1e-10 and comp<=1e-5 and difference<=2e-10 else 'failure',refinements=len(history)-1,residual_history=history,scaled_klu_difference=difference,interior_condition=float(np.linalg.cond(d/ds[:,None],np.inf)),interface_condition=float(np.linalg.cond(ss/sc[:,None],np.inf)))
  except np.linalg.LinAlgError as error:row.update(status='singular',reason=str(error))
  records.append(row)
result={'scope':'Offline exact 40-auxiliary elimination plus constant-linear interior Schur condensation, complete original residual corrections and recovery; no GPU/transient qualification','core':n,'port':port.tolist(),'interior':interior.tolist(),'promoted':promoted,'all_nonlinear_entries_confined_to_interface':True,'records':records}
(w/'auxiliary-condense125.json').write_text(json.dumps(result,indent=2)+'\n');print({status:sum(r['status']==status for r in records) for status in set(r['status'] for r in records)},flush=True);print('maxdiff',max(r.get('scaled_klu_difference',0) for r in records),'maxrefine',max(r.get('refinements',0) for r in records),flush=True)
