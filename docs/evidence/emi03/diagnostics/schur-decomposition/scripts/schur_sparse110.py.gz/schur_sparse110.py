from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text()
s=s.replace('double failed_best;', 'double failed_best;\n  unsigned long long cycles[3];')
s=s.replace('__device__ bool Factor(double *lu, int n, int *permutation, Work &w,\n                       int group)', '__device__ bool Factor(double *lu, int n, int *permutation, Work &w,\n                       int group, unsigned long long *masks)')
# Formatting may leave signature on one line.
s=s.replace('__device__ bool Factor(double *lu, int n, int *permutation, Work &w, int group)', '__device__ bool Factor(double *lu, int n, int *permutation, Work &w, int group, unsigned long long *masks)')
s=s.replace('''      lu[i * n + j] = fma(-lu[i * n + k], lu[k * n + j], lu[i * n + j]);''','''      const double lower = lu[i * n + k], upper = lu[k * n + j];
      if (lower != 0 && upper != 0)
        lu[i * n + j] = fma(-lower, upper, lu[i * n + j]);''')
s=s.replace('''  return true;
}
// Each lane''','''  for (int row = lane; row < n; row += 32) {
    unsigned long long lower = 0, upper = 0;
    for (int col = 0; col < row; ++col)
      if (lu[row * n + col] != 0) lower |= 1ULL << col;
    for (int col = row + 1; col < n; ++col)
      if (lu[row * n + col] != 0) upper |= 1ULL << col;
    masks[row] = lower;
    masks[n + row] = upper;
  }
  __syncwarp();
  return true;
}
// Each lane''')
s=s.replace('void Solve(const double *lu, int n, double *values)', 'void Solve(const double *lu, int n, double *values, const unsigned long long *masks)')
s=s.replace('''    for (int col = 0; col < row; ++col)
      value = fma(-lu[row * n + col], values[col], value);''','''    auto active = masks[row];
    while (active) {
      const int col = __ffsll(active) - 1;
      value = fma(-lu[row * n + col], values[col], value);
      active &= active - 1;
    }''')
s=s.replace('''    for (int col = row + 1; col < n; ++col)
      value = fma(-lu[row * n + col], values[col], value);''','''    auto active = masks[n + row];
    while (active) {
      const int col = __ffsll(active) - 1;
      value = fma(-lu[row * n + col], values[col], value);
      active &= active - 1;
    }''')
s=s.replace('int *permutations, bool correction)', 'int *permutations, unsigned long long *all_masks, bool correction)')
s=s.replace('int *permutation = permutations + group * L;', 'int *permutation = permutations + group * L;\n  auto *masks = all_masks + group * L * 2;')
s=s.replace('Factor(lu, n, permutation, w, group)', 'Factor(lu, n, permutation, w, group, masks)')
s=s.replace('Solve(lu, n, values)', 'Solve(lu, n, values, masks)')
s=s.replace('''__device__ void Interface(const Plan &p, Work &w, double *lu, int *permutation,
                          bool correction)''','''__device__ void Interface(const Plan &p, Work &w, double *lu, int *permutation,
                          unsigned long long *masks, bool correction)''')
s=s.replace('Factor(lu, p.ports, permutation, w, -1)', 'Factor(lu, p.ports, permutation, w, -1, masks)')
s=s.replace('Solve(lu, p.ports, values)', 'Solve(lu, p.ports, values, masks)')
s=s.replace('__shared__ int permutations[G * L + P];', '__shared__ int permutations[G * L + P];\n  __shared__ unsigned long long masks[G * L * 2 + P * 2];')
s=s.replace('''  for (int iteration = 0; iteration < iterations; ++iteration) {''','''  if (rank == 0 && threadIdx.x == 0)
    for (int stage = 0; stage < 3; ++stage) w.cycles[stage] = 0;
  for (int iteration = 0; iteration < iterations; ++iteration) {''')
s=s.replace('''    for (int pass = 0; pass < 2; ++pass) {
      for''','''    for (int pass = 0; pass < 2; ++pass) {
      auto start = clock64();
      for''')
s=s.replace('Interior(p, w, group, storage, permutations, pass != 0);', 'Interior(p, w, group, storage, permutations, masks, pass != 0);')
s=s.replace('''      barrier();
      if (w.error)
        return;
      if (rank == 0 && warp == 0)
        Interface(p, w, storage + p.storage, permutations + G * L, pass != 0);
      barrier();
      if (w.error)
        return;''','''      barrier();
      if (rank == 0 && threadIdx.x == 0) w.cycles[0] += clock64() - start;
      if (w.error) return;
      start = clock64();
      if (rank == 0 && warp == 0)
        Interface(p, w, storage + p.storage, permutations + G * L, masks + G * L * 2, pass != 0);
      barrier();
      if (rank == 0 && threadIdx.x == 0) w.cycles[1] += clock64() - start;
      if (w.error) return;
      start = clock64();''')
s=s.replace('''      barrier();
    }
  }
}
void Launch''','''      barrier();
      if (rank == 0 && threadIdx.x == 0) w.cycles[2] += clock64() - start;
    }
  }
}
void Launch''')
s=s.replace('<< ",\\\"device_ms\\\":" << milliseconds << "}\\n";', '<< ",\\\"device_ms\\\":" << milliseconds\n                  << ",\\\"cycles\\\":[" << output[0].cycles[0] << "," << output[0].cycles[1] << "," << output[0].cycles[2] << "]}\\n";')
p.write_text(s)
