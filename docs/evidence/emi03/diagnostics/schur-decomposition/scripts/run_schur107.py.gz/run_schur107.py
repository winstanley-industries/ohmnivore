from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
root=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=w/'schur-snapshots107';out.mkdir(exist_ok=False)
source=w/'prefix-phases106';specs=json.loads((source/'specs.json').read_text());binary=root/'bazel-out/k8-opt/bin/cpp/emi03_schur_probe'
identity={'scope':'Fresh CPU accepted-state Jacobians at eight selected 20us-prefix points, BE/TRAP companion matrices and manufactured RHS with independently certified KLU solutions; numerical decomposition feasibility only','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'probe_source_sha256':hashlib.sha256((root/'cpp/benchmarks/emi03_schur_probe.cc').read_bytes()).hexdigest(),'cases':{s['id']:s['source_sha256'] for s in specs}}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
def run(spec):
 folder=out/spec['id'];folder.mkdir();deck=folder/'input.cir';deck.write_text(spec['source']);start=time.monotonic()
 with (folder/'matrices.jsonl').open('w') as data,(folder/'run.log').open('w') as log:
  try:code=subprocess.run([str(binary),str(deck)],stdout=data,stderr=log,env=dict(os.environ,TMPDIR=str(w/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'),timeout=120).returncode
  except subprocess.TimeoutExpired:code=124
 row={'case':spec['id'],'exit_code':code,'wall_s':time.monotonic()-start,'matrix_lines':len((folder/'matrices.jsonl').read_text().splitlines()),'matrices_sha256':hashlib.sha256((folder/'matrices.jsonl').read_bytes()).hexdigest()};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=9) as pool:records=list(pool.map(run,specs))
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
raise SystemExit(0 if all(x['exit_code']==0 and x['matrix_lines']==16 for x in records) else 1)
