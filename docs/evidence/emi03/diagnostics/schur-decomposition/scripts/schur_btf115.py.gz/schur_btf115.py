from pathlib import Path
import json,shlex
w=Path('/home/adam/emi03-work');p=json.loads((w/'schur-structure107.json').read_text());edges=set();desc={};names={}
for line in (w/'structure-probe.tsv').read_text().splitlines():
 t=shlex.split(line)
 if t[0] in ['V','I']:names[int(t[1])]=t[2]
 elif t[0] in ['G','C'] and float(t[3])!=0:edges.add((int(t[1]),int(t[2])))
 elif t[0]=='D':desc[int(t[1])]={'r':[],'d':[]}
 elif t[0]=='P':desc[int(t[1])]['d'].append(int(t[2]))
 elif t[0]=='R':desc[int(t[1])]['r'].append(int(t[2]))
for d in desc.values():edges.update((r,c) for r in d['r'] for c in d['d'])
def btf(indices):
 indices=set(indices);match={}
 def augment(row,seen):
  for col in sorted(indices):
   if col in seen or (row,col) not in edges:continue
   seen.add(col)
   if col not in match or augment(match[col],seen):match[col]=row;return True
  return False
 assert all(augment(row,set()) for row in sorted(indices))
 adj={col:sorted(c for c in indices if (row,c) in edges) for col,row in match.items()}
 on=set();stack=[];low={};num={};components=[]
 def visit(i):
  low[i]=num[i]=len(num);stack.append(i);on.add(i)
  for j in adj[i]:
   if j not in num:visit(j);low[i]=min(low[i],low[j])
   elif j in on:low[i]=min(low[i],num[j])
  if low[i]==num[i]:
   group=[]
   while True:
    j=stack.pop();on.remove(j);group.append(j)
    if j==i:break
   components.append(sorted(group))
 for i in sorted(indices):
  if i not in num:visit(i)
 return {'size':len(indices),'blocks':[{'variables':[names[i] for i in g],'rows':[names[match[i]] for i in g],'indices':g,'row_indices':[match[i] for i in g]} for g in components],'sizes':sorted([len(x) for x in components],reverse=True)}
r={'full':btf(range(185)),'interiors':[btf(g['indices']) for g in p['groups']]}
(w/'schur-btf115.json').write_text(json.dumps(r,indent=2)+'\n')
print('full',r['full']['sizes'])
for i,x in enumerate(r['interiors']):print(i,x['size'],x['sizes'])
