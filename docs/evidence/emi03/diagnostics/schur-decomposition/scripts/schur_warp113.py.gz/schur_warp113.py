from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text()
a=s.index('// Each lane owns');b=s.index('__device__ double Rhs',a)
s=s[:a]+'''// All lanes cooperate across rows and RHS columns. Avoid serial per-column
// dot products with only one to four active lanes on the FP64 pipeline.
__device__ void Solve(const double *lu, int n, double *values, int count) {
  const int lane = threadIdx.x & 31;
  for (int k = 0; k < n; ++k) {
    for (int at = lane; at < (n - k - 1) * count; at += 32) {
      const int row = k + 1 + at / count, column = at % count;
      const double coefficient = lu[row * n + k];
      if (coefficient != 0)
        values[column * n + row] = fma(-coefficient, values[column * n + k], values[column * n + row]);
    }
    __syncwarp();
  }
  for (int k = n - 1; k >= 0; --k) {
    for (int column = lane; column < count; column += 32)
      values[column * n + k] /= lu[k * n + k];
    __syncwarp();
    for (int at = lane; at < k * count; at += 32) {
      const int row = at / count, column = at % count;
      const double coefficient = lu[row * n + k];
      if (coefficient != 0)
        values[column * n + row] = fma(-coefficient, values[column * n + k], values[column * n + row]);
    }
    __syncwarp();
  }
}
'''+s[b:]
a=s.index('  const int count = p.coupling_count[group];',s.index('__device__ void Interior'));b=s.index('\n}\n__device__ void Interface',a)
s=s[:a]+'''  const int coupled = p.coupling_count[group];
  const int count = correction ? 1 : coupled + 1;
  double *values = storage + p.rhs_offset[group];
  for (int at = lane; at < count * n; at += 32) {
    const int column = at / n, row = at % n;
    const int original = p.index[group][permutation[row]];
    values[at] = (column == count - 1 ? Rhs(p, w, original, correction)
                    : w.a[original * N + p.port[p.coupling_port[group][column]]])
                  / w.scale[original];
  }
  __syncwarp();
  Solve(lu, n, values, count);
  for (int at = lane; at < count * n; at += 32) {
    const int column = at / n, row = at % n;
    const int original = p.index[group][row];
    if (column == count - 1) w.q[original] = values[at];
    else w.response[original * P + p.coupling_port[group][column]] = values[at];
    if (!isfinite(values[at])) atomicExch(&w.error, 2);
  }'''+s[b:]
a=s.index('  if (lane == 0) {\n    double *values',s.index('__device__ void Interface'));b=s.index('\n}\ntemplate <bool Cluster>',a)
s=s[:a]+'''  double *values = lu + p.ports * p.ports;
  for (int row = lane; row < p.ports; row += 32) {
    const int original = p.port[permutation[row]];
    const double scale = w.scale[original];
    double value = Rhs(p, w, original, correction) / scale;
    for (int j = p.interface_offsets[permutation[row]];
         j < p.interface_offsets[permutation[row] + 1]; ++j) {
      const int k = p.interface_columns[j];
      value = fma(-w.a[original * N + k] / scale, w.q[k], value);
    }
    values[row] = value;
  }
  __syncwarp();
  Solve(lu, p.ports, values, 1);
  for (int row = lane; row < p.ports; row += 32)
    w.interface_solution[row] = values[row];'''+s[b:]
p.write_text(s)
