from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text();a=s.index('// All lanes cooperate');b=s.index('__device__ double Rhs',a)
s=s[:a]+'''// Build dependency levels from the complete current factors. These are work
// scheduling dependencies, never approximations to the electrical coupling.
__device__ void PrepareLevels(int n, int *levels, const unsigned long long *masks) {
  if ((threadIdx.x & 31) == 0) {
    for (int row = 0; row < n; ++row) {
      int level = 0;
      auto active = masks[row];
      while (active) {
        const int col = __ffsll(active) - 1;
        level = max(level, levels[col] + 1);
        active &= active - 1;
      }
      levels[row] = level;
    }
    for (int row = n - 1; row >= 0; --row) {
      int level = 0;
      auto active = masks[n + row];
      while (active) {
        const int col = __ffsll(active) - 1;
        level = max(level, levels[n + col] + 1);
        active &= active - 1;
      }
      levels[n + row] = level;
    }
  }
  __syncwarp();
}
__device__ void Solve(const double *lu, int n, double *values, int count,
                     const int *levels, const unsigned long long *masks) {
  const int lane = threadIdx.x & 31;
  for (int pass = 0; pass < 2; ++pass) {
    unsigned last = 0;
    for (int row = lane; row < n; row += 32)
      last = max(last, static_cast<unsigned>(levels[pass * n + row]));
    last = __reduce_max_sync(0xffffffff, last);
    for (unsigned level = 0; level <= last; ++level) {
      for (int at = lane; at < n * count; at += 32) {
        const int row = at / count, column = at % count;
        if (static_cast<unsigned>(levels[pass * n + row]) != level) continue;
        double value = values[column * n + row];
        auto active = masks[pass * n + row];
        while (active) {
          const int col = __ffsll(active) - 1;
          value = fma(-lu[row * n + col], values[column * n + col], value);
          active &= active - 1;
        }
        values[column * n + row] = pass ? value / lu[row * n + row] : value;
      }
      __syncwarp();
    }
  }
}
'''+s[b:]
a=s.index('__device__ void Interior');b=s.index('__device__ void Interface',a);t=s[a:b];t=t.replace('''  if (lane == 0)
    w.detail[group][0]''','''  if (!correction) PrepareLevels(n, permutation + n, masks);
  if (lane == 0)
    w.detail[group][0]''',1).replace('Solve(lu, n, values, count);','Solve(lu, n, values, count, permutation + n, masks);');s=s[:a]+t+s[b:]
a=s.index('__device__ void Interface');b=s.index('template <bool Cluster>',a);t=s[a:b];t=t.replace('''  if (lane == 0)
    w.detail[p.groups][0]''','''  if (!correction) PrepareLevels(p.ports, permutation + p.ports, masks);
  if (lane == 0)
    w.detail[p.groups][0]''',1).replace('Solve(lu, p.ports, values, 1);','Solve(lu, p.ports, values, 1, permutation + p.ports, masks);');s=s[:a]+t+s[b:]
p.write_text(s)
