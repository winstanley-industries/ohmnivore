__global__ void SelectedMatrixReplay(const Model *models, Workspace *all, int iterations) {
  const Model m = models[blockIdx.x];
  Workspace *workspace = all + blockIdx.x;
  // INITIALIZATION_FROM_SELECTED_KERNEL
  for (int i = threadIdx.x; i < m.n; i += Threads)
    w.affine_rhs[i] = workspace->affine_rhs[i];
  for (int i = threadIdx.x; i < m.nnz; i += Threads)
    w.jacobian[i] = workspace->jacobian[i];
  __syncthreads();
  for (int i = 0; i < iterations && !s.error; ++i) {
    if (threadIdx.x == 0) s.factor_valid = false;
    __syncthreads();
    Linear(m, w, s);
  }
  for (int i = threadIdx.x; i < m.n; i += Threads)
    workspace->solution[i] = w.solution[i];
  if (threadIdx.x == 0) {
    w.progress.error = s.error;
    workspace->progress = w.progress;
  }
}
template <class T> T ProbeChecked(Result<T> result) {
  if (!result.ok()) throw std::runtime_error(result.error().message);
  return result.TakeValue();
}
struct ProbeSample { std::string name; CsrMatrix a; std::vector<double> b, oracle; };
std::vector<ProbeSample> ReadProbe(const char *path) {
  std::ifstream input(path); std::string magic; int n=0, ports=0, groups=0, count=0;
  input>>magic>>n>>ports>>groups>>count;
  if (!input || magic!="EMI03_SCHUR_REPLAY_1" || n!=185 || ports!=14 || groups!=15 || count!=144)
    throw std::runtime_error("invalid frozen replay");
  int ignored;
  for (int i=0;i<ports;++i) input>>ignored;
  for (int g=0;g<groups;++g) {int size=0; input>>size; if(size<1||size>64) throw std::runtime_error("bad group"); for(int i=0;i<size;++i)input>>ignored;}
  std::vector<ProbeSample> samples(count);
  for(auto &s:samples) {
    std::size_t nnz=0;input>>s.name>>nnz;
    if(!input||nnz>static_cast<std::size_t>(n*n))throw std::runtime_error("bad matrix");
    s.a.rows=s.a.columns=n;s.a.row_offsets.resize(n+1);s.a.column_indices.resize(nnz);s.a.values.resize(nnz);s.b.resize(n);s.oracle.resize(n);
    for(auto &x:s.a.row_offsets)input>>x;
    for(auto &x:s.a.column_indices)input>>x;
    for(auto &x:s.a.values)input>>x;
    for(auto &x:s.b)input>>x;
    for(auto &x:s.oracle)input>>x;
    if(!input)throw std::runtime_error("truncated matrix");
    ProbeChecked(ValidateSparseSolution(s.a,s.b,s.oracle));
  }
  return samples;
}
std::size_t ProbePrepare(const ProbeSample &sample, Allocations &allocation, Model &m, Workspace &w) {
  const int n=sample.a.rows;
  MnaSystem system;system.g=sample.a;system.c.rows=system.c.columns=n;system.c.row_offsets.resize(n+1);
  system.b_dc.resize(n);system.b_ac.resize(n);
  for(int i=0;i<n;++i)system.node_names.push_back("v"+std::to_string(i));
  TranAnalysis analysis{1,1,0,false};
  m.n=m.nodes=n;m.nnz=sample.a.values.size();
  PrepareFactorPlan(system,analysis,std::vector<double>(n),m,allocation);
  m.row_offsets=allocation.Upload(std::vector<int>(sample.a.row_offsets.begin(),sample.a.row_offsets.end()));
  m.columns=allocation.Upload(std::vector<int>(sample.a.column_indices.begin(),sample.a.column_indices.end()));
  w.state=allocation.Upload(std::vector<double>(n));
  w.affine_rhs=allocation.Upload(sample.b);w.jacobian=allocation.Upload(sample.a.values);
  w.solution=allocation.Allocate<double>(n);
  w.factored_jacobian=allocation.Allocate<double>(m.nnz);
  w.lu=allocation.Allocate<double>(n*N);w.permutation=allocation.Allocate<int>(n);
  w.last_dynamic_jacobian=nullptr;
  std::size_t bytes=((m.factor_nonzeros+17*n+2*m.nnz)*sizeof(double)+7)/8*8+
      (2*m.factor_nonzeros+m.factor_levels+1)*sizeof(int);
  bytes=(bytes+7)/8*8;
  m.shared_factor_metadata=true;m.shared_structure=true;
  bytes=(bytes+m.factor_nonzeros*sizeof(FactorEntry)+m.factor_terms*sizeof(FactorTerm)+7)/8*8;
  bytes+=(n+1+m.nnz)*sizeof(int);
  return bytes;
}
int MatrixProbe(const char *path) {
  auto samples=ReadProbe(path);
  ProbeChecked(BeginEmi03CudaJob("selected-matrix-probe"));
  {
    HostStaging staging;Allocations allocation(staging);
    std::vector<Model> models(16);std::vector<Workspace> workspace(16);
    std::size_t bytes=0;
    for(int i=0;i<16;++i)bytes=std::max(bytes,ProbePrepare(samples[(i%9)*16+4],allocation,models[i],workspace[i]));
    auto *dm=allocation.Upload(models);auto *dw=allocation.Upload(workspace);
    CheckCuda(cudaFuncSetAttribute(SelectedMatrixReplay,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"probe shared memory");
    cudaEvent_t begin,end;CheckCuda(cudaEventCreate(&begin),"probe event");CheckCuda(cudaEventCreate(&end),"probe event");
    for(int count:{1,9,16})for(int repetition=-1;repetition<9;++repetition) {
      constexpr int iterations=100;
      CheckCuda(cudaEventRecord(begin,allocation.stream()),"probe event");
      SelectedMatrixReplay<<<count,Threads,bytes,allocation.stream()>>>(dm,dw,iterations);
      CheckCuda(cudaGetLastError(),"probe launch");
      CheckCuda(cudaEventRecord(end,allocation.stream()),"probe event");
      CheckCuda(cudaEventSynchronize(end),"probe event");
      float ms=0;CheckCuda(cudaEventElapsedTime(&ms,begin,end),"probe timing");
      std::vector<Workspace> result(count);allocation.Copy(result.data(),dw,count*sizeof(Workspace),cudaMemcpyDeviceToHost);
      std::uint64_t solves=0,refinements=0,dense=0,factors=0;
      for(int i=0;i<count;++i) {
        if(result[i].progress.error)throw std::runtime_error("selected solver error "+std::to_string(result[i].progress.error));
        std::vector<double> x(models[i].n);allocation.Copy(x.data(),result[i].solution,x.size()*sizeof(double),cudaMemcpyDeviceToHost);
        const auto &sample=samples[(i%9)*16+4];ProbeChecked(ValidateSparseSolution(sample.a,sample.b,x));
        double difference=0,norm=1;for(std::size_t j=0;j<x.size();++j){difference=std::max(difference,std::abs(x[j]-sample.oracle[j]));norm=std::max(norm,std::abs(sample.oracle[j]));}
        if(difference/norm>2e-10)throw std::runtime_error("selected solver KLU differential failure");
        solves+=result[i].progress.solves;refinements+=result[i].progress.refinements;dense+=result[i].progress.dense_factors;factors+=result[i].progress.factors;
        result[i].progress={};
      }
      allocation.Copy(dw,result.data(),count*sizeof(Workspace),cudaMemcpyHostToDevice);
      std::cout<<"{\"kind\":\"selected_timing\",\"count\":"<<count<<",\"repetition\":"<<repetition<<",\"iterations\":"<<iterations<<",\"device_ms\":"<<ms<<",\"solves\":"<<solves<<",\"factors\":"<<factors<<",\"refinements\":"<<refinements<<",\"dense_factors\":"<<dense<<"}\n";
    }
    CheckCuda(cudaEventDestroy(begin),"probe event release");CheckCuda(cudaEventDestroy(end),"probe event release");
  }
  const auto ended=ProbeChecked(EndEmi03CudaJob());
  if(ended.outstanding_device_bytes||ended.cleanup_failures)throw std::runtime_error("selected probe cleanup failure");
  return 0;
}
} // namespace
} // namespace ohmnivore
int main(int argc,char **argv) { try {if(argc!=2)return 2;std::cout<<std::setprecision(17);return ohmnivore::MatrixProbe(argv[1]);}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;} }
