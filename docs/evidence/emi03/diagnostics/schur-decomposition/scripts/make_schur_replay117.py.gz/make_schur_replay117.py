from pathlib import Path
import json
w=Path('/home/adam/emi03-work');p=json.loads((w/'schur-structure117.json').read_text())
matrices=[(folder.name,json.loads(line)) for folder in sorted((w/'schur-snapshots107').glob('*-*')) if folder.is_dir() for line in (folder/'matrices.jsonl').read_text().splitlines()]
with (w/'schur-replay117.txt').open('w') as f:
 def line(*x):f.write(' '.join(str(v) for v in x)+'\n')
 line('EMI03_SCHUR_REPLAY_1');line(p['unknowns'],len(p['interface']),len(p['groups']),len(matrices));line(*[x['index'] for x in p['interface']])
 for g in p['groups']:line(len(g['indices']),*g['indices'])
 for case,m in matrices:
  line(case+'-s'+str(m['sample'])+'-a'+str(int(m['alpha'])),len(m['values']));line(*m['rows']);line(*m['columns']);line(*m['values']);line(*m['rhs']);line(*m['oracle'])
