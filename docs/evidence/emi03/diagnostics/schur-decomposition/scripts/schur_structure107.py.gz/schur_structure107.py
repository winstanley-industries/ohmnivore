from pathlib import Path
import hashlib,json,shlex
w=Path('/home/adam/emi03-work');names={};edges=set();desc={};g={};c={}
for line in (w/'structure-probe.tsv').read_text().splitlines():
 x=shlex.split(line)
 if x[0]=='N':n=int(x[1])
 elif x[0] in ['V','I']:names[int(x[1])]=x[2]
 elif x[0] in ['G','C']:
  row,col=int(x[1]),int(x[2]);value=float(x[3]);(g if x[0]=='G' else c)[row,col]=value
  if value!=0:edges.add((row,col))
 elif x[0]=='D':desc[int(x[1])]={'rows':[],'deps':[]}
 elif x[0]=='P':desc[int(x[1])]['deps'].append(int(x[2]))
 elif x[0]=='R':desc[int(x[1])]['rows'].append(int(x[2]))
for d in desc.values():edges.update((r,c) for r in d['rows'] for c in d['deps'])
model_groups=[{i for i,name in names.items() if '_'+tag+'_' in name.lower()} for tag in ['xdah','xdal','xdbh','xdbl']]
assert [len(x) for x in model_groups]==[32]*4
interior=set.union(*model_groups);ports={col if row in interior else row for row,col in edges if (row in interior)!=(col in interior)}
adj={i:set() for i in range(n)}
for a,b in edges:
 if a!=b:adj[a].add(b);adj[b].add(a)
def components(separator):
 unseen=set(range(n))-separator;groups=[]
 while unseen:
  todo=[min(unseen)];group=set(todo);unseen-=group
  while todo:
   for j in adj[todo.pop()]&unseen:
    unseen.remove(j);group.add(j);todo.append(j)
  groups.append(group)
 return groups
def matching(group):
 match={}
 def augment(row,seen):
  for col in sorted(group):
   if col in seen or (row,col) not in edges:continue
   seen.add(col)
   if col not in match or augment(match[col],seen):match[col]=row;return True
  return False
 failed=[]
 for row in sorted(group):
  if not augment(row,set()):failed.append(row)
 return failed
promoted=[]
while True:
 groups=components(ports);failed=set(j for group in groups for j in matching(group))
 if not failed:break
 ports|=failed;promoted.extend(sorted(failed))
labels={i:k for k,group in enumerate(groups) for i in group}
assert all(a in ports or b in ports or labels[a]==labels[b] for a,b in edges)
report={'scope':'Exact compiled-MNA graph partition analysis, no numerical solver or performance claim','unknowns':n,'interface_size':len(ports),'interface':[{'index':i,'name':names[i]} for i in sorted(ports)],'promoted_to_interface':[names[i] for i in promoted],'interior_sizes':[len(x) for x in groups],'groups':[{'indices':sorted(group),'names':[names[i] for i in sorted(group)],'interface_columns':sorted({b for a,b in edges if a in group and b in ports}),'interface_rows':sorted({a for a,b in edges if a in ports and b in group})} for group in groups],'every_interior_structurally_full_rank':True,'cross_interior_edges':0,'input_sha256':hashlib.sha256((w/'structure-probe.tsv').read_bytes()).hexdigest()}
(w/'schur-structure107.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='groups'},indent=2))
