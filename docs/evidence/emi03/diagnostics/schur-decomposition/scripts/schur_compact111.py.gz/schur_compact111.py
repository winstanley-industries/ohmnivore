from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text()
a=s.index('    for (int i = k + 1 + lane; i < n; i += 32)');b=s.index('\n  }\n  for (int row = lane;',a)
s=s[:a]+'''    int *rows = permutation + n, *columns = permutation + 2 * n;
    int row_count = 0, column_count = 0;
    for (int base = 0; base < n; base += 32) {
      const int index = base + lane;
      const bool lower = index > k && index < n && lu[index * n + k] != 0;
      const bool upper = index > k && index < n && lu[k * n + index] != 0;
      const auto row_mask = __ballot_sync(0xffffffff, lower);
      const auto column_mask = __ballot_sync(0xffffffff, upper);
      const unsigned below = (1U << lane) - 1;
      if (lower) rows[row_count + __popc(row_mask & below)] = index;
      if (upper) columns[column_count + __popc(column_mask & below)] = index;
      row_count += __popc(row_mask);
      column_count += __popc(column_mask);
    }
    __syncwarp();
    for (int at = lane; at < row_count; at += 32)
      lu[rows[at] * n + k] /= lu[k * n + k];
    __syncwarp();
    for (int at = lane; at < row_count * column_count; at += 32) {
      const int row = rows[at / column_count], col = columns[at % column_count];
      lu[row * n + col] = fma(-lu[row * n + k], lu[k * n + col], lu[row * n + col]);
    }
    __syncwarp();'''+s[b:]
s=s.replace('permutations + group * L;', 'permutations + group * L * 3;').replace('permutations[G * L + P]', 'permutations[G * L * 3 + P * 3]').replace('permutations + G * L,','permutations + G * L * 3,')
p.write_text(s)
