from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text()
s=s.replace('#include <stdexcept>','#include <stdexcept>\n#include <set>')
s=s.replace('int port[P]{}, size[G]{}, index[G][L]{}, offset[G]{};', '''int port[P]{}, size[G]{}, index[G][L]{}, offset[G]{}, rhs_offset[G]{};
  int coupling_count[G]{}, coupling_port[G][P]{};
  const int *row_offsets = nullptr, *columns = nullptr;
  const int *interface_offsets = nullptr, *interface_columns = nullptr;''')
s=s.replace('__device__ void Solve(', '__device__ __forceinline__ void Solve(')
s=s.replace('for (int col = 0; col < p.n; ++col) {\n    const double a = -w.a[row * N + col], x = w.x[col];', '''for (int at = p.row_offsets[row]; at < p.row_offsets[row + 1]; ++at) {
    const int col = p.columns[at];
    const double a = -w.a[row * N + col], x = w.x[col];''')
s=s.replace('for (int col = 0; col < p.n; ++col)\n        scale = fmax(scale, fabs(w.a[original * N + col]));', '''for (int at = p.row_offsets[original]; at < p.row_offsets[original + 1]; ++at)
        scale = fmax(scale, fabs(w.a[original * N + p.columns[at]]));''')
a=s.index('    for (int port = lane; port < p.ports; port += 32) {');b=s.index('\n}\n__device__ void Interface',a)
s=s[:a]+'''  }
  const int count = p.coupling_count[group];
  for (int column = lane; column <= count; column += 32) {
    if (correction && column != count)
      continue;
    double *values = storage + p.rhs_offset[group] + column * n;
    for (int row = 0; row < n; ++row) {
      const int original = p.index[group][permutation[row]];
      values[row] = (column == count ? Rhs(p, w, original, correction)
                        : w.a[original * N + p.port[p.coupling_port[group][column]]])
                      / w.scale[original];
    }
    Solve(lu, n, values);
    for (int row = 0; row < n; ++row) {
      const int original = p.index[group][row];
      if (column == count)
        w.q[original] = values[row];
      else
        w.response[original * P + p.coupling_port[group][column]] = values[row];
      if (!isfinite(values[row]))
        atomicExch(&w.error, 2);
    }
  }'''+s[b:]
s=s.replace('''      for (int group = 0; group < p.groups; ++group)
        for (int j = 0; j < p.size[group]; ++j) {
          const int k = p.index[group][j];
          value = fma(-w.a[original * N + k] / scale,
                      w.response[k * P + col], value);
        }''', '''      for (int j = p.interface_offsets[at / p.ports];
           j < p.interface_offsets[at / p.ports + 1]; ++j) {
        const int k = p.interface_columns[j];
        value = fma(-w.a[original * N + k] / scale,
                    w.response[k * P + col], value);
      }''')
s=s.replace('double values[P];', 'double *values = lu + p.ports * p.ports;')
s=s.replace('''      for (int group = 0; group < p.groups; ++group)
        for (int j = 0; j < p.size[group]; ++j) {
          const int k = p.index[group][j];
          value = fma(-w.a[original * N + k] / scale, w.q[k], value);
        }''', '''      for (int j = p.interface_offsets[permutation[row]];
           j < p.interface_offsets[permutation[row] + 1]; ++j) {
        const int k = p.interface_columns[j];
        value = fma(-w.a[original * N + k] / scale, w.q[k], value);
      }''')
s=s.replace('''          for (int col = 0; col < p.ports; ++col)
            value = fma(-w.response[row * P + col], w.interface_solution[col],
                        value);''', '''          for (int at = 0; at < p.coupling_count[group]; ++at) {
            const int col = p.coupling_port[group][at];
            value = fma(-w.response[row * P + col], w.interface_solution[col], value);
          }''')
s=s.replace('(p.storage + p.ports * p.ports) * sizeof(double)', '(p.storage + p.ports * p.ports + p.ports) * sizeof(double)')
# Own all structure storage until kernels are synchronized and finished.
pos=s.index('void Configure(const Plan &p)')
s=s[:pos]+'''struct Structure {
  std::vector<int *> device;
  const int *Upload(const std::vector<int> &values) {
    int *pointer = nullptr;
    Check(cudaMalloc(&pointer, std::max<std::size_t>(1, values.size()) * sizeof(int)));
    Check(cudaMemcpy(pointer, values.data(), values.size() * sizeof(int), cudaMemcpyHostToDevice));
    // The immutable preparation path has no outstanding numerical kernels.
    Check(cudaDeviceSynchronize());
    device.push_back(pointer);
    return pointer;
  }
  void Prepare(Plan &p, const std::vector<Sample> &samples) {
    std::vector<std::set<int>> pattern(p.n);
    for (const auto &sample : samples)
      for (int row = 0; row < p.n; ++row)
        for (auto at = sample.a.row_offsets[row]; at < sample.a.row_offsets[row + 1]; ++at)
          pattern[row].insert(sample.a.column_indices[at]);
    std::vector<int> offsets{0}, columns;
    for (const auto &row : pattern) {
      columns.insert(columns.end(), row.begin(), row.end());
      offsets.push_back(columns.size());
    }
    p.row_offsets = Upload(offsets);
    p.columns = Upload(columns);
    std::set<int> ports(p.port, p.port + p.ports);
    offsets = {0}; columns.clear();
    for (int row = 0; row < p.ports; ++row) {
      for (int col : pattern[p.port[row]])
        if (!ports.contains(col)) columns.push_back(col);
      offsets.push_back(columns.size());
    }
    p.interface_offsets = Upload(offsets);
    p.interface_columns = Upload(columns);
    p.storage = 0;
    for (int group = 0; group < p.groups; ++group) {
      std::set<int> coupled;
      for (int i = 0; i < p.size[group]; ++i)
        for (int port = 0; port < p.ports; ++port)
          if (pattern[p.index[group][i]].contains(p.port[port])) coupled.insert(port);
      p.coupling_count[group] = coupled.size();
      std::copy(coupled.begin(), coupled.end(), p.coupling_port[group]);
      p.offset[group] = p.storage;
      p.storage += p.size[group] * p.size[group];
      p.rhs_offset[group] = p.storage;
      p.storage += p.size[group] * (coupled.size() + 1);
    }
  }
  ~Structure() { for (int *p : device) cudaFree(p); }
};
'''+s[pos:]
# Hostile structural union includes both diagonals, even if their values are zero.
s=s.replace('''  p.storage = 1;
  Configure(p);''', '''  p.storage = 1;
  Sample hostile;
  hostile.a.rows = hostile.a.columns = 2;
  hostile.a.row_offsets = {0, 2, 4};
  hostile.a.column_indices = {0, 1, 0, 1};
  hostile.a.values = {1, 1, 1, 1};
  Structure structure;
  structure.Prepare(p, {hostile});
  Configure(p);''')
s=s.replace('''    std::cout << std::setprecision(17);
    cudaStream_t stream;''', '''    Structure structure;
    structure.Prepare(p, samples);
    std::cout << std::setprecision(17);
    cudaStream_t stream;''')
p.write_text(s)
