from pathlib import Path
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work')
s=(r/'cuda/emi03_resident.cu').read_text();s=s[:s.index('Model Prepare(')];s=s.replace('#include "cuda/emi03_resident_device.cuh"','#define Emi03Advance UnusedAdvanceInMatrixProbe\n#include "cuda/emi03_resident_device.cuh"\n#undef Emi03Advance')
s='#include <fstream>\n#include <iomanip>\n#include <iostream>\n#include <stdexcept>\n#include "cuda/emi03_real_solver.h"\n#include "ohmnivore/solver.h"\n'+s
init=(r/'cuda/emi03_resident_device.cuh').read_text();init=init[init.index('  __shared__ Shared s;',init.index('extern "C" __global__ void Emi03Advance')):init.index('  const auto dense_before =',init.index('extern "C" __global__ void Emi03Advance'))];init=init.replace('  const auto cycles = clock64();\n','')
t=(w/'selected_probe119_tail.cc').read_text().replace('  // INITIALIZATION_FROM_SELECTED_KERNEL',init)
(r/'cuda/emi03_selected_matrix_probe.cu').write_text(s+t)
p=r/'cuda/BUILD.bazel';s=p.read_text();s+='''
cuda_library(
    name = "emi03_selected_matrix_probe_impl",
    srcs = ["emi03_selected_matrix_probe.cu"],
    copts = ["-std=c++20", "--fmad=false", "-lineinfo", "-Xcompiler=-Wall", "-Xcompiler=-Werror", "-Xcompiler=-Wextra"],
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_cuda", "@suitesparse_7_12_3//:klu"],
)
cc_binary(
    name = "emi03_selected_matrix_probe",
    testonly = True,
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_selected_matrix_probe_impl"],
)
''';p.write_text(s)
