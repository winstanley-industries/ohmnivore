from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text().replace('unsigned long long cycles[3];','unsigned long long cycles[3], detail[G + 1][3];')
a=s.index('__device__ void Interior');b=s.index('__device__ void Interface',a);t=s[a:b]
t=t.replace('  if (!correction) {','  auto stamp = clock64();\n  if (!correction) {',1)
t=t.replace('  const int coupled =', '  if (lane == 0) w.detail[group][0] += clock64() - stamp;\n  stamp = clock64();\n  const int coupled =',1)
t=t.replace('  Solve(lu, n, values, count);', '  if (lane == 0) w.detail[group][1] += clock64() - stamp;\n  stamp = clock64();\n  Solve(lu, n, values, count);',1)
pos=t.rindex('\n}');t=t[:pos]+'\n  if (lane == 0) w.detail[group][2] += clock64() - stamp;'+t[pos:];s=s[:a]+t+s[b:]
a=s.index('__device__ void Interface');b=s.index('template <bool Cluster>',a);t=s[a:b]
t=t.replace('  if (!correction) {','  auto stamp = clock64();\n  if (!correction) {',1)
t=t.replace('  double *values =', '  if (lane == 0) w.detail[p.groups][0] += clock64() - stamp;\n  stamp = clock64();\n  double *values =',1)
t=t.replace('  Solve(lu, p.ports, values, 1);', '  if (lane == 0) w.detail[p.groups][1] += clock64() - stamp;\n  stamp = clock64();\n  Solve(lu, p.ports, values, 1);',1)
pos=t.rindex('\n}');t=t[:pos]+'\n  if (lane == 0) w.detail[p.groups][2] += clock64() - stamp;'+t[pos:];s=s[:a]+t+s[b:]
s=s.replace('''  for (int iteration = 0; iteration < iterations; ++iteration) {''','''  if (rank == 0)
    for (int at = threadIdx.x; at < (p.groups + 1) * 3; at += blockDim.x)
      w.detail[at / 3][at % 3] = 0;
  for (int iteration = 0; iteration < iterations; ++iteration) {''',1)
needle='''<< output[0].cycles[1] << "," << output[0].cycles[2] << "]}\\n";'''
assert needle in s
s=s.replace(needle,'''<< output[0].cycles[1] << "," << output[0].cycles[2] << "],\\\"detail\\\":[";
        for (int group = 0; group <= p.groups; ++group) {
          if (group) std::cout << ',';
          std::cout << '[' << output[0].detail[group][0] << ',' << output[0].detail[group][1] << ',' << output[0].detail[group][2] << ']';
        }
        std::cout << "]}\\n";''')
p.write_text(s)
