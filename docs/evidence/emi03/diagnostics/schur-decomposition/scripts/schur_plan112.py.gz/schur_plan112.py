from pathlib import Path
p=Path('/home/adam/code/ohmnivore/cuda/emi03_schur_probe.cu');s=p.read_text();pos=s.index('// Each lane owns')
s=s[:pos]+'''// Reuse only the row ordering. Rebuild the symbolic fill from this actual
// matrix; a failed pivot returns to the bounded local partial-pivot factor.
__device__ bool OrderedFactor(double *lu, int n, unsigned long long *masks) {
  const int lane = threadIdx.x & 31;
  for (int row = lane; row < n; row += 32) {
    unsigned long long pattern = 0;
    for (int col = 0; col < n; ++col)
      if (lu[row * n + col] != 0) pattern |= 1ULL << col;
    masks[row] = pattern;
  }
  __syncwarp();
  for (int k = 0; k < n; ++k) {
    const auto upper = k == 63 ? 0ULL : masks[k] & (~0ULL << (k + 1));
    for (int row = k + 1 + lane; row < n; row += 32)
      if (masks[row] & (1ULL << k)) masks[row] |= upper;
    __syncwarp();
  }
  for (int row = lane; row < n; row += 32) {
    masks[n + row] = row == 63 ? 0ULL : masks[row] & (~0ULL << (row + 1));
    masks[row] &= (1ULL << row) - 1;
  }
  __syncwarp();
  for (int k = 0; k < n; ++k) {
    bool bad = false;
    for (int col = k + lane; col < n; col += 32) {
      double value = lu[k * n + col];
      auto active = masks[k];
      while (active) {
        const int j = __ffsll(active) - 1;
        value = fma(-lu[k * n + j], lu[j * n + col], value);
        active &= active - 1;
      }
      lu[k * n + col] = value;
      bad |= !isfinite(value);
    }
    __syncwarp();
    if (__any_sync(0xffffffff, bad) ||
        !(fabs(lu[k * n + k]) >= 2.2250738585072014e-308)) return false;
    for (int row = k + 1 + lane; row < n; row += 32) {
      if (!(masks[row] & (1ULL << k))) continue;
      double value = lu[row * n + k];
      auto active = masks[row] & ((1ULL << k) - 1);
      while (active) {
        const int j = __ffsll(active) - 1;
        value = fma(-lu[row * n + j], lu[j * n + k], value);
        active &= active - 1;
      }
      lu[row * n + k] = value / lu[k * n + k];
      bad |= !isfinite(lu[row * n + k]);
    }
    __syncwarp();
    if (__any_sync(0xffffffff, bad)) return false;
  }
  return true;
}
'''+s[pos:]
s=s.replace('bool correction) {\n  const int lane = threadIdx.x & 31, n = p.size[group];','bool correction, bool ordered) {\n  const int lane = threadIdx.x & 31, n = p.size[group];')
a=s.index('    for (int at = lane; at < n * n; at += 32) {',s.index('__device__ void Interior'));b=s.index('\n  }\n  const int count',a)
s=s[:a]+'''    for (int attempt = 0; attempt < 2; ++attempt) {
      const bool reuse = ordered && attempt == 0;
      for (int at = lane; at < n * n; at += 32) {
        const int row = p.index[group][reuse ? permutation[at / n] : at / n];
        const double value = w.a[row * N + p.index[group][at % n]];
        lu[at] = value / w.scale[row];
        if (!isfinite(lu[at]) || (value != 0 && lu[at] == 0)) atomicExch(&w.error, 2);
      }
      __syncwarp();
      if (reuse) {
        if (OrderedFactor(lu, n, masks)) break;
      } else {
        if (!Factor(lu, n, permutation, w, group, masks)) return;
        break;
      }
    }'''+s[b:]
s=s.replace('Interior(p, w, group, storage, permutations, masks, pass != 0);','Interior(p, w, group, storage, permutations, masks, pass != 0, iteration > 0);')
# Keep the tiny interface pivoted afresh; cached local order cannot weaken S rank checks.
s=s.replace('Launch(p, device, count, 1, cluster, stream);','Launch(p, device, count, 2, cluster, stream);')
p.write_text(s)
