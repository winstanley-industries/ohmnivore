exec(open('/home/adam/emi03-work/schur_structure107.py').read().split('report=')[0])
from itertools import combinations
base=set(ports);network=sorted(groups[0]);records=[]
for count in [1,2,3]:
 for extra in combinations(network,count):
  separator=base|set(extra)
  while True:
   sub=components(separator);bad=set(x for g in sub for x in matching(g))
   if not bad:break
   separator|=bad
  sizes=sorted([len(g) for g in sub],reverse=True)
  if max(len(g & set(network)) for g in sub)>31:continue
  signature=tuple(sorted(separator))
  records.append({'interface':signature,'sizes':sizes,'score':len(separator)**3+sum(x**3 for x in sizes[:1]),'network_largest':max(len(g & set(network)) for g in sub)})
by={r['interface']:r for r in records};records=sorted(by.values(),key=lambda r:(r['score'],r['network_largest'],len(r['interface'])))
for r in records[:12]:print({**r,'extra_names':[names[i] for i in r['interface'] if i not in base]})
(w/'schur-partitions117.json').write_text(json.dumps(records,indent=2)+'\n')
best=records[0];ports=set(best['interface']);groups=components(ports)
report={'scope':'Structural second-level partition of the passive interior; numerical feasibility must be tested','unknowns':n,'interface_size':len(ports),'interface':[{'index':i,'name':names[i]} for i in sorted(ports)],'interior_sizes':[len(x) for x in groups],'groups':[{'indices':sorted(group),'names':[names[i] for i in sorted(group)],'interface_columns':sorted({b for a,b in edges if a in group and b in ports}),'interface_rows':sorted({a for a,b in edges if a in ports and b in group})} for group in groups]}
(w/'schur-structure117.json').write_text(json.dumps(report,indent=2)+'\n')
