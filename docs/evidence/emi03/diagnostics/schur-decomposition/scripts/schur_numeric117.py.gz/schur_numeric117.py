from reference.emi03 import ensemble as e
from pathlib import Path
import hashlib,json
np=e.metrics.np
w=Path('/home/adam/emi03-work'); out=w/'schur-snapshots107'
partition=json.loads((w/'schur-structure117.json').read_text()); ports=np.array([p['index'] for p in partition['interface']]); groups=[np.array(g['indices']) for g in partition['groups']]
records=[]
def residual(a,b,x):
 aa=a.astype(np.longdouble);bb=b.astype(np.longdouble);xx=x.astype(np.longdouble)
 r=bb-aa@xx; denom=abs(bb)+abs(aa)@abs(xx); scale=np.maximum(abs(aa).max(axis=1),abs(bb));scale[scale==0]=1
 component=np.max(np.divide(abs(r),denom,out=np.zeros_like(r),where=denom!=0))
 norm=np.max(abs(r)/scale)/(np.max(abs(aa).sum(axis=1)/scale)*np.max(abs(xx))+np.max(abs(bb)/scale))
 return r.astype(float),float(norm),float(component)
for folder in sorted(out.glob('*-*')):
 if not folder.is_dir():continue
 for line in (folder/'matrices.jsonl').read_text().splitlines():
  m=json.loads(line);n=m['n'];a=np.zeros((n,n));b=np.array(m['rhs']);ref=np.array(m['oracle'])
  for i in range(n):a[i,np.array(m['columns'][m['rows'][i]:m['rows'][i+1]])]=m['values'][m['rows'][i]:m['rows'][i+1]]
  row={'case':folder.name,'sample':m['sample'],'time_s':m['time_s'],'alpha':m['alpha']}
  try:
   assert n==partition['unknowns']
   for p in partition['interface']:assert m['names'][p['index']]==p['name']
   for g in partition['groups']:assert [m['names'][i] for i in g['indices']]==g['names']
   for i,g in enumerate(groups):
    for h in groups[i+1:]:assert not np.any(a[np.ix_(g,h)]) and not np.any(a[np.ix_(h,g)])
   scale=abs(a).max(axis=1);assert np.all(scale>0);aa=a/scale[:,None]
   ds=[aa[np.ix_(g,g)] for g in groups];fs=[aa[np.ix_(ports,g)] for g in groups]
   ps=[np.linalg.solve(d,aa[np.ix_(g,ports)]) for d,g in zip(ds,groups)]
   s=aa[np.ix_(ports,ports)].copy()
   for f,p in zip(fs,ps):s-=f@p
   row['local_condition_inf']=[float(np.linalg.cond(d,np.inf)) for d in ds];row['interface_condition_inf']=float(np.linalg.cond(s,np.inf))
   def solve(rhs):
    bb=rhs/scale;qs=[np.linalg.solve(d,bb[g]) for d,g in zip(ds,groups)];v=bb[ports].copy()
    for f,q in zip(fs,qs):v-=f@q
    y=np.linalg.solve(s,v);x=np.empty(n);x[ports]=y
    for g,q,p in zip(groups,qs,ps):x[g]=q-p@y
    return x
   x=solve(b);history=[]
   for attempt in range(5):
    r,norm,component=residual(a,b,x);history.append({'normwise':norm,'componentwise':component})
    if not np.any(r) or (attempt>0 and norm<=1e-10 and component<=1e-5):break
    if attempt<4:x+=solve(r)
   row.update(status='pass' if norm<=1e-10 and component<=1e-5 else 'residual_failure',refinements=len(history)-1,residual_history=history,max_absolute_klu_difference=float(np.max(abs(x-ref))),relative_inf_klu_difference=float(np.max(abs(x-ref))/max(1,np.max(abs(ref)))))
  except (AssertionError,np.linalg.LinAlgError) as error:row.update(status='failure',error=str(error))
  records.append(row)
summary={'scope':'Offline FP64 Schur feasibility on accepted-state Jacobians and manufactured RHS; numpy residual evaluation, not canonical C++ validation, not transient qualification or performance','matrices':len(records),'passed':sum(r['status']=='pass' for r in records),'failed':sum(r['status']!='pass' for r in records),'structure_sha256':hashlib.sha256((w/'schur-structure117.json').read_bytes()).hexdigest(),'records':records}
(out/'numeric-feasibility117.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2))
if summary['failed']:print(json.dumps([r for r in records if r['status']!='pass'],indent=2))
else:
 print('max KLU relative difference',max(r['relative_inf_klu_difference'] for r in records));print('max local conditions',[max(r['local_condition_inf'][j] for r in records) for j in range(len(groups))]);print('max interface condition',max(r['interface_condition_inf'] for r in records));print('max refinements',max(r['refinements'] for r in records));print('max final residuals',[max(r['residual_history'][-1][k] for r in records) for k in ['normwise','componentwise']])
raise SystemExit(bool(summary['failed']))
