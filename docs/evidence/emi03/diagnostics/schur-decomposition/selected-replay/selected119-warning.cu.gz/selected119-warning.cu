#include "cuda/emi03_cuda_internal.h"
#include "cuda/emi03_expression_device.cuh"
#include "cuda/emi03_real_solver.h"
#include "cuda/emi03_reduction.cuh"
#include "cuda/emi03_resident.h"
#include "ohmnivore/behavioral.h"
#include "ohmnivore/nonlinear.h"
#include "ohmnivore/solver.h"
#include "ohmnivore/waveform.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>

#include <klu.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <limits>
#include <memory>
#include <thread>
#include <utility>
#include <vector>

namespace ohmnivore {
namespace {
using namespace emi03_device;
using emi03_cuda_internal::BackendError;
using emi03_cuda_internal::CheckCuda;
#define Emi03Advance UnusedAdvanceInMatrixProbe
#include "cuda/emi03_resident_device.cuh"
#undef Emi03Advance

class HostStaging {
public:
  static constexpr std::size_t kBytes = Chunk * (N + 1) * sizeof(double);
  HostStaging() {
    CheckCuda(cudaHostAlloc(&data_, kBytes, cudaHostAllocDefault),
              "resident private pinned transfer staging");
  }
  HostStaging(const HostStaging &) = delete;
  HostStaging &operator=(const HostStaging &) = delete;
  ~HostStaging() {
    if (data_ && cudaFreeHost(data_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
  }
  void *data() const { return data_; }

private:
  void *data_ = nullptr;
};
class Allocations {
public:
  explicit Allocations(HostStaging &staging, cudaStream_t consumer = nullptr)
      : staging_(staging), consumer_(consumer) {
    CheckCuda(cudaStreamCreateWithFlags(&stream_, cudaStreamNonBlocking),
              "resident stream creation");
  }
  Allocations(const Allocations &) = delete;
  Allocations &operator=(const Allocations &) = delete;
  cudaStream_t stream() const { return stream_; }
  HostStaging &staging() const { return staging_; }
  void Copy(void *destination, const void *source, std::size_t bytes,
            cudaMemcpyKind kind) {
    if (kind != cudaMemcpyHostToDevice && kind != cudaMemcpyDeviceToHost)
      throw BackendError(ErrorCode::kUnsupported, "resident copy direction");
    // Pageable asynchronous copies can spin in the driver before returning.
    // Keep bounded pinned staging private to each job. Every copy completes
    // before another stream within this job uses that storage. Completion
    // queries sleep between attempts: blocking event waits still consumed a CPU
    // core on the measured WSL driver. All waiting remains in charged wall
    // time.
    if (!completed_)
      CheckCuda(
          cudaEventCreateWithFlags(&completed_, cudaEventBlockingSync |
                                                    cudaEventDisableTiming),
          "resident blocking completion event");
    for (std::size_t offset = 0; offset < bytes;
         offset += HostStaging::kBytes) {
      const auto count = std::min(HostStaging::kBytes, bytes - offset);
      auto *target = static_cast<unsigned char *>(destination) + offset;
      const auto *input = static_cast<const unsigned char *>(source) + offset;
      if (kind == cudaMemcpyHostToDevice)
        std::memcpy(staging_.data(), input, count);
      CheckCuda(cudaMemcpyAsync(
                    kind == cudaMemcpyHostToDevice ? target : staging_.data(),
                    kind == cudaMemcpyHostToDevice ? staging_.data() : input,
                    count, kind, stream_),
                "resident stream copy");
      CheckCuda(cudaEventRecord(completed_, stream_),
                "resident completion event record");
      const auto start = std::chrono::steady_clock::now();
      auto status = cudaEventQuery(completed_);
      while (status == cudaErrorNotReady) {
        std::this_thread::sleep_for(std::chrono::microseconds(250));
        status = cudaEventQuery(completed_);
      }
      emi03_cuda_internal::Statistics().synchronization_ns +=
          std::chrono::duration_cast<std::chrono::nanoseconds>(
              std::chrono::steady_clock::now() - start)
              .count();
      CheckCuda(status, "resident completion query");
      if (kind == cudaMemcpyDeviceToHost)
        std::memcpy(target, staging_.data(), count);
    }
  }
  ~Allocations() {
    // Factor metadata is uploaded on this owner's stream, but read by the
    // resident simulation stream. Both must finish before asynchronous release,
    // including exceptional exits before the normal output-copy completion.
    if (consumer_ && consumer_ != stream_ &&
        cudaStreamSynchronize(consumer_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
    if (cudaStreamSynchronize(stream_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
    for (auto it = owned_.rbegin(); it != owned_.rend(); ++it)
      emi03_cuda_internal::FreeDevice(it->first, it->second);
    if (completed_ && cudaEventDestroy(completed_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
    if (cudaStreamDestroy(stream_) != cudaSuccess)
      ++emi03_cuda_internal::Statistics().cleanup_failures;
  }
  template <class T> T *Allocate(std::size_t count) {
    const auto bytes = std::max<std::size_t>(1, count) * sizeof(T);
    void *p = emi03_cuda_internal::AllocateDevice(bytes);
    try {
      owned_.emplace_back(p, bytes);
    } catch (...) {
      emi03_cuda_internal::FreeDevice(p, bytes);
      throw;
    }
    return static_cast<T *>(p);
  }
  template <class T> T *Upload(const std::vector<T> &values) {
    auto *result = Allocate<T>(values.size());
    if (!values.empty()) {
      Copy(result, values.data(), values.size() * sizeof(T),
           cudaMemcpyHostToDevice);
      emi03_cuda_internal::Statistics().upload_bytes +=
          values.size() * sizeof(T);
    }
    return result;
  }

private:
  cudaStream_t stream_ = nullptr;
  cudaEvent_t completed_ = nullptr;
  HostStaging &staging_;
  cudaStream_t consumer_ = nullptr;
  std::vector<std::pair<void *, std::size_t>> owned_;
};
void PrepareFactorPlan(const MnaSystem &system, const TranAnalysis &analysis,
                       const std::vector<double> &initial, Model &model,
                       Allocations &allocation,
                       const std::vector<double> *refresh = nullptr) {
  auto companion = FormTransientCompanionMatrix(system.g, system.c,
                                                analysis.time_step_seconds, 1);
  if (!companion.ok())
    throw BackendError(companion.error().code, companion.error().message);
  auto working = system;
  working.g = companion.TakeValue();
  auto remap = RemapBehavioralDescriptors(&working);
  if (!remap.ok())
    throw BackendError(remap.error().code, remap.error().message);
  auto assembled = BuildNonlinearDcLinearization(working, initial);
  if (!assembled.ok())
    throw BackendError(assembled.error().code, assembled.error().message);
  auto matrix = assembled.value().jacobian;
  if (refresh) {
    if (refresh->size() != matrix.values.size())
      throw BackendError(ErrorCode::kInvalidStructure,
                         "resident refresh structure changed");
    matrix.values = *refresh;
  }
  auto converted = ConvertCsrToSolverCsc(matrix);
  if (!converted.ok())
    throw BackendError(converted.error().code, converted.error().message);
  auto csc = converted.TakeValue();
  klu_common common;
  klu_defaults(&common);
  common.ordering =
      1; // COLAMD: structural ordering only, never a CPU numeric solve.
  const auto release_symbolic = [&common](klu_symbolic *value) {
    if (value)
      klu_free_symbolic(&value, &common);
  };
  std::unique_ptr<klu_symbolic, decltype(release_symbolic)> symbolic(
      klu_analyze(model.n, csc.column_offsets.data(), csc.row_indices.data(),
                  &common),
      release_symbolic);
  if (!symbolic)
    throw BackendError(ErrorCode::kSingular,
                       "resident symbolic ordering failed");
  std::vector<int> q(symbolic->Q, symbolic->Q + model.n);
  std::vector<int> structural_rows(symbolic->P, symbolic->P + model.n);
  symbolic.reset();
  std::vector<int> qi(model.n), p(model.n), pi(model.n);
  for (int j = 0; j < model.n; ++j)
    qi[q[j]] = j;
  {
    Allocations temporary(allocation.staging());
    auto w = std::make_unique<Workspace>();
    std::vector<int> dense_offsets, dense_columns;
    std::vector<double> ordered_values;
    dense_offsets.push_back(0);
    for (int row : structural_rows) {
      for (auto k = matrix.row_offsets[row]; k < matrix.row_offsets[row + 1];
           ++k) {
        dense_columns.push_back(qi[matrix.column_indices[k]]);
        ordered_values.push_back(matrix.values[k]);
      }
      dense_offsets.push_back(static_cast<int>(dense_columns.size()));
    }
    w->jacobian = temporary.Upload(ordered_values);
    w->lu = temporary.Allocate<double>(model.n * N);
    w->equil = temporary.Allocate<double>(model.n);
    w->permutation = temporary.Allocate<int>(model.n);
    auto *device = temporary.Allocate<Workspace>(1);
    auto *error = temporary.Allocate<int>(1);
    auto ordering = model;
    ordering.row_offsets = temporary.Upload(dense_offsets);
    ordering.columns = temporary.Upload(dense_columns);
    temporary.Copy(device, w.get(), sizeof(Workspace), cudaMemcpyHostToDevice);
    DiscoverPivots<<<1, Threads, 0, temporary.stream()>>>(
        ordering, device, error, refresh == nullptr);
    CheckCuda(cudaGetLastError(), "resident pivot discovery launch");
    int status = 0;
    temporary.Copy(&status, error, sizeof(int), cudaMemcpyDeviceToHost);
    if (status)
      throw BackendError(static_cast<ErrorCode>(status - 1),
                         "resident initial GPU pivot discovery failed");
    temporary.Copy(p.data(), w->permutation, model.n * sizeof(int),
                   cudaMemcpyDeviceToHost);
    for (auto &row : p)
      row = structural_rows[row];
    auto &stats = emi03_cuda_internal::Statistics();
    stats.upload_bytes += sizeof(Workspace);
    stats.readback_bytes += (model.n + 1) * sizeof(int);
    ++stats.factorizations;
  }
  for (int j = 0; j < model.n; ++j)
    pi[p[j]] = j;
  std::vector<unsigned char> pattern(model.n * model.n, 0);
  for (int row = 0; row < model.n; ++row)
    for (auto k = matrix.row_offsets[row]; k < matrix.row_offsets[row + 1]; ++k)
      pattern[pi[row] * model.n + qi[matrix.column_indices[k]]] = 1;
  for (int k = 0; k < model.n; ++k)
    for (int row = k + 1; row < model.n; ++row)
      if (pattern[row * model.n + k])
        for (int col = k + 1; col < model.n; ++col)
          pattern[row * model.n + col] |= pattern[k * model.n + col];
  std::vector<int> offsets{0}, columns, diagonal, slots(model.n * model.n, -1);
  for (int row = 0; row < model.n; ++row) {
    for (int col = 0; col < model.n; ++col)
      if (pattern[row * model.n + col]) {
        slots[row * model.n + col] = static_cast<int>(columns.size());
        columns.push_back(col);
      }
    if (slots[row * model.n + row] < 0)
      throw BackendError(ErrorCode::kSingular,
                         "resident missing symbolic pivot");
    diagonal.push_back(slots[row * model.n + row]);
    offsets.push_back(static_cast<int>(columns.size()));
  }
  std::vector<int> inputs;
  for (int row = 0; row < model.n; ++row)
    for (auto k = matrix.row_offsets[row]; k < matrix.row_offsets[row + 1]; ++k)
      inputs.push_back(slots[pi[row] * model.n + qi[matrix.column_indices[k]]]);
  std::vector<FactorEntry> entries(columns.size());
  std::vector<FactorTerm> terms;
  std::vector<int> entry_levels(columns.size(), 0);
  for (int row = 0; row < model.n; ++row)
    for (int slot = offsets[row]; slot < offsets[row + 1]; ++slot) {
      const int col = columns[slot];
      auto &entry = entries[slot];
      if (terms.size() >= (1U << 24))
        throw BackendError(ErrorCode::kUnsupportedSize,
                           "resident factor term encoding bound");
      entry.begin = terms.size();
      entry.diagonal = row > col ? col : -1;
      entry.pivot = row == col ? row : -1;
      for (int k = 0; k < std::min(row, col); ++k) {
        const int lower = slots[row * model.n + k],
                  upper = slots[k * model.n + col];
        if (lower >= 0 && upper >= 0) {
          terms.push_back(FactorTerm{static_cast<std::uint16_t>(lower),
                                     static_cast<std::uint16_t>(upper)});
          entry_levels[slot] =
              std::max(entry_levels[slot],
                       std::max(entry_levels[lower], entry_levels[upper]) + 1);
        }
      }
      if (row > col)
        entry_levels[slot] =
            std::max(entry_levels[slot], entry_levels[diagonal[col]] + 1);
      if (terms.size() - entry.begin > 255)
        throw BackendError(ErrorCode::kUnsupportedSize,
                           "resident factor count encoding bound");
      entry.count = terms.size() - entry.begin;
    }
  model.factor_levels =
      *std::max_element(entry_levels.begin(), entry_levels.end()) + 1;
  std::vector<int> factor_order, factor_starts{0};
  for (int level = 0; level < model.factor_levels; ++level) {
    for (int slot = 0; slot < static_cast<int>(entries.size()); ++slot)
      if (entry_levels[slot] == level)
        factor_order.push_back(slot);
    factor_starts.push_back(static_cast<int>(factor_order.size()));
  }
  model.factor_entries = allocation.Upload(entries);
  model.factor_term = allocation.Upload(terms);
  model.factor_order = allocation.Upload(factor_order);
  model.factor_level_offsets = allocation.Upload(factor_starts);
  model.factor_terms = static_cast<int>(terms.size());
  std::vector<int> forward(model.n, 0), backward(model.n, 0);
  for (int row = 0; row < model.n; ++row)
    for (int j = offsets[row]; j < diagonal[row]; ++j)
      forward[row] = std::max(forward[row], forward[columns[j]] + 1);
  for (int row = model.n - 1; row >= 0; --row)
    for (int j = diagonal[row] + 1; j < offsets[row + 1]; ++j)
      backward[row] = std::max(backward[row], backward[columns[j]] + 1);
  const auto levels = [&](const std::vector<int> &level, const int *&rows,
                          const int *&bounds) {
    const int count = *std::max_element(level.begin(), level.end()) + 1;
    std::vector<int> ordered, starts{0};
    for (int i = 0; i < count; ++i) {
      for (int row = 0; row < model.n; ++row)
        if (level[row] == i)
          ordered.push_back(row);
      starts.push_back(static_cast<int>(ordered.size()));
    }
    rows = allocation.Upload(ordered);
    bounds = allocation.Upload(starts);
    return count;
  };
  model.forward_levels =
      levels(forward, model.forward_rows, model.forward_offsets);
  model.backward_levels =
      levels(backward, model.backward_rows, model.backward_offsets);
  model.factor_nonzeros = static_cast<int>(columns.size());
  model.factor_rows = allocation.Upload(offsets);
  model.factor_columns = allocation.Upload(columns);
  model.factor_diagonal = allocation.Upload(diagonal);
  model.factor_input_slots = allocation.Upload(inputs);
  model.row_permutation = allocation.Upload(p);
  model.column_permutation = allocation.Upload(q);
}
__global__ void SelectedMatrixReplay(const Model *models, Workspace *all,
                                     int iterations) {
  const Model m = models[blockIdx.x];
  Workspace *workspace = all + blockIdx.x;
  __shared__ Shared s;
  auto &w = s.runtime;
  extern __shared__ double storage[];
  if (threadIdx.x == 0) {
    w = *workspace;
    s.error = 0;
    s.factor_valid = false;
    s.active_scale = 0;
    s.factored_scale = -1;
    s.expression_cache_valid = false;
    s.expression_cache_derivatives = false;
    w.progress.output_count = 0;
    s.factor = storage;
    s.triangular = storage + m.factor_nonzeros;
    s.inverse = s.triangular + m.n;
    double *vectors = s.inverse + m.n;
    w.state = vectors + 0 * m.n;
    w.full = vectors + 1 * m.n;
    w.half = vectors + 2 * m.n;
    w.current = vectors + 3 * m.n;
    w.proposed = vectors + 4 * m.n;
    w.delta = vectors + 5 * m.n;
    w.companion_rhs = vectors + 6 * m.n;
    w.affine_rhs = vectors + 7 * m.n;
    w.residual = vectors + 8 * m.n;
    w.row_scale = vectors + 9 * m.n;
    w.solution = vectors + 10 * m.n;
    w.equil = vectors + 11 * m.n;
    w.inverse_equil = vectors + 12 * m.n;
    w.linear_row_norm = vectors + 13 * m.n;
    s.expression_state = vectors + 14 * m.n;
    // Linear correction/forward work finish before the next nonlinear assembly
    // replaces residual/scale. The second half-step result is the final Newton
    // proposal and survives until its error/history checks have consumed it.
    w.correction = w.residual;
    w.work = w.row_scale;
    w.second = w.proposed;
    w.history_current = vectors + 15 * m.n;
    w.history_older = w.history_current + m.reactive;
    w.history_trial = w.history_older + m.reactive;
    w.base = w.history_trial + m.reactive;
    w.jacobian = w.base + m.nnz;
    w.gradients = w.jacobian + m.nnz;
    w.expressions =
        reinterpret_cast<DeviceResult *>(w.gradients + m.dependency_count);
    s.expression_values =
        reinterpret_cast<double *>(w.expressions + m.programs);
    s.expression_adjoints = s.expression_values + m.expression_node_count;
    s.expression_active = reinterpret_cast<unsigned char *>(
        s.expression_adjoints + m.expression_node_count);
    s.factor_columns = reinterpret_cast<int *>(
        (reinterpret_cast<std::uintptr_t>(s.expression_active +
                                          m.expression_node_count) +
         7) &
        ~std::uintptr_t{7});
    s.factor_order = s.factor_columns + m.factor_nonzeros;
    s.factor_level_offsets = s.factor_order + m.factor_nonzeros;
    s.factor_entries = m.factor_entries;
    s.factor_term = m.factor_term;
    auto end = (reinterpret_cast<std::uintptr_t>(s.factor_level_offsets +
                                                 m.factor_levels + 1) +
                7) &
               ~std::uintptr_t{7};
    if (m.shared_factor_metadata) {
      s.factor_entries = reinterpret_cast<const FactorEntry *>(end);
      s.factor_term = reinterpret_cast<const FactorTerm *>(s.factor_entries +
                                                           m.factor_nonzeros);
      end = (reinterpret_cast<std::uintptr_t>(s.factor_term + m.factor_terms) +
             7) &
            ~std::uintptr_t{7};
    }
    s.expression_nodes =
        m.shared_expression_metadata
            ? reinterpret_cast<const PackedExpressionNode *>(end)
            : m.parallel_nodes;
    if (m.shared_expression_metadata)
      end += m.expression_node_count * sizeof(PackedExpressionNode);
    s.matrix_rows =
        m.shared_structure ? reinterpret_cast<const int *>(end) : m.row_offsets;
    s.matrix_columns = m.shared_structure ? s.matrix_rows + m.n + 1 : m.columns;
  }
  __syncthreads();
  if (m.shared_structure) {
    for (int i = threadIdx.x; i <= m.n; i += Threads)
      const_cast<int *>(s.matrix_rows)[i] = m.row_offsets[i];
    for (int i = threadIdx.x; i < m.nnz; i += Threads)
      const_cast<int *>(s.matrix_columns)[i] = m.columns[i];
  }
  for (int i = threadIdx.x; i < m.n; i += Threads) {
    w.state[i] = workspace->state[i];
    if (i < m.reactive) {
      w.history_current[i] = workspace->history_current[i];
      w.history_older[i] = workspace->history_older[i];
      w.history_trial[i] = workspace->history_trial[i];
    }
    s.factor_diagonal[i] = m.factor_diagonal[i];
    s.row_permutation[i] = m.row_permutation[i];
    s.column_permutation[i] = m.column_permutation[i];
    s.forward_rows[i] = m.forward_rows[i];
    s.backward_rows[i] = m.backward_rows[i];
  }
  for (int i = threadIdx.x; i <= m.n; i += Threads) {
    s.factor_rows[i] = m.factor_rows[i];
  }
  for (int i = threadIdx.x; i <= m.forward_levels; i += Threads)
    s.forward_offsets[i] = m.forward_offsets[i];
  for (int i = threadIdx.x; i <= m.backward_levels; i += Threads)
    s.backward_offsets[i] = m.backward_offsets[i];
  for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
    s.factor_columns[i] = m.factor_columns[i];
  for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
    s.factor_order[i] = m.factor_order[i];
  for (int i = threadIdx.x; i <= m.factor_levels; i += Threads)
    s.factor_level_offsets[i] = m.factor_level_offsets[i];
  __syncthreads();
  if (m.shared_factor_metadata) {
    for (int i = threadIdx.x; i < m.factor_nonzeros; i += Threads)
      const_cast<FactorEntry *>(s.factor_entries)[i] = m.factor_entries[i];
    for (int i = threadIdx.x; i < m.factor_terms; i += Threads)
      const_cast<FactorTerm *>(s.factor_term)[i] = m.factor_term[i];
  }
  if (m.shared_expression_metadata)
    for (int index = threadIdx.x; index < m.expression_node_count;
         index += Threads)
      const_cast<PackedExpressionNode *>(s.expression_nodes)[index] =
          m.parallel_nodes[index];
  __syncthreads();

  for (int i = threadIdx.x; i < m.n; i += Threads)
    w.affine_rhs[i] = workspace->affine_rhs[i];
  for (int i = threadIdx.x; i < m.nnz; i += Threads)
    w.jacobian[i] = workspace->jacobian[i];
  __syncthreads();
  for (int i = 0; i < iterations && !s.error; ++i) {
    if (threadIdx.x == 0)
      s.factor_valid = false;
    __syncthreads();
    Linear(m, w, s);
  }
  for (int i = threadIdx.x; i < m.n; i += Threads)
    workspace->solution[i] = w.solution[i];
  if (threadIdx.x == 0) {
    w.progress.error = s.error;
    workspace->progress = w.progress;
  }
}
template <class T> T ProbeChecked(Result<T> result) {
  if (!result.ok())
    throw std::runtime_error(result.error().message);
  return result.TakeValue();
}
struct ProbeSample {
  std::string name;
  CsrMatrix a;
  std::vector<double> b, oracle;
};
std::vector<ProbeSample> ReadProbe(const char *path) {
  std::ifstream input(path);
  std::string magic;
  int n = 0, ports = 0, groups = 0, count = 0;
  input >> magic >> n >> ports >> groups >> count;
  if (!input || magic != "EMI03_SCHUR_REPLAY_1" || n != 185 || ports != 14 ||
      groups != 15 || count != 144)
    throw std::runtime_error("invalid frozen replay");
  int ignored;
  for (int i = 0; i < ports; ++i)
    input >> ignored;
  for (int g = 0; g < groups; ++g) {
    int size = 0;
    input >> size;
    if (size < 1 || size > 64)
      throw std::runtime_error("bad group");
    for (int i = 0; i < size; ++i)
      input >> ignored;
  }
  std::vector<ProbeSample> samples(count);
  for (auto &s : samples) {
    std::size_t nnz = 0;
    input >> s.name >> nnz;
    if (!input || nnz > static_cast<std::size_t>(n * n))
      throw std::runtime_error("bad matrix");
    s.a.rows = s.a.columns = n;
    s.a.row_offsets.resize(n + 1);
    s.a.column_indices.resize(nnz);
    s.a.values.resize(nnz);
    s.b.resize(n);
    s.oracle.resize(n);
    for (auto &x : s.a.row_offsets)
      input >> x;
    for (auto &x : s.a.column_indices)
      input >> x;
    for (auto &x : s.a.values)
      input >> x;
    for (auto &x : s.b)
      input >> x;
    for (auto &x : s.oracle)
      input >> x;
    if (!input)
      throw std::runtime_error("truncated matrix");
    ProbeChecked(ValidateSparseSolution(s.a, s.b, s.oracle));
  }
  return samples;
}
std::size_t ProbePrepare(const ProbeSample &sample, Allocations &allocation,
                         Model &m, Workspace &w) {
  const int n = sample.a.rows;
  MnaSystem system;
  system.g = sample.a;
  system.c.rows = system.c.columns = n;
  system.c.row_offsets.resize(n + 1);
  system.b_dc.resize(n);
  system.b_ac.resize(n);
  for (int i = 0; i < n; ++i)
    system.node_names.push_back("v" + std::to_string(i));
  TranAnalysis analysis{1, 1, 0, false};
  m.n = m.nodes = n;
  m.nnz = sample.a.values.size();
  PrepareFactorPlan(system, analysis, std::vector<double>(n), m, allocation);
  m.row_offsets = allocation.Upload(std::vector<int>(
      sample.a.row_offsets.begin(), sample.a.row_offsets.end()));
  m.columns = allocation.Upload(std::vector<int>(
      sample.a.column_indices.begin(), sample.a.column_indices.end()));
  w.state = allocation.Upload(std::vector<double>(n));
  w.affine_rhs = allocation.Upload(sample.b);
  w.jacobian = allocation.Upload(sample.a.values);
  w.solution = allocation.Allocate<double>(n);
  w.factored_jacobian = allocation.Allocate<double>(m.nnz);
  w.lu = allocation.Allocate<double>(n * N);
  w.permutation = allocation.Allocate<int>(n);
  w.last_dynamic_jacobian = nullptr;
  std::size_t bytes =
      ((m.factor_nonzeros + 17 * n + 2 * m.nnz) * sizeof(double) + 7) / 8 * 8 +
      (2 * m.factor_nonzeros + m.factor_levels + 1) * sizeof(int);
  bytes = (bytes + 7) / 8 * 8;
  m.shared_factor_metadata = true;
  m.shared_structure = true;
  bytes = (bytes + m.factor_nonzeros * sizeof(FactorEntry) +
           m.factor_terms * sizeof(FactorTerm) + 7) /
          8 * 8;
  bytes += (n + 1 + m.nnz) * sizeof(int);
  return bytes;
}
int MatrixProbe(const char *path) {
  auto samples = ReadProbe(path);
  ProbeChecked(BeginEmi03CudaJob("selected-matrix-probe"));
  {
    HostStaging staging;
    Allocations allocation(staging);
    std::vector<Model> models(16);
    std::vector<Workspace> workspace(16);
    std::size_t bytes = 0;
    for (int i = 0; i < 16; ++i)
      bytes =
          std::max(bytes, ProbePrepare(samples[(i % 9) * 16 + 4], allocation,
                                       models[i], workspace[i]));
    auto *dm = allocation.Upload(models);
    auto *dw = allocation.Upload(workspace);
    CheckCuda(cudaFuncSetAttribute(SelectedMatrixReplay,
                                   cudaFuncAttributeMaxDynamicSharedMemorySize,
                                   bytes),
              "probe shared memory");
    cudaEvent_t begin, end;
    CheckCuda(cudaEventCreate(&begin), "probe event");
    CheckCuda(cudaEventCreate(&end), "probe event");
    for (int count : {1, 9, 16})
      for (int repetition = -1; repetition < 9; ++repetition) {
        constexpr int iterations = 100;
        CheckCuda(cudaEventRecord(begin, allocation.stream()), "probe event");
        SelectedMatrixReplay<<<count, Threads, bytes, allocation.stream()>>>(
            dm, dw, iterations);
        CheckCuda(cudaGetLastError(), "probe launch");
        CheckCuda(cudaEventRecord(end, allocation.stream()), "probe event");
        CheckCuda(cudaEventSynchronize(end), "probe event");
        float ms = 0;
        CheckCuda(cudaEventElapsedTime(&ms, begin, end), "probe timing");
        std::vector<Workspace> result(count);
        allocation.Copy(result.data(), dw, count * sizeof(Workspace),
                        cudaMemcpyDeviceToHost);
        std::uint64_t solves = 0, refinements = 0, dense = 0, factors = 0;
        for (int i = 0; i < count; ++i) {
          if (result[i].progress.error)
            throw std::runtime_error("selected solver error " +
                                     std::to_string(result[i].progress.error));
          std::vector<double> x(models[i].n);
          allocation.Copy(x.data(), result[i].solution,
                          x.size() * sizeof(double), cudaMemcpyDeviceToHost);
          const auto &sample = samples[(i % 9) * 16 + 4];
          ProbeChecked(ValidateSparseSolution(sample.a, sample.b, x));
          double difference = 0, norm = 1;
          for (std::size_t j = 0; j < x.size(); ++j) {
            difference =
                std::max(difference, std::abs(x[j] - sample.oracle[j]));
            norm = std::max(norm, std::abs(sample.oracle[j]));
          }
          if (difference / norm > 2e-10)
            throw std::runtime_error(
                "selected solver KLU differential failure");
          solves += result[i].progress.solves;
          refinements += result[i].progress.refinements;
          dense += result[i].progress.dense_factors;
          factors += result[i].progress.factors;
          result[i].progress = {};
        }
        allocation.Copy(dw, result.data(), count * sizeof(Workspace),
                        cudaMemcpyHostToDevice);
        std::cout << "{\"kind\":\"selected_timing\",\"count\":" << count
                  << ",\"repetition\":" << repetition
                  << ",\"iterations\":" << iterations << ",\"device_ms\":" << ms
                  << ",\"solves\":" << solves << ",\"factors\":" << factors
                  << ",\"refinements\":" << refinements
                  << ",\"dense_factors\":" << dense << "}\n";
      }
    CheckCuda(cudaEventDestroy(begin), "probe event release");
    CheckCuda(cudaEventDestroy(end), "probe event release");
  }
  const auto ended = ProbeChecked(EndEmi03CudaJob());
  if (ended.outstanding_device_bytes || ended.cleanup_failures)
    throw std::runtime_error("selected probe cleanup failure");
  return 0;
}
} // namespace
} // namespace ohmnivore
int main(int argc, char **argv) {
  try {
    if (argc != 2)
      return 2;
    std::cout << std::setprecision(17);
    return ohmnivore::MatrixProbe(argv[1]);
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
