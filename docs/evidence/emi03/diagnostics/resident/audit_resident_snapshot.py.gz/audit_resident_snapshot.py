from pathlib import Path
import gzip, hashlib, io, json, math, os, re, struct, subprocess, tarfile, tempfile

root = Path('/home/adam/code/ohmnivore')
out = root / 'docs/evidence/emi03/diagnostics/resident'
identity = json.loads((out/'identity.json').read_text())
patch = gzip.decompress((out/'source.patch.gz').read_bytes())
assert hashlib.sha256(patch).hexdigest() == identity['source_patch_sha256']
with tempfile.TemporaryDirectory(prefix='resident-source-audit-', dir='/home/adam/emi03-work/tmp') as name:
    scratch = Path(name)
    archived = subprocess.check_output(['git','archive',identity['base_commit'],'cpp','cuda','.bazelrc','MODULE.bazel','MODULE.bazel.lock'], cwd=root)
    with tarfile.open(fileobj=io.BytesIO(archived)) as archive:
        archive.extractall(scratch, filter='data')
    subprocess.run(['git','apply','--'], input=patch, cwd=scratch, check=True)
    for path, expected in identity['source_files'].items():
        assert hashlib.sha256((scratch/path).read_bytes()).hexdigest() == expected, path
runfiles = (root/'bazel-bin/reference/emi03/ensemble.runfiles').resolve()
assert hashlib.sha256(Path('/home/adam/emi03-work/bin/emi03_resident_worker').read_bytes()).hexdigest() == identity['gpu_binary_sha256']
assert hashlib.sha256((runfiles/'_main/cpp/emi03_cpu_worker').read_bytes()).hexdigest() == identity['cpu_binary_sha256']
raws = json.loads((out/'raw-index.json').read_text())
counts = {}
for path, expected in raws.items():
    encoded = (out/path).read_bytes()
    raw = gzip.decompress(encoded)
    assert len(encoded) == expected['gzip_bytes']
    assert hashlib.sha256(encoded).hexdigest() == expected['gzip_sha256']
    assert len(raw) == expected['raw_bytes']
    assert hashlib.sha256(raw).hexdigest() == expected['raw_sha256']
    start = raw.index(b'Binary:\n') + len(b'Binary:\n')
    header = raw[:start].decode()
    variables = int(re.search(r'No\. Variables: (\d+)', header)[1])
    points = int(re.search(r'No\. Points: (\d+)', header)[1])
    width = variables * 8
    assert len(raw) - start == points * width
    stop, maximum_step = (16 * 1e-6, 2e-9) if path.startswith('dpt-q0/') else (200 * 1e-6, 625e-12)
    previous = -1.0
    for index in range(points):
        time = struct.unpack_from('<d', raw, start + index * width)[0]
        assert math.isfinite(time) and previous < time <= stop
        if previous >= 0: assert time - previous <= maximum_step * (1 + 1e-10)
        previous = time
    assert previous == stop
    counts[path] = {'points': points, 'variables': variables}
for path, expected in json.loads((out/'scripts.json').read_text()).items():
    raw = gzip.decompress((out/(path+'.gz')).read_bytes())
    assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
with tempfile.TemporaryDirectory(prefix='resident-dpt-audit-', dir='/home/adam/emi03-work/tmp') as name:
    scratch = Path(name)
    for lane in ('cpu','gpu'):
        (scratch/(lane+'.raw')).write_bytes(gzip.decompress((out/'dpt-q0'/(lane+'.raw.gz')).read_bytes()))
    script = scratch/'compare.py'
    script.write_bytes(gzip.decompress((out/'compare_resident_dpt.py.gz').read_bytes()))
    python = next(runfiles.glob('rules_python++python+*/bin/python3'))
    env = dict(os.environ, RUNFILES_DIR=str(runfiles), PYTHONPATH=':'.join([str(runfiles/'_main'),str(runfiles/'rules_python+'),str(next(runfiles.glob('rules_python++pip+*'))/'site-packages')]))
    subprocess.run([str(python),str(script),str(scratch)], env=env, check=True, stdout=subprocess.DEVNULL)
    rebuilt = json.loads((scratch/'comparison.json').read_text())
    assert rebuilt == json.loads((out/'dpt-q0/comparison.json').read_text())
    assert rebuilt['comparison']['pass']
budget = json.loads((out/'reference-q0-budget/summary.json').read_text())['results']
assert budget['cpu']['status'] == 'complete'
assert budget['gpu']['status'] == 'resource_limit' and budget['gpu']['returncode'] == 124
assert budget['gpu']['wall_s'] >= 120 and budget['gpu']['child_cpu_s'] < 110
assert not (out/'reference-q0-budget/gpu.raw.gz').exists()
result = {'source_reconstruction_pass': True, 'source_files':len(identity['source_files']), 'binary_identity_pass':True, 'raw_reconstruction_pass':True, 'raw_counts':counts, 'dpt_comparison_reproduced':True, 'budget_failure_reproduced_from_terminal_record':True, 'audit_pass':True, 'acceptance_pass':False, 'scope':'Single-case development evidence; no complete qualification or performance pass.'}
(out/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
