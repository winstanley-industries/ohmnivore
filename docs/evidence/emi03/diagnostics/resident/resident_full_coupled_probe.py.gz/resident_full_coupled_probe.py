from pathlib import Path
import os,subprocess,tempfile,time,json,re,hashlib,shutil,sys,resource
from reference.emi02 import importer
from reference.emi01 import circuits
out=Path(sys.argv[1]); out.mkdir(exist_ok=False)
r=Path(os.environ['EMI03_RUNFILES']); archive=r/'+http_file+emi01_microchip_model/file/model.zip'
manifest=json.loads(Path('/home/adam/code/ohmnivore/reference/emi01/manifest-v2.json').read_text())
candidate=next(c for c in manifest['candidates'] if c['id']=='reference')
corner=next(c for c in manifest['corners'] if c['id']=='nominal')
source=circuits.ensemble(candidate,corner,manifest['candidate_max_steps_s']['reference'][0],'emi01-v2')
flat,identity=importer.import_archive(archive,source)
with tempfile.TemporaryDirectory(prefix='emi03-short-') as t:
 p=Path(t); inp=p/'input.cir'; inp.write_text(flat)
 result={}
 for lane,binary in [('cpu',r/'_main/cpp/emi03_cpu_worker'),('gpu',Path('/home/adam/emi03-work/bin/emi03_resident_worker'))]:
  raw=p/(lane+'.raw'); stats=p/(lane+'.json'); start=time.perf_counter()
  def budgets():
   resource.setrlimit(resource.RLIMIT_CPU,(110,110))
   if lane == 'cpu': resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
  before_cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
  try:
   proc=subprocess.run([str(binary),str(inp),str(raw),str(stats)],capture_output=True,timeout=120,preexec_fn=budgets)
  except subprocess.TimeoutExpired as e:
   proc=subprocess.CompletedProcess([str(binary)],124,e.stdout or b'',e.stderr or b'')
  after_cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
  used_cpu=after_cpu.ru_utime+after_cpu.ru_stime-before_cpu.ru_utime-before_cpu.ru_stime
  row={'child_cpu_s':used_cpu,'wall_s':time.perf_counter()-start,'returncode':proc.returncode,'status':('complete' if proc.returncode == 0 else 'resource_limit' if proc.returncode == 124 or (proc.returncode == -9 and used_cpu >= 109) else 'failed'),'diagnostic_sha256':hashlib.sha256(proc.stderr).hexdigest()}
  for path in [stats,Path(str(stats)+'.gpu.json')]:
   if path.exists():
    data=json.loads(path.read_text()); row[path.name]=data
    (out/path.name).write_text(json.dumps(data,indent=2)+'\n')
  if raw.is_file(): shutil.copy2(raw,out/(lane+'.raw'))
  if proc.stdout: print(proc.stdout.decode(errors='replace')[:4096],flush=True)
  if proc.stderr: print(proc.stderr.decode(errors='replace')[:500],flush=True)
  result[lane]=row
  print(json.dumps(row),flush=True)
(out/'summary.json').write_text(json.dumps({'interpretation':'one full frozen q0 reference/nominal job with fresh CPU comparison inputs; diagnostic only, not the complete 30-job qualification or a throughput claim','source_sha256':hashlib.sha256(source.encode()).hexdigest(),'import_identity':identity,'wall_limit_s':120,'cpu_limit_s':110,'results':result},indent=2)+'\n')
