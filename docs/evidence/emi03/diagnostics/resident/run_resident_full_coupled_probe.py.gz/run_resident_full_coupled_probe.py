from pathlib import Path
import subprocess,os,sys,shutil
r=Path('bazel-bin/reference/emi03/ensemble.runfiles').resolve()
env=dict(os.environ,EMI03_RUNFILES=str(r),RUNFILES_DIR=str(r),TMPDIR='/home/adam/emi03-work/tmp',PYTHONPATH=':'.join([str(r/'_main'),str(r/'rules_python+'),str(next(r.glob('rules_python++pip+*'))/'site-packages')]))
python=next(r.glob('rules_python++python+*/bin/python3'))
out=Path('/home/adam/emi03-work')/sys.argv[1]
shutil.copy2('bazel-bin/cuda/emi03_resident_worker','/home/adam/emi03-work/bin/emi03_resident_worker')
with out.with_suffix('.log').open('w') as log:
 proc=subprocess.run([str(python),'/home/adam/emi03-work/resident_full_coupled_probe.py',str(out)],env=env,stdout=log,stderr=subprocess.STDOUT)
print(out.with_suffix('.log').read_text())
raise SystemExit(proc.returncode)
