import hashlib,json,os,subprocess,time
from pathlib import Path
w=Path('/home/adam/emi03-work');root=Path('/home/adam/code/ohmnivore');out=root/'docs/evidence/emi03/diagnostics/resident-factor-power-screening/sanitizers-retry';out.mkdir(exist_ok=False)
tool=w/'pinned-profiler-bazel/external/+http_archive+compute_sanitizer_current/compute-sanitizer/compute-sanitizer';binary=root/'bazel-out/k8-opt/bin/cuda/emi03_resident_test'
identity={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['cuda/emi03_resident_device.cuh','cuda/emi03_resident.cu','cuda/emi03_resident_test.cc']}}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
checks=[]
for mode,extra in [('memcheck',[]),('racecheck',['--kernel-name','kns=Emi03Advance','--launch-count','1'])]:
 cmd=[str(tool),'--tool',mode,'--error-exitcode','99',*extra,str(binary),'--gtest_filter=Emi03Resident.DenseCouplingRetainsEverySparseFactorEntry'];start=time.monotonic()
 with (out/(mode+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,env=dict(os.environ,TMPDIR=str(w/'tmp')),stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
  except subprocess.TimeoutExpired:code=124
 log=(out/(mode+'.log')).read_text();passed=code==0 and ('RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)' in log if mode=='racecheck' else 'ERROR SUMMARY: 0 errors' in log) and '[  PASSED  ] 1 test.' in log
 checks.append({'tool':mode,'command':cmd,'elapsed_s':time.monotonic()-start,'exit_code':code,'pass':passed,'scope':'New dense-factor regression on selected100; memcheck all launches, racecheck first resident chunk only'})
 (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks[-1]),flush=True)
 if not passed:raise SystemExit(1)
