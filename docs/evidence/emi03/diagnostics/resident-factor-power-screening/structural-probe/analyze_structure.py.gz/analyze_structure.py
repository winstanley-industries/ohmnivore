from pathlib import Path
from functools import lru_cache
import hashlib,json,shlex,sys
w=Path(sys.argv[1] if len(sys.argv)>1 else '/home/adam/emi03-work');data=(w/'structure-probe.tsv').read_bytes();g={};c={};b={};desc={};nodes={};branches={};sources=set();reactive=set()
for line in data.decode().splitlines():
 x=shlex.split(line);kind=x[0]
 if kind=='N':size=int(x[1])
 elif kind=='V':nodes[int(x[1])]=x[2]
 elif kind=='I':branches[int(x[1])]=x[2]
 elif kind in ['G','C']:(g if kind=='G' else c)[(int(x[1]),int(x[2]))]=float(x[3])
 elif kind=='B':b[int(x[1])]=float(x[2])
 elif kind=='D':
  i=int(x[1]);desc[i]={'name':x[2],'voltage':bool(int(x[3])),'pos':int(x[4]),'neg':int(x[5]),'branch':int(x[6]),'root':int(x[7]),'state_size':int(x[8]),'nodes':{},'dependencies':[],'rows':[]}
 elif kind=='P':desc[int(x[1])]['dependencies'].append(int(x[2]))
 elif kind=='R':desc[int(x[1])]['rows'].append((int(x[2]),float(x[3])))
 elif kind=='E':desc[int(x[1])]['nodes'][int(x[2])]=dict(zip(['op','first','second','third','value','constant'],[int(y) for y in x[3:7]]+[float(x[7]),int(x[8])]))
 elif kind=='S':sources.add(int(x[1]))
 elif kind=='T':reactive.add(int(x[1]))
 elif kind=='OTHER':assert x[1:]==['0','0']
candidates={};failed={}
for i,d in desc.items():
 if not d['voltage'] or d['pos']<0 or d['neg']!=-1:continue
 v=d['pos'];branch=d['branch'];assert branch>=len(nodes)
 expected={(v,v):1e-12,(v,branch):1.,(branch,v):1.}
 actual={p:x for p,x in g.items() if x!=0 and (v in p or branch in p)}
 checks={'only_gmin_and_source_linear_stamps':actual==expected,'no_reactive_coupling':not any(x!=0 and (v in p or branch in p) for p,x in c.items()),'zero_dc_rows':b[v]==b[branch]==0,'no_transient_or_reactive_state':not ({v,branch}&(sources|reactive)),'no_branch_current_dependency':not any(branch in x['dependencies'] for x in desc.values()),'only_own_branch_nonlinear_row':d['rows']==[(branch,-1.)] and not any(row in [v,branch] for j,x in desc.items() if j!=i for row,coefficient in x['rows'])}
 if all(checks.values()):candidates[v]=i
 else:failed[d['name']]=checks
visiting=set();order=[];done=set()
def visit(v):
 if v in visiting:raise ValueError('auxiliary cycle')
 if v in done:return
 visiting.add(v)
 for dep in desc[candidates[v]]['dependencies']:
  if dep in candidates:visit(dep)
 visiting.remove(v);done.add(v);order.append(v)
for v in candidates:visit(v)
@lru_cache(None)
def expanded(i,j):
 n=desc[i]['nodes'][j];op=n['op']
 if op==1 and n['first'] in candidates:
  d=candidates[n['first']];return expanded(d,desc[d]['root'])
 if op in [0,1]:return (1,1)
 children=[expanded(i,n['first'])]
 if op not in [2,8]:children.append(expanded(i,n['second']))
 if op==11:children.append(expanded(i,n['third']))
 return 1+sum(x[0] for x in children),1+max(x[1] for x in children)
counts={d['name']:{'original_nodes':len(d['nodes']),'expanded_tree_nodes':expanded(i,d['root'])[0],'expanded_depth':expanded(i,d['root'])[1]} for i,d in desc.items()}
result={'scope':'Read-only compiled MNA and exported AST structural probe; no solver reduction or equivalence/acceptance claim','acceptance_pass':False,'input_sha256':hashlib.sha256((w/'hardware-profile-70/input.cir').read_bytes()).hexdigest(),'compiled_probe_sha256':hashlib.sha256(data).hexdigest(),'original_unknowns':size,'compiled_isolated_grounded_drivers':len(candidates),'candidate_reduced_unknowns':size-2*len(candidates),'rejected_candidates':failed,'auxiliary_topological_order':[nodes[v] for v in order],'auxiliary_branch_current_formula':'i(driver) = -1e-12 * v(auxiliary) because the original GMIN stamp remains','original_expression_nodes':sum(len(d['nodes']) for d in desc.values()),'expanded_all_program_nodes':sum(x['expanded_tree_nodes'] for x in counts.values()),'maximum_expanded_program_nodes':max(x['expanded_tree_nodes'] for x in counts.values()),'maximum_expanded_depth':max(x['expanded_depth'] for x in counts.values()),'programs':counts,'requirements':['Keep eager domain checks for all original programs, including unused auxiliary expressions','Reconstruct all original states and currents on GPU','Preserve original residual, update and Jacobian nonsingularity checks','Fresh complete CPU and external qualification before any acceptance timing']}
(w/'compiled-auxiliary-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['programs','auxiliary_topological_order']},indent=2))
