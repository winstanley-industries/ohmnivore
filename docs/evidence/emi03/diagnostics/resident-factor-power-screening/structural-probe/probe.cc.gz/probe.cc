#include "cpp/src/expression_internal.h"
#include "ohmnivore/behavioral.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <string>

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  std::ifstream input(argv[1]);
  if (!input) return 3;
  const std::string source{std::istreambuf_iterator<char>(input), {}};
  auto parsed = ohmnivore::ParseBehavioralNetlist(source);
  if (!parsed.ok()) { std::cerr << parsed.error().message; return 4; }
  auto compiled = ohmnivore::CompileBehavioralMna(parsed.value());
  if (!compiled.ok()) { std::cerr << compiled.error().message; return 5; }
  const auto &s = compiled.value();
  std::cout << std::setprecision(17) << "N " << s.g.rows << '\n';
  for (std::size_t i=0;i<s.node_names.size();++i)
    std::cout << "V " << i << ' ' << std::quoted(s.node_names[i]) << '\n';
  for (std::size_t i=0;i<s.branch_names.size();++i)
    std::cout << "I " << i+s.node_names.size() << ' ' << std::quoted(s.branch_names[i]) << '\n';
  for (const auto &[tag,matrix] : {std::pair{'G',&s.g},std::pair{'C',&s.c}})
    for (std::size_t row=0;row<matrix->rows;++row)
      for (auto k=matrix->row_offsets[row];k<matrix->row_offsets[row+1];++k)
        std::cout << tag << ' ' << row << ' ' << matrix->column_indices[k] << ' ' << matrix->values[k] << '\n';
  for (std::size_t i=0;i<s.b_dc.size();++i) std::cout << "B " << i << ' ' << s.b_dc[i] << '\n';
  for (std::size_t i=0;i<s.behavioral_descriptors.size();++i) {
    const auto &d=s.behavioral_descriptors[i];
    auto exported=ohmnivore::internal::ExportExpressionProgram(d.expression);
    if (!exported.ok()) return 6;
    const auto &p=exported.value();
    std::cout << "D " << i << ' ' << std::quoted(d.name) << ' ' << d.is_voltage << ' '
              << (d.positive_node_index ? static_cast<int>(*d.positive_node_index) : -1) << ' '
              << (d.negative_node_index ? static_cast<int>(*d.negative_node_index) : -1) << ' '
              << (d.branch_index ? static_cast<int>(*d.branch_index) : -1) << ' ' << p.root << ' ' << p.state_size << '\n';
    for (auto dep:p.dependencies) std::cout << "P " << i << ' ' << dep << '\n';
    for (const auto &row:d.rows) std::cout << "R " << i << ' ' << row.row << ' ' << row.coefficient << '\n';
    for (std::size_t j=0;j<p.nodes.size();++j) {
      const auto &n=p.nodes[j];
      std::cout << "E " << i << ' ' << j << ' ' << static_cast<unsigned>(n.op) << ' ' << n.first << ' ' << n.second << ' ' << n.third << ' ' << n.value << ' ' << n.constant << '\n';
    }
  }
  for (const auto &source_stamp:s.transient_sources)
    for (const auto &stamp:source_stamp.rhs_stamps) std::cout << "S " << stamp.index << '\n';
  for (const auto &cap:s.capacitor_initial_constraints) {
    if (cap.positive_node_index) std::cout << "T " << *cap.positive_node_index << '\n';
    if (cap.negative_node_index) std::cout << "T " << *cap.negative_node_index << '\n';
  }
  for (const auto &ind:s.inductor_initial_constraints) std::cout << "T " << ind.branch_index << '\n';
  std::cout << "OTHER " << s.diode_descriptors.size() << ' ' << s.bjt_descriptors.size() << '\n';
}
