from pathlib import Path
import gzip,hashlib,json,shutil
root=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=root/'docs/evidence/emi03/diagnostics/resident-factor-power-screening';out.mkdir(exist_ok=False)
for version,label in [(102,'factor'),(103,'power')]:
 source=w/f'resident-{label}{version}';target=out/source.name;target.mkdir();raws={}
 for p in source.rglob('*'):
  if not p.is_file():continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw':
   b=p.read_bytes();q=Path(str(q)+'.gz');q.write_bytes(gzip.compress(b,mtime=0));raws[str(q.relative_to(target))]={'raw_bytes':len(b),'raw_sha256':hashlib.sha256(b).hexdigest()}
  else:shutil.copy2(p,q)
 (target/'raw-files.json').write_text(json.dumps(raws,indent=2)+'\n')
 frozen=w/f'block-{version}';dest=out/f'variant-{version}';dest.mkdir()
 for name in ['identity.json','source.patch','sources.tar.gz','tests.log']:shutil.copy2(frozen/name,dest/name)
 (dest/'scope.json').write_text(json.dumps({'selected':False,'acceptance_pass':False,'scope':{'factor':'Prefetch four immutable factor descriptors per thread, with indirect descriptors for larger factors','power':'Use native FP64 products or square root for selected constant power exponents; the original freezer label is generic metadata'}[label]},indent=2)+'\n')
 for name in [f'resident-{label}{version}.log',f'resident-{label}{version}-build.log']:
  if (w/name).exists():shutil.copy2(w/name,out/name)
 for name in [f'{label}{version}.py',f'run_{label}{version}.py']:(out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
shutil.copy2(w/'resident-dense-regression100.log',out/'selected100-with-dense-regression-tests.log')
(out/'freeze_compact_variant.py.gz').write_bytes(gzip.compress((w/'freeze_compact_variant.py').read_bytes(),mtime=0))
(out/'retain_small103.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(out)
