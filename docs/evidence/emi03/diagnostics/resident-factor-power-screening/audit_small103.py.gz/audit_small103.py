from reference.emi03 import ensemble as e
from pathlib import Path
import gzip,json,statistics,tarfile,subprocess,sys,tempfile
root=Path('/home/adam/code/ohmnivore');out=root/'docs/evidence/emi03/diagnostics/resident-factor-power-screening';np=e.metrics.np
raw_count=0;wave_count=0
for version,label in [(102,'factor'),(103,'power'),(104,'ordering'),(105,'ordering')]:
 frozen=out/f'variant-{version}';identity=json.loads((frozen/'identity.json').read_text())
 with tarfile.open(frozen/'sources.tar.gz','r:gz') as archive:
  sources={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
 assert set(sources)==set(identity['sources'])
 for name,h in identity['sources'].items():assert e.study.sha(sources[name])==h,name
 assert '[  PASSED  ] 11 tests.' in (frozen/'tests.log').read_text()
 assert not json.loads((frozen/'scope.json').read_text())['selected']
 p=out/f'resident-{label}{version}';records=json.loads((p/'records.json').read_text());assert len(records)==11
 grid=np.linspace(0,1.03*1e-6,2061)
 for row in records:
  folder=p/(row['lane']+'-'+str(row['trial'])+('-profile' if row.get('profile') else ''))
  raw=gzip.decompress((folder/'output.raw.gz').read_bytes());assert e.study.sha(raw)==row['raw_sha256'];raw_count+=1
  table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);assert len(table)==row['points']
  if row['lane']=='cpu':reference={n:np.interp(grid,table[:,0],table[:,i]) for i,n in enumerate(e.circuits.STUDY_NAMES)}
  else:
   compared={n:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[n],n.startswith('v('),400) for i,n in enumerate(e.circuits.STUDY_NAMES) if n!='time'}
   assert compared==row['waveforms'] and all(x['pass'] for x in compared.values());wave_count+=1
   gpu=json.loads((folder/'stats.json.gpu.json').read_text());e.validate_gpu_telemetry(gpu,gpu['job_id'])
 summary=json.loads((p/'summary.json').read_text());assert not summary['acceptance_pass']
 medians={lane:statistics.median(x['wall_s'] for x in records if x['lane']==lane and x['trial']>=0 and not x.get('profile')) for lane in {x['lane'] for x in records if x['lane']!='cpu'}}
 assert medians==summary['median_request_wall_s'] and summary['ratio_candidate_over_baseline']>1
assert '[  PASSED  ] 11 tests.' in (out/'selected100-with-dense-regression-tests.log').read_text()
e.study.write_json(out/'audit.json',{'pass':True,'acceptance_pass':False,'selected_variants':[],'source_variants':[102,103,104,105],'raw_trajectories':raw_count,'gpu_waveform_comparisons':wave_count,'candidate_resident_test_executions':44,'selected100_resident_test_executions':11,'scope':'Exact archived sources, raw reconstruction and CPU waveform comparisons for four rejected 1.03 us screening experiments. No complete qualification or acceptance timing.'})
print('Audit passes:',raw_count,'trajectories;',wave_count,'GPU waveform comparisons; four source archives; 55 resident test executions.')

failed=json.loads((out/'sanitizers/checks.json').read_text());passed=json.loads((out/'sanitizers-retry/checks.json').read_text())
assert len(failed)==1 and failed[0]['exit_code']==99 and not failed[0]['pass']
assert 'Selective device code recompilation in progress' in (out/'sanitizers/memcheck.log').read_text()
assert len(passed)==2 and all(x['pass'] and x['exit_code']==0 for x in passed)
assert json.loads((out/'sanitizers/identity.json').read_text())==json.loads((out/'sanitizers-retry/identity.json').read_text())
with tempfile.TemporaryDirectory() as temporary:
 path=Path(temporary);probe=out/'structural-probe'
 (path/'structure-probe.tsv').write_bytes(gzip.decompress((probe/'compiled.tsv.gz').read_bytes()))
 (path/'hardware-profile-70').mkdir();(path/'hardware-profile-70/input.cir').write_bytes(gzip.decompress((probe/'input.cir.gz').read_bytes()))
 script=path/'analyze.py';script.write_bytes(gzip.decompress((probe/'analyze_structure.py.gz').read_bytes()))
 subprocess.run([sys.executable,str(script),str(path)],check=True,stdout=subprocess.DEVNULL)
 assert json.loads((path/'compiled-auxiliary-probe.json').read_text())==json.loads((probe/'compiled-auxiliary-probe.json').read_text())
audit=json.loads((out/'audit.json').read_text());audit.update({'sanitizer_successes':2,'sanitizer_initial_recompilation_warning_failures':1,'structural_probe_reconstructed':True});e.study.write_json(out/'audit.json',audit)
print('Dense-fixture sanitizer checks and compiled structural analysis reconstructed; initial warning failure retained.')
