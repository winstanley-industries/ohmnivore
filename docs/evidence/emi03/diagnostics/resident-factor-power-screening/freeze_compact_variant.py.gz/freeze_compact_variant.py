from pathlib import Path
import hashlib,json,shutil,subprocess,sys,gzip,io,tarfile
root=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');version=sys.argv[1];out=w/('block-'+version);out.mkdir(exist_ok=False)
binroot=root/'bazel-out/k8-opt/bin';worker=binroot/'cuda/emi03_resident_worker';test=binroot/'cuda/emi03_resident_test';runtime=out/'runtime'
identity=json.loads((w/'pool-dpt-81/identity.json').read_text());sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in identity['sources']}
for name in ['cuda/emi03_resident.cu','cuda/emi03_resident_device.cuh','cuda/emi03_expression_device.cuh','cuda/emi03_resident_test.cc']:
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
shutil.copy2(worker,out/'worker')
for name in json.loads((w/'pool-test-runtime-81/files.json').read_text()):
 p=runtime/name;p.parent.mkdir(parents=True,exist_ok=True)
 src=test if name.startswith('cuda/') else Path(str(test)+'.runfiles')/'_main'/name
 shutil.copy2(src,p)
identity={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':sources,'worker_sha256':hashlib.sha256((out/'worker').read_bytes()).hexdigest(),'runtime_files':{str(p.relative_to(runtime)):hashlib.sha256(p.read_bytes()).hexdigest() for p in runtime.rglob('*') if p.is_file()},'scope':'Unqualified factor-metadata diagnostic prototype; no acceptance pass'}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','cuda/emi03_resident.cu','cuda/emi03_resident_device.cuh','cuda/emi03_expression_device.cuh','cuda/emi03_resident_test.cc'],cwd=root));print(out)

source_buffer=io.BytesIO()
with tarfile.open(fileobj=source_buffer,mode='w') as source_archive:
 for name,digest in sorted(sources.items()):
  data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
  entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(data)
  source_archive.addfile(entry,io.BytesIO(data))
(out/'sources.tar.gz').write_bytes(gzip.compress(source_buffer.getvalue(),mtime=0))
