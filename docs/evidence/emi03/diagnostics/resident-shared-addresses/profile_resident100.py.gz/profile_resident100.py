from pathlib import Path
import hashlib,json,os,signal,subprocess,time
w=Path('/home/adam/emi03-work');root=Path('/home/adam/code/ohmnivore');out=w/'resident-full-counters100';out.mkdir(exist_ok=False)
tool=w/'pinned-profiler-bazel/external/+http_archive+nsight_compute_current/ncu';worker=w/'block-100/worker';source=w/'hardware-profile-70/input.cir'
identity=json.loads((w/'pool-dpt-100/identity.json').read_text())
assert hashlib.sha256(worker.read_bytes()).hexdigest()==identity['binaries']['gpu']
for name,h in identity['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
cmd=[str(tool),'--set','full','--kernel-name','Emi03Advance','--launch-skip','4','--launch-count','1','--clock-control','none','--cache-control','none','--export',str(out/'resident'),str(worker),str(source),str(out/'output.raw'),str(out/'statistics.json')]
record={'command':cmd,'worker_sha256':identity['binaries']['gpu'],'source_identity':identity,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Full hardware-counter diagnosis of one resident chunk on a shortened coupled reference/nominal trajectory; no acceptance timing'}
started=time.monotonic()
with (out/'ncu.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,env=dict(os.environ,TMPDIR=str(w/'tmp')),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=240)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
record.update(exit_code=code,elapsed_s=time.monotonic()-started);(out/'profile.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'exit_code':code,'elapsed_s':record['elapsed_s']}),flush=True)
if code:print((out/'ncu.log').read_text()[-12000:]);raise SystemExit(code)
report=next(out.glob('resident.ncu-rep*'))
for args,name in [(['--page','details'],'metrics.txt'),(['--page','raw','--csv'],'metrics.csv'),(['--page','source','--print-source','cuda,sass','--csv'],'source.csv')]:
 with (out/name).open('w') as f:subprocess.run([str(tool),'--import',str(report),*args],stdout=f,stderr=subprocess.STDOUT,check=True)
print((out/'ncu.log').read_text()[-4000:])
