from reference.emi03 import ensemble as e
from pathlib import Path
import gzip,io,json,statistics,subprocess,tarfile,tempfile
r=Path('/home/adam/code/ohmnivore');out=r/'docs/evidence/emi03/diagnostics/resident-shared-addresses';base=r/'docs/evidence/emi03/diagnostics/resident-owner-pool';np=e.metrics.np
variants=[];raw_count=0;wave_count=0
for v in [99,100,101]:
 p=out/('variant-'+str(v));identity=json.loads((p/'identity.json').read_text())
 with tempfile.TemporaryDirectory(prefix='counter-source-audit-') as tmp:
  path=Path(tmp)
  with tarfile.open(fileobj=io.BytesIO((p/'sources.tar.gz').read_bytes()),mode='r:gz') as tar:
   for member in tar:
    assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
    target=path/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
  for name,h in identity['sources'].items():assert e.study.sha((path/name).read_bytes())==h,name
 assert '[  PASSED  ] 10 tests.' in (p/'tests.log').read_text()
 variants.append(v)
for name in ['resident-shared99','resident-shared100','resident-shared101','resident-coupled20us99','resident-coupled20us101']:
 p=out/name;records=json.loads((p/'records.json').read_text());long=name.startswith('resident-coupled20us');stop=(20 if long else 1.03)*1e-6;grid=np.linspace(0,stop,40001 if long else 2061)
 for row in records:
  folder=p/row['lane'] if long else p/(row['lane']+'-'+str(row['trial'])+('-profile' if row.get('profile') else ''))
  raw=gzip.decompress((folder/'output.raw.gz').read_bytes());assert e.study.sha(raw)==row['raw_sha256'];raw_count+=1
  table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,stop,625e-12);assert len(table)==row['points']
  if row['lane']=='cpu':reference={n:np.interp(grid,table[:,0],table[:,i]) for i,n in enumerate(e.circuits.STUDY_NAMES)}
  else:
   compared={n:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[n],n.startswith('v('),400) for i,n in enumerate(e.circuits.STUDY_NAMES) if n!='time'}
   assert compared==row['waveforms'] and all(x['pass'] for x in compared.values());wave_count+=1
   gpu=json.loads((folder/'stats.json.gpu.json').read_text());e.validate_gpu_telemetry(gpu,gpu['job_id'])
 assert not json.loads((p/'summary.json').read_text())['acceptance_pass']
 if not long:
  summary=json.loads((p/'summary.json').read_text())
  medians={lane:statistics.median(x['wall_s'] for x in records if x['lane']==lane and x['trial']>=0 and not x.get('profile')) for lane in {x['lane'] for x in records if x['lane']!='cpu'}}
  assert medians==summary['median_request_wall_s']
refinements=[]
for name in ['pool-dpt-100']:
 p=out/name;summary=json.loads((p/'summary.json').read_text());identity=json.loads((p/'identity.json').read_text());refs=[]
 with tarfile.open(p/'sources.tar.gz','r:gz') as archive:source_data={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
 for n,h in identity['sources'].items():assert e.study.sha(source_data[n])==h,n
 for lane in ['cpu','gpu']:
  rows=summary['results'][lane]['jobs'];by={x['level']:x for x in rows};assert set(by)=={0,1,2}
  for row in rows:
   table=e.study.restore(p/lane,row);raw_count+=1
   assert e.metrics.dpt(table,row['sample_step_s'])==row['metrics'] and row['metrics']['pass']
   if lane=='gpu':
    cpu={x['level']:x for x in summary['results']['cpu']['jobs']}[row['level']]
    compared=e.compare_pair(table,row,e.study.restore(p/'cpu',cpu),cpu)
    assert compared==row['cpu_validation'] and compared['pass'];wave_count+=1
    e.validate_gpu_telemetry(row['gpu'],row['request_input'])
  for level in [1,2]:refs.append(e.study.dpt_compare(by[level-1]['metrics'],by[level]['metrics'],f'{lane}-q{level-1}-q{level}'))
  for dt in e.study.selected_manifest('emi01-v2')['dpt_sample_steps_s'][:2]:refs.append(e.study.dpt_compare(e.metrics.dpt(e.study.restore(p/lane,by[2]),dt),by[2]['metrics'],f'{lane}-output-{dt}'))
  workers=json.loads((p/(lane+'-workers.json')).read_text());resources=json.loads((p/(lane+'-resources.json')).read_text())
  assert e.audit_resources(resources,rows,workers,lane=='gpu');e.audit_worker_affinity(workers,lane=='gpu',16 if lane=='gpu' else 1)
 assert refs==summary['refinements'] and len(refs)==8 and all(x['pass'] for x in refs)
 assert not summary['acceptance_pass'];refinements.extend(refs)
p=out/'resident-full-counters100';profile=json.loads((p/'profile.json').read_text())
assert profile['exit_code']==0 and '41 passes' in (p/'ncu.log').read_text()
assert e.study.sha((p/'input.cir').read_bytes())==profile['input_sha256']
raw=gzip.decompress((p/'output.raw.gz').read_bytes());table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);raw_count+=1
cpu=gzip.decompress((out/'resident-shared100/cpu--1/output.raw.gz').read_bytes());ct=e.signals.parse_raw(cpu,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);grid=np.linspace(0,1.03*1e-6,2061)
profile_checks={n:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),np.interp(grid,ct[:,0],ct[:,i]),n.startswith('v('),400) for i,n in enumerate(e.circuits.STUDY_NAMES) if n!='time'}
assert all(x['pass'] for x in profile_checks.values());wave_count+=1
base_identity=json.loads((out/'pool-dpt-100/identity.json').read_text());assert profile['source_identity']['sources']==base_identity['sources']
checks=json.loads((out/'pool-sanitizers-100/checks.json').read_text());assert len(checks)==7 and all(c['pass'] and c['exit_code']==0 for c in checks)
validation=json.loads((out/'pool-validation-100/checks.json').read_text());assert len(validation)==19 and all(c['pass_'] for c in validation)
for attempt in [1,2,3]:
 failed=json.loads((out/f'pool-validation-100-attempt{attempt}/checks.json').read_text())
 assert not failed[-1]['pass_'] and failed[-1]['name']==('build' if attempt==3 else 'lint')
p=out/'prefix-corpus100';specs=json.loads((p/'specs.json').read_text());by_spec={x['id']:x for x in specs};assert len(by_spec)==9
manifest=e.study.selected_manifest('emi01-v2');grid=np.linspace(0,20*1e-6,40001);references={}
for spec in specs:
 assert spec['max_step_s']==manifest['candidate_max_steps_s'].get(spec['candidate']['id'],manifest['ensemble_max_steps_s'])[0]
 assert e.study.sha(spec['source'].encode())==spec['source_sha256']
for lane in ['cpu','gpu']:
 rows=json.loads((p/(lane+'-records.json')).read_text());assert len(rows)==(9 if lane=='cpu' else 18)
 assert {(x['batch'],x['id']) for x in rows}=={(batch,name) for batch in ([0] if lane=='cpu' else [-1,0]) for name in by_spec}
 for row in rows:
  spec=by_spec[row['id']];folder=p/row['directory'];assert (folder/'input.cir').read_text()==spec['source']
  raw=gzip.decompress((folder/'output.raw.gz').read_bytes());assert e.study.sha(raw)==row['raw_sha256'];raw_count+=1
  table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,20*1e-6,spec['max_step_s']);assert len(table)==row['points']
  values={n:np.interp(grid,table[:,0],table[:,i]) for i,n in enumerate(e.circuits.STUDY_NAMES)}
  assert row['pass'] and row['status']=='complete'
  if lane=='cpu':references[row['id']]=values
  else:
   compared={n:e.metrics._waveform_check(values[n],references[row['id']][n],n.startswith('v('),spec['corner']['bus_v']) for n in e.circuits.STUDY_NAMES if n!='time'}
   assert compared==row['waveforms'] and all(c['pass'] for c in compared.values());wave_count+=1
   native=json.loads((folder/'stats.json.gpu.json').read_text());assert native==row['gpu'];e.validate_gpu_telemetry(native,row['process']['input'])
 workers=json.loads((p/(lane+'-workers.json')).read_text());resource=json.loads((p/(lane+'-resources.json')).read_text());assert e.audit_resources(resource,rows,workers,lane=='gpu');e.audit_worker_affinity(workers,lane=='gpu',16)
summary=json.loads((p/'summary.json').read_text());assert not summary['acceptance_pass'] and all(x['pass'] for x in summary['lanes'].values())
failed=json.loads((out/'prefix-corpus100-setup-failure/failure.json').read_text());assert failed['exit_code']==1 and failed['workload_requests_started']==0
e.study.write_json(out/'audit.json',{'pass':True,'acceptance_pass':False,'source_variants':variants,'raw_trajectories':raw_count,'gpu_waveform_comparisons':wave_count,'dpt_refinements':len(refinements),'sanitizer_checks':len(checks),'canonical_checks':len(validation),'historical_packaging_failures_retained':3,'prefix_setup_failures_retained':1,'distinct_coupled_prefix_inputs':9,'hardware_profile_waveforms':profile_checks,'scope':'Source, raw, DPT/refinement, resource and diagnostic reconstruction; variant 100 selected for continued qualification, no full EMI-03 acceptance'})
print('Audit passes:',raw_count,'trajectories,',wave_count,'GPU comparisons,',len(refinements),'DPT refinements;',len(variants),'source variants, seven sanitizer and nineteen canonical checks.',flush=True)
