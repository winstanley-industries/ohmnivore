from pathlib import Path
import gzip,hashlib,json,shutil,io,tarfile
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-shared-addresses';out.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
for name in ['resident-shared99','resident-shared100','resident-shared101','resident-coupled20us99','resident-coupled20us101','pool-dpt-100','pool-sanitizers-100','resident-full-counters100','pool-validation-100','pool-validation-100-attempt1','pool-validation-100-attempt2','pool-validation-100-attempt3']:
 source=w/name;target=out/name;target.mkdir();raws={}
 for p in source.rglob('*'):
  if not p.is_file() or "sources" in p.relative_to(source).parts:continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw' or p.name in ['source.csv','metrics.csv']:
   b=p.read_bytes();q=Path(str(q)+'.gz');q.write_bytes(gzip.compress(b,mtime=0))
   if p.suffix=='.raw':raws[str(q.relative_to(target))]={'raw_bytes':len(b),'raw_sha256':sha(b)}
  else:shutil.copy2(p,q)
 if raws:(target/'raw-files.json').write_text(json.dumps(raws,indent=2)+'\n')
 if (source/'sources').is_dir():
  buffer=io.BytesIO()
  with tarfile.open(fileobj=buffer,mode='w') as archive:
   for p in sorted((source/'sources').rglob('*')):
    if p.is_file():
     data=p.read_bytes();entry=tarfile.TarInfo(str(p.relative_to(source/'sources')));entry.mode=0o644;entry.size=len(data);archive.addfile(entry,io.BytesIO(data))
  (target/'sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
 log=w/(name+'.log')
 if log.exists():shutil.copy2(log,target/'run.log')
for name in ['shared99.py','run_shared99.py','shared100.py','run_shared100.py','shared101.py','run_shared101.py','coupled20us99.py','run_coupled20us99.py','coupled20us101.py','run_coupled20us101.py','pool_dpt100.py','run_pool_dpt100.py','freeze_factor_variant.py','freeze_shared_variant.py','run_pool_sanitizers100.py','profile_resident100.py','run_pool_validation100.py','retain_shared101.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
for name in ['resident-shared99-build.log','resident-shared100-build.log','resident-shared101-build.log']:
 shutil.copy2(w/name,out/name)
shutil.copy2(w/'hardware-profile-70/input.cir',out/'resident-full-counters100/input.cir')
print(out)
