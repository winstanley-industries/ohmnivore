from reference.emi03 import ensemble as e
from pathlib import Path
import json, os, re, sys, time

w = Path('/home/adam/emi03-work')
r = Path(os.environ['RUNFILES_DIR'])
version, name = sys.argv[1:]
out = w / name
out.mkdir(exist_ok=False)
np = e.metrics.np
manifest = e.study.selected_manifest('emi01-v2')
cpu = r / '_main/cpp/emi03_cpu_worker'
gpu = w / f'block-{version}/worker'
archive = r / '+http_file+emi01_microchip_model/file/model.zip'
identity = {
    'scope': 'Nine distinct candidate/corner 20 us prefixes; request-batch timings only, no full-study acceptance',
    'acceptance_pass': False,
    'gpu_variant': json.loads((w / f'block-{version}/identity.json').read_text()),
    'worker_environment': e.worker_environment(True),
    'binary_sha256': {'cpu': e.study.sha(cpu.read_bytes()), 'gpu': e.study.sha(gpu.read_bytes())},
    'harness_sources': e.identities(), 'cpu': e.cpu_identity(), 'accelerator': e.accelerator_identity(),
}
assert identity['binary_sha256']['gpu'] == identity['gpu_variant']['worker_sha256']
e.study.write_json(out / 'identity.json', identity)
specs = []
for candidate in manifest['candidates']:
    for corner in manifest['corners']:
        step = manifest['candidate_max_steps_s'][candidate['id']][0]
        deck = e.circuits.ensemble(candidate, corner, step, 'emi01-v2')
        deck, count = re.subn(r'(?im)^(\.tran\s+\S+\s+)\S+', r'\g<1>20u', deck)
        assert count == 1
        flat, imported = e.importer.import_archive(archive, deck)
        specs.append({'id': candidate['id'] + '-' + corner['id'], 'candidate': candidate,
                      'corner': corner, 'max_step_s': step, 'source': flat,
                      'source_sha256': e.study.sha(flat.encode()), 'model_identity': imported})
e.study.write_json(out / 'specs.json', specs)
grid = np.linspace(0, 20 * 1e-6, 40001)
references = {}
all_records = {}
for lane, binary in [('cpu', cpu), ('gpu', gpu)]:
    is_gpu = lane == 'gpu'
    pool = e.PersistentPool(binary, out / (lane + '-workers'), manifest['limits'], is_gpu, 16)
    records = []
    batches = []
    try:
        for batch in ([-1, 0] if is_gpu else [0]):
            paths = []
            for spec in specs:
                folder = out / lane / str(batch) / spec['id']
                folder.mkdir(parents=True)
                (folder / 'input.cir').write_text(spec['source'])
                paths.append(folder)
            def execute(index):
                folder = paths[index]
                owner = pool.workers[index]
                row = {'id': specs[index]['id'], 'owner': index, 'batch': batch,
                       'directory': str(folder.relative_to(out))}
                try:
                    row['process'] = owner.request(folder / 'input.cir', folder / 'output.raw',
                                                   folder / 'stats.json', pool.exhausted)
                    row['status'] = 'complete'
                except Exception as exc:
                    row.update(status='failed', error=str(exc), process=owner.last_process)
                return row
            start = time.perf_counter()
            futures = [pool.executor.submit(execute, i) for i in range(len(specs))]
            rows = [future.result() for future in futures]
            elapsed = time.perf_counter() - start
            for spec, row in zip(specs, rows):
                folder = out / row['directory']
                row['pass'] = False
                if row['status'] == 'complete':
                    raw = (folder / 'output.raw').read_bytes()
                    table = e.signals.parse_raw(raw, e.circuits.STUDY_NAMES, 20 * 1e-6, spec['max_step_s'])
                    row['raw_sha256'] = e.study.sha(raw)
                    row['points'] = len(table)
                    values = {n: np.interp(grid, table[:, 0], table[:, i])
                              for i, n in enumerate(e.circuits.STUDY_NAMES)}
                    if not is_gpu:
                        references[spec['id']] = values
                        row['pass'] = True
                    else:
                        row['waveforms'] = {n: e.metrics._waveform_check(values[n], references[spec['id']][n],
                                             n.startswith('v('), spec['corner']['bus_v'])
                                            for n in e.circuits.STUDY_NAMES if n != 'time'}
                        row['pass'] = all(check['pass'] for check in row['waveforms'].values())
                        native = json.loads((folder / 'stats.json.gpu.json').read_text())
                        e.validate_gpu_telemetry(native, row['process']['input'])
                        row['gpu'] = native
                        with pool.device_lock:
                            key = e.worker_key(pool.workers[row['owner']])
                            pool.device_peaks[key] = max(pool.device_peaks.get(key, 0), native['peak_device_bytes'])
            records.extend(rows)
            batch_record = {'batch': batch, 'request_batch_wall_s': elapsed,
                            'pass': all(row['pass'] for row in rows)}
            batches.append(batch_record)
            e.study.write_json(out / (lane + '-records.json'), records)
            e.study.write_json(out / (lane + '-batches.json'), batches)
            print(json.dumps({'lane': lane, **batch_record,
                              'jobs': [{k: row[k] for k in ['id', 'status', 'pass']} for row in rows]}), flush=True)
            if not batch_record['pass']:
                break
    finally:
        workers = pool.close()
        resources = e.pool_resources(pool)
        e.study.write_json(out / (lane + '-workers.json'), workers)
        e.study.write_json(out / (lane + '-resources.json'), resources)
    resource_pass = e.audit_resources(resources, records, workers, is_gpu)
    e.audit_worker_affinity(workers, is_gpu, 16)
    all_records[lane] = {'resource_pass': resource_pass, 'batches': batches, 'jobs': len(records),
                         'pass': resource_pass and all(row['pass'] for row in records)}
    e.study.write_json(out / 'summary.json', {'acceptance_pass': False, 'scope': identity['scope'],
                                            'lanes': all_records})
    if not all_records[lane]['pass']:
        raise RuntimeError('Prefix corpus failed; all terminal records retained')
print('All nine CPU prefixes and eighteen GPU prefixes pass waveform/resource checks; full acceptance remains false.', flush=True)
