import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/adam/code/ohmnivore')
out = Path('/home/adam/emi03-work/pool-validation-100')
out.mkdir(exist_ok=True)
os.environ['TMPDIR'] = '/home/adam/emi03-work/tmp'
checks = [
 ('lint', ['bazel','lint'], 0),
 ('build', ['bazel','build','--jobs=1','//...'], 0),
 ('test', ['bazel','test','--jobs=1','//...'], 0),
 ('asan', ['bazel','test','--jobs=1','--config=asan','//...'], 0),
 ('ubsan', ['bazel','test','--jobs=1','--config=ubsan','//...'], 0),
 ('lockfile', ['bazel','test','--jobs=1','--lockfile_mode=error','//...'], 0),
 ('ngspice', ['bazel','test','--jobs=1','//acceptance:ngspice_acceptance_test'], 0),
 ('prepared-ac', ['bazel','test','--jobs=1','//cpp:gpu01_prepared_ac_test','//cpp:gpu01_replay_test'], 0),
 ('prepared-ac-benchmark', ['bazel','run','-c','opt','//cpp:prepared_ac_replay_benchmark','--','--warmups=2','--repetitions=9'], 0),
 ('cuda', ['bazel','test','-c','opt','--config=cuda','--jobs=1','--local_test_jobs=1','//cuda:emi03_cuda_test','//cuda:emi03_resident_test','//cuda:emi03_resident_linkage_test','//cuda:emi03_reduction_test','//cuda:emi03_linkage_test','//:cuda_smoke_test'], 0),
 ('protocol', ['bazel','test','-c','opt','--jobs=1','//reference/emi03:gpu_worker_process_test','--test_arg=--worker=/home/adam/emi03-work/block-100/worker'], 0),
]
for sanitizer in ['asan','ubsan']:
    for name,target in [('smoke','//cuda:smoke_test'),('cuda','//cuda:emi03_cuda_test'),('resident','//cuda:emi03_resident_test'),('resident-linkage','//cuda:emi03_resident_linkage_test')]:
        checks.append((name+'-'+sanitizer+'-incompatible', ['bazel','build','--config=cuda','--config='+sanitizer,target], 1))

results = []
for name, command, expected in checks:
    started = time.time()
    print('START ' + name, flush=True)
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    passed = result.returncode == expected
    if expected:
        passed = passed and 'incompatible' in (out / (name + '.log')).read_text()
    record = dict(name=name, command=command, exit_code=result.returncode,
                  expected_exit_code=expected, pass_=passed,
                  elapsed_s=time.time()-started)
    results.append(record)
    (out / 'checks.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if not passed:
        raise SystemExit(1)
