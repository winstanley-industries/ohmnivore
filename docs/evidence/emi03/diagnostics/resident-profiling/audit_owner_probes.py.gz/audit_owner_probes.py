from pathlib import Path
import os,json,hashlib
from reference.emi01 import circuits,metrics,signals
np=signals.np
w=Path('/home/adam/emi03-work');stop=1.03*1e-6;maximum=625e-12
cpu=signals.parse_raw((w/'resident-coupled-68/cpu.raw').read_bytes(),circuits.STUDY_NAMES,stop,maximum)
grid=np.linspace(0,stop,2061);reference={name:np.interp(grid,cpu[:,0],cpu[:,i]) for i,name in enumerate(circuits.STUDY_NAMES)}
records=[]
for folder in ['concurrent-owner-probe-74','concurrent-owner-probe-75','concurrent-owner-probe-76','concurrent-owner-repeat-76','ordinary-four-owners-73','systems-current-profile-73']:
 root=w/folder
 for raw in sorted(root.rglob('*.raw')):
  table=signals.parse_raw(raw.read_bytes(),circuits.STUDY_NAMES,stop,maximum)
  checks={}
  for i,name in enumerate(circuits.STUDY_NAMES):
   if name=='time':continue
   check=metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[name],name.startswith('v('),400)
   checks[name]=check
  stats=json.loads(raw.with_suffix('.json').read_text());native=json.loads(Path(str(raw.with_suffix('.json'))+'.gpu.json').read_text())
  assert stats['status']=='complete' and stats['points']==len(table)
  assert native['peak_device_bytes']<=native['maximum_device_bytes']
  assert all(native[x]==0 for x in ['gpu_fallbacks','outstanding_device_bytes','cleanup_failures','allocation_failures'])
  records.append({'path':str(raw.relative_to(w)),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'points':len(table),'waveforms':checks,'pass':all(c['pass'] for c in checks.values())})
result={'scope':'Shortened trajectory validation only, using original waveform tolerance formulas on a 0.5 ns diagnostic grid. No full-window spectra, stress/loss, feasibility, resource admission or performance acceptance.','cpu_raw_sha256':hashlib.sha256((w/'resident-coupled-68/cpu.raw').read_bytes()).hexdigest(),'jobs':records,'pass':all(x['pass'] for x in records),'acceptance_pass':False}
(w/'owner-probe-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({'jobs':len(records),'pass':result['pass'],'acceptance_pass':False})
assert result['pass']
