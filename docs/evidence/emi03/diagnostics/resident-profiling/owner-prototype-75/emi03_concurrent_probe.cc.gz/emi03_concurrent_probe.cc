#define main Emi03SequentialMain
#include "cpp/benchmarks/emi03_worker.cc"
#undef main

#include <atomic>
#include <barrier>
#include <thread>

// Development-only complete-job owner probe. Each thread executes the ordinary
// worker boundary with private paths/state and the process's shared CUDA context.
int main(int argc, char **argv) {
  if (argc != 4)
    return 2;
  const int count = std::stoi(argv[3]);
  if (count < 1 || count > 16)
    return 2;
  std::vector<std::vector<std::string>> requests;
  for (int i = 0; i < count; ++i) {
    const auto path = std::filesystem::path(argv[2]) / std::to_string(i);
    if (!std::filesystem::create_directories(path))
      return 2;
    requests.push_back({argv[0], argv[1], (path / "gpu.raw").string(),
                        (path / "gpu.json").string()});
  }
  std::atomic<int> failed{0};
  std::barrier started(count);
  std::vector<std::jthread> owners;
  for (int i = 0; i < count; ++i)
    owners.emplace_back([&, i] {
      started.arrive_and_wait();
      if (Execute(requests[i]) != 0)
        ++failed;
    });
  owners.clear();
  return failed.load() == 0 ? 0 : 1;
}
