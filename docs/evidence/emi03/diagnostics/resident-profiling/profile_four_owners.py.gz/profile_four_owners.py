from pathlib import Path
import subprocess,sys,json,time,os
w=Path('/home/adam/emi03-work');out=Path(sys.argv[1]);out.mkdir(exist_ok=True);workers=[];started=time.monotonic()
for i in range(4):
 p=out/str(i);p.mkdir(exist_ok=False);log=(p/'worker.log').open('w')
 args=[str(w/'resident-v73-source/emi03_resident_worker'),str(w/'hardware-profile-70/input.cir'),str(p/'gpu.raw'),str(p/'gpu.json')]
 workers.append((subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT),log,i,time.monotonic()))
results=[]
while workers:
 for worker,log,i,start in list(workers):
  if worker.poll() is not None:
   results.append({'id':i,'returncode':worker.returncode,'observed_wall_s':time.monotonic()-start});log.close();workers.remove((worker,log,i,start))
 if workers:time.sleep(.005)
(out/'owners.json').write_text(json.dumps({'owners':results,'whole_wall_s':time.monotonic()-started,'scope':'four independent shortened-coupled diagnostic owners; instrumented, not qualification or throughput acceptance'},indent=2)+'\n')
assert all(x['returncode']==0 for x in results)
