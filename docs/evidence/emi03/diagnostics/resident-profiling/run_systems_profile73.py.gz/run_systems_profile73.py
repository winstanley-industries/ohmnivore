from pathlib import Path
import os,subprocess,json,hashlib,time,sqlite3
work=Path('/home/adam/emi03-work');out=work/'systems-current-profile-73';out.mkdir(exist_ok=False)
nsys=work/'pinned-profiler-bazel/external/+http_archive+nsight_systems_current/bin/nsys'
worker=work/'resident-v73-source/emi03_resident_worker';deck=work/'hardware-profile-70/input.cir'
args=[str(nsys),'profile','--trace=cuda-sw,nvtx,osrt','--sample=none','--cpuctxsw=none','--gpu-metrics-devices=none','--force-overwrite=false','--output='+str(out/'resident'),str(worker),str(deck),str(out/'gpu.raw'),str(out/'gpu.json')]
env=dict(os.environ,TMPDIR=str(work/'tmp'),EMI03_RESIDENT_PROFILE='1')
start=time.monotonic()
with (out/'trace.log').open('w') as log:p=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
(out/'invocation.json').write_text(json.dumps({'command':args,'returncode':p.returncode,'wall_s':time.monotonic()-start,'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(deck.read_bytes()).hexdigest(),'scope':'Instrumented shortened-coupled diagnostic; not gate timing or qualification.'},indent=2)+'\n')
if p.returncode==0:
 with (out/'stats.log').open('w') as log:subprocess.run([str(nsys),'stats','--report','cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,osrt_sum','--format','csv','--output',str(out/'stats'),str(out/'resident.nsys-rep')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 c=sqlite3.connect(out/'resident.sqlite');tables=c.execute("select name from sqlite_master where type='table'").fetchall()
 diagnostics=c.execute('select * from DIAGNOSTIC_EVENT').fetchall();(out/'diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n');print(tables);print(diagnostics)
 print((out/'stats_cuda_gpu_kern_sum.csv').read_text())
print((out/'trace.log').read_text());raise SystemExit(p.returncode)
