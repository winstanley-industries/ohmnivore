from pathlib import Path
import subprocess,os,time,json,shutil,hashlib
w=Path('/home/adam/emi03-work');root=Path('/home/adam/code/ohmnivore');o=w/'concurrent-owner-probe-76';o.mkdir(exist_ok=False)
worker=o/'probe';shutil.copy2(root/'bazel-bin/cuda/emi03_concurrent_probe',worker)
(o/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','cuda'],cwd=root))
for p in ['cuda/emi03_concurrent_probe.cc','cuda/emi03_real_solver.cu','cuda/BUILD.bazel','cuda/emi03_resident.cu']:shutil.copy2(root/p,o/Path(p).name)
records=[]
for n in [1,4,16]:
 p=o/str(n);start=time.monotonic()
 with (o/f'{n}.log').open('w') as log:result=subprocess.run([str(worker),str(w/'hardware-profile-70/input.cir'),str(p),str(n)],env=dict(os.environ,TMPDIR=str(w/'tmp'),EMI03_RESIDENT_PROFILE='1'),stdout=log,stderr=subprocess.STDOUT,timeout=120)
 row={'owners':n,'wall_s':time.monotonic()-start,'returncode':result.returncode,'scope':'shortened-coupled development diagnostic only; not qualification or acceptance'};records.append(row);print(row,flush=True)
 (o/'summary.json').write_text(json.dumps({'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'results':records},indent=2)+'\n')
 if result.returncode:break
