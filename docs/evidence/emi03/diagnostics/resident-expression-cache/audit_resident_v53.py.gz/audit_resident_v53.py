from pathlib import Path
import gzip,hashlib,io,json,os,subprocess,tarfile,tempfile
root=Path('/home/adam/code/ohmnivore');out=root/'docs/evidence/emi03/diagnostics/resident-expression-cache';work=Path('/home/adam/emi03-work')
identity=json.loads((out/'identity.json').read_text());patch=gzip.decompress((out/'source.patch.gz').read_bytes())
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(patch)==identity['source_patch_sha256']
rf=(root/'bazel-bin/reference/emi03/ensemble.runfiles').resolve()
with tempfile.TemporaryDirectory(prefix='resident-v53-audit-',dir=work/'tmp') as temporary:
 mirror=Path(temporary);scratch=mirror/'_main';scratch.mkdir()
 for entry in rf.iterdir():
  if entry.name!='_main':(mirror/entry.name).symlink_to(entry)
 archive=subprocess.check_output(['git','archive',identity['base_commit'],'cpp','cuda','.bazelrc','MODULE.bazel','MODULE.bazel.lock','reference','third_party/emi_python'],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(archive)) as source:source.extractall(scratch,filter='data')
 subprocess.run(['git','apply','--'],input=patch,cwd=scratch,check=True)
 (scratch/'third_party/emi_python/libz.so.1').symlink_to(rf/'_main/third_party/emi_python/libz.so.1')
 for p,expected in {**identity['source_files'],**identity['comparison_sources']}.items():assert sha((scratch/p).read_bytes())==expected,p
 assert sha((work/'resident-v53-source/emi03_resident_worker').read_bytes())==identity['gpu_binary_sha256']
 assert sha((rf/'_main/cpp/emi03_cpu_worker').read_bytes())==identity['cpu_binary_sha256']
 data=scratch/'data';data.mkdir()
 for p,expected in json.loads((out/'raw-index.json').read_text()).items():
  encoded=(out/p).read_bytes();raw=gzip.decompress(encoded)
  assert sha(encoded)==expected['gzip_sha256'] and len(encoded)==expected['gzip_bytes']
  assert sha(raw)==expected['raw_sha256'] and len(raw)==expected['raw_bytes']
  (data/p.removesuffix('.gz')).write_bytes(raw)
 script=scratch/'compare.py';script.write_bytes((out/'compare.py').read_bytes())
 env=dict(os.environ,RUNFILES_DIR=str(mirror),PYTHONPATH=':'.join([str(scratch),str(rf/'rules_python+'),str(next(rf.glob('rules_python++pip+*'))/'site-packages')]))
 python=next(rf.glob('rules_python++python+*/bin/python3'))
 subprocess.run([str(python),str(script),str(data)],env=env,check=True,stdout=subprocess.DEVNULL)
 comparison=json.loads((data/'comparison.json').read_text());assert comparison==json.loads((out/'comparison.json').read_text()) and comparison['comparison']['pass']
checks=json.loads((out/'validation/checks.json').read_text());assert len(checks)==18 and all(c['pass_'] for c in checks)
scope=json.loads((out/'validation/scope.json').read_text());assert scope['pass'] and not scope['changed_protected_paths']
native=json.loads((out/'gpu.json.gpu.json').read_text())
for key in ['gpu_fallbacks','outstanding_device_bytes','cleanup_failures','allocation_failures']:assert native[key]==0,key
summary=json.loads((out/'summary.json').read_text())
for record in summary['results'].values():assert record['returncode']==0 and record['wall_s']<120
result={'audit_pass':True,'acceptance_pass':False,'source_reconstruction_pass':True,'source_files':len(identity['source_files']),'comparison_sources':len(identity['comparison_sources']),'binary_identity_pass':True,'raw_reconstruction_pass':True,'full_q0_dpt_comparison_reproduced':True,'canonical_checks_passed':len(checks),'protected_scope_pass':True,'scope':'One frozen q0 DPT diagnostic; no full qualification, aggregate resources or performance pass.'}
(out/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
