import json,os,subprocess,time
from pathlib import Path
w=Path('/home/adam/emi03-work');root=Path('/home/adam/code/ohmnivore')
steps=[('sanitizers',['python3',str(w/'run_pool_sanitizers81.py')]),('cuda',['bazel','test','-c','opt','--config=cuda','--jobs=1','--local_test_jobs=1','//cuda:emi03_cuda_test','//cuda:emi03_resident_test','//cuda:emi03_resident_linkage_test','//cuda:emi03_reduction_test','//cuda:emi03_linkage_test','//:cuda_smoke_test']),('protocol',['bazel','test','-c','opt','--jobs=1','//reference/emi03:gpu_worker_process_test','--test_arg=--worker='+str(w/'pool-worker-81')]),('dpt',['python3',str(w/'run_pool_dpt81.py')])]
records=[]
for name,cmd in steps:
 print('START '+name,flush=True);start=time.time()
 with (w/('pool-checks81-'+name+'.log')).open('w') as log:code=subprocess.call(cmd,cwd=root,env=dict(os.environ,TMPDIR=str(w/'tmp')),stdout=log,stderr=subprocess.STDOUT)
 row={'stage':name,'command':cmd,'exit_code':code,'elapsed_s':time.time()-start};records.append(row);print(json.dumps(row),flush=True)
 (w/'pool-checks81.json').write_text(json.dumps(records,indent=2)+'\n')
 if code:raise SystemExit(code)
