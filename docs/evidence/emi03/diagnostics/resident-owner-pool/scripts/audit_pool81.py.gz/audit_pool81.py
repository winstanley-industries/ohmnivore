from reference.emi03 import ensemble as e
from pathlib import Path
import gzip,io,json,tarfile
root=Path('/home/adam/code/ohmnivore');out=root/'docs/evidence/emi03/diagnostics/resident-owner-pool'
identity=json.loads((out/'identity.json').read_text())
with tarfile.open(fileobj=io.BytesIO(gzip.decompress((out/'sources.tar.gz').read_bytes()))) as tar:
 assert set(tar.getnames())==set(identity['sources'])
 for name,want in identity['sources'].items():
  assert e.study.sha(tar.extractfile(name).read())==want,name
  assert e.study.sha((root/name).read_bytes())==want,name
summary=json.loads((out/'dpt/summary.json').read_text());checks=[];refinements=[]
for lane in ['cpu','gpu']:
 result=summary['results'][lane];records=result['jobs'];bylevel={j['level']:j for j in records}
 assert result['expected_jobs']==result['completed_jobs']==3 and set(bylevel)=={0,1,2}
 for level,row in bylevel.items():
  table=e.study.restore(out/'dpt'/lane,row)
  assert e.metrics.dpt(table,row['sample_step_s'])==row['metrics'] and row['metrics']['pass']
  if lane=='gpu':
   cpu={j['level']:j for j in summary['results']['cpu']['jobs']}[level]
   actual=e.compare_pair(table,row,e.study.restore(out/'dpt/cpu',cpu),cpu)
   assert actual==row['cpu_validation'] and actual['pass']
   e.validate_gpu_telemetry(row['gpu'],row['request_input'])
  checks.append(lane+'-'+row['id'])
 for level in [1,2]:refinements.append(e.study.dpt_compare(bylevel[level-1]['metrics'],bylevel[level]['metrics'],f'{lane}-q{level-1}-q{level}'))
 manifest=e.study.selected_manifest('emi01-v2')
 for dt in manifest['dpt_sample_steps_s'][:2]:refinements.append(e.study.dpt_compare(e.metrics.dpt(e.study.restore(out/'dpt'/lane,bylevel[2]),dt),bylevel[2]['metrics'],f'{lane}-output-{dt}'))
 workers=json.loads((out/'dpt'/(lane+'-workers.json')).read_text())
 resource=json.loads((out/'dpt'/(lane+'-resources.json')).read_text())
 assert e.audit_resources(resource,records,workers,lane=='gpu')
 e.audit_worker_affinity(workers,lane=='gpu',16 if lane=='gpu' else 1)
assert refinements==summary['refinements'] and len(refinements)==8 and all(r['pass'] for r in refinements)
assert summary['dpt_pass'] and summary['audit_pass'] and not summary['acceptance_pass']
record={'pass':True,'source_files':len(identity['sources']),'reconstructed_raw_and_metrics':checks,'refinement_checks':8,'cpu_gpu_differential_checks':3,'scope':'DPT source/raw/metrics/refinement/owner/resource reconstruction only','acceptance_pass':False}
e.study.write_json(out/'audit.json',record);print(json.dumps(record))
