import hashlib,json,os,subprocess,time
from pathlib import Path
w=Path('/home/adam/emi03-work');out=w/'pool-sanitizers-81-concurrent';out.mkdir(exist_ok=False)
tool=w/'pinned-profiler-bazel/external/+http_archive+compute_sanitizer_current/compute-sanitizer/compute-sanitizer'
binary=w/'pool-test-runtime-81/cuda/emi03_resident_test'
common='Emi03Resident.ConcurrentJobsKeepStateAndFailureOwnershipPrivate:Emi03Resident.WideOutputRowsCrossChunkBoundariesWithoutCorruption:Emi03Resident.DynamicGpuPivotsDoNotHideBehindZeroResponse'
checks=[('race-concurrent','racecheck','Emi03Resident.ConcurrentJobsKeepStateAndFailureOwnershipPrivate',[])]
records=[]
for name,mode,selected,extra in checks:
 cmd=[str(tool),'--tool',mode,'--error-exitcode','99',*extra,str(binary),'--gtest_filter='+selected]
 print('START '+name,flush=True);started=time.time()
 with (out/(name+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,env=dict(os.environ,TMPDIR=str(w/'tmp')),stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
  except subprocess.TimeoutExpired:code=124
 text=(out/(name+'.log')).read_text();passed=code==0 and ('RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)' in text if mode=='racecheck' else 'ERROR SUMMARY: 0 errors' in text) and 'Internal Sanitizer Error' not in text
 row={'name':name,'tool':mode,'command':cmd,'exit_code':code,'pass':passed,'elapsed_s':time.time()-started,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'Full concurrent 16-job race check, all launches; instrumented correctness only.'};records.append(row)
 (out/'checks.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 if not passed:raise SystemExit(1)
