"""Fresh full DPT refinements through the actual persistent owner protocol."""
from reference.emi03 import ensemble as e
from pathlib import Path
import json,os,shutil,subprocess,time
root=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');r=Path(os.environ['RUNFILES_DIR'])
out=w/'pool-dpt-81';out.mkdir(exist_ok=False)
sources=e.identities();snapshot=out/'sources'
for name in sources:
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(e.qualification.ROOT/name,target)
archive=r/'+http_file+emi01_microchip_model/file/model.zip'
binaries={'cpu':r/'_main/cpp/emi03_cpu_worker','gpu':w/'pool-worker-81'}
manifest=e.study.selected_manifest('emi01-v2');specs=[s for s in e.qualification.expected_specs(manifest) if s['fixture']=='dpt']
assert len(specs)==3
identity={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':sources,'binaries':{k:e.study.sha(v.read_bytes()) for k,v in binaries.items()},'gpu_execution_model':e.GPU_EXECUTION_MODEL,'scope':'DPT CPU differential, refinement and pool resource diagnostic; no full EMI-03 acceptance'}
e.study.write_json(out/'identity.json',identity)
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root))
records={};workers={};resources={};results={}
for lane,binary in binaries.items():
 gpu=lane=='gpu';pool=e.PersistentPool(binary,out/(lane+'-workers'),manifest['limits'],gpu,16 if gpu else 1)
 try:
  result=e.complete_study(specs,identity['binaries'][lane],archive,out/lane,pool,gpu,{x['id']:x for x in records['cpu']} if gpu else None,out/'cpu' if gpu else None)
 finally:
  workers[lane]=pool.close();resources[lane]=e.pool_resources(pool)
 records[lane]=result['jobs'];results[lane]=result
 e.study.write_json(out/(lane+'-workers.json'),workers[lane]);e.study.write_json(out/(lane+'-resources.json'),resources[lane])
 print(json.dumps({'lane':lane,'pass':result['pass'],'wall_s':[x.get('process',{}).get('wall_s') for x in result['jobs']],'status':[x['status'] for x in result['jobs']]}),flush=True)
refinements=[];audits=[]
for lane in binaries:
 bylevel={x['level']:x for x in records[lane]};assert set(bylevel)=={0,1,2}
 for level in range(3):
  row=bylevel[level];table=e.study.restore(out/lane,row);measured=e.metrics.dpt(table,row['sample_step_s'])
  assert measured==row['metrics'] and measured['pass']
  if lane=='gpu':
   cpu={x['level']:x for x in records['cpu']}[level]
   compared=e.compare_pair(table,row,e.study.restore(out/'cpu',cpu),cpu)
   assert compared==row['cpu_validation'] and compared['pass'];e.validate_gpu_telemetry(row['gpu'],row['request_input'])
 for level in [1,2]:refinements.append(e.study.dpt_compare(bylevel[level-1]['metrics'],bylevel[level]['metrics'],f'{lane}-q{level-1}-q{level}'))
 for dt in manifest['dpt_sample_steps_s'][:2]:refinements.append(e.study.dpt_compare(e.metrics.dpt(e.study.restore(out/lane,bylevel[2]),dt),bylevel[2]['metrics'],f'{lane}-output-{dt}'))
 assert e.audit_resources(resources[lane],records[lane],workers[lane],lane=='gpu')
 e.audit_worker_affinity(workers[lane],lane=='gpu',16 if lane=='gpu' else 1);audits.append(lane)
assert sources==e.identities()
summary={'scope':identity['scope'],'acceptance_pass':False,'dpt_pass':all(x['pass'] for x in results.values()) and len(refinements)==8 and all(x['pass'] for x in refinements),'audit_pass':audits==['cpu','gpu'],'refinements':refinements,'resources':resources,'results':results}
e.study.write_json(out/'summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['refinements','resources','results']}),flush=True)
