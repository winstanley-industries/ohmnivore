import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/adam/code/ohmnivore')
out = Path('/home/adam/emi03-work/pool-validation-81')
out.mkdir(exist_ok=True)
os.environ['TMPDIR'] = '/home/adam/emi03-work/tmp'
checks = [('lint', ['bazel','lint'], 0), ('prepared-ac-benchmark', ['bazel','run','-c','opt','//cpp:prepared_ac_replay_benchmark','--','--warmups=2','--repetitions=9'], 0)]
for sanitizer in ['asan','ubsan']:
    for name,target in [('smoke','//cuda:smoke_test'),('cuda','//cuda:emi03_cuda_test'),('resident','//cuda:emi03_resident_test'),('resident-linkage','//cuda:emi03_resident_linkage_test')]:
        checks.append((name+'-'+sanitizer+'-incompatible', ['bazel','build','--config=cuda','--config='+sanitizer,target], 1))

results = []
for name, command, expected in checks:
    started = time.time()
    print('START ' + name, flush=True)
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    passed = result.returncode == expected
    if expected:
        passed = passed and 'incompatible' in (out / (name + '.log')).read_text()
    record = dict(name=name, command=command, exit_code=result.returncode,
                  expected_exit_code=expected, pass_=passed,
                  elapsed_s=time.time()-started)
    results.append(record)
    (out / 'checks.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if not passed:
        raise SystemExit(1)
