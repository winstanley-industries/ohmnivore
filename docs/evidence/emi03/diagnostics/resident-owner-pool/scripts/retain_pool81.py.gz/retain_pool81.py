from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
root=Path('/home/adam/code/ohmnivore');work=Path('/home/adam/emi03-work')
out=root/'docs/evidence/emi03/diagnostics/resident-owner-pool';out.mkdir(exist_ok=True)
source=work/'pool-dpt-81';identity=json.loads((source/'identity.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def put(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def archive(src,dst):
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w') as tar:
  for p in sorted(src.rglob('*')):
   if p.is_file():
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(src)));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 dst.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
for p,h in identity['sources'].items():
 assert sha((source/'sources'/p).read_bytes())==h,p
 assert sha((root/p).read_bytes())==h,p
assert sha((work/'pool-worker-81').read_bytes())==identity['binaries']['gpu']
copy(source/'identity.json',out/'identity.json');archive(source/'sources',out/'sources.tar.gz')
(out/'source.patch.gz').write_bytes(gzip.compress((source/'source.patch').read_bytes(),mtime=0))
for lane in ['cpu','gpu']:
 shutil.copytree(source/lane,out/'dpt'/lane,dirs_exist_ok=True)
 for suffix in ['-workers.json','-resources.json']:copy(source/(lane+suffix),out/'dpt'/(lane+suffix))
put(out/'dpt/worker-log-identities.json',{str(p.relative_to(source)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for lane in ['cpu','gpu'] for p in sorted((source/(lane+'-workers')).rglob('*')) if p.is_file()})
copy(source/'summary.json',out/'dpt/summary.json');copy(work/'pool-checks81-dpt.log',out/'dpt/execution.log')
for version in ['77','77b','78','79','80','81','81-concurrent']:
 origin=work/('pool-sanitizers-'+version)
 assert origin.exists()
 shutil.copytree(origin,out/'sanitizers'/version,dirs_exist_ok=True)
 runtime=work/('pool-test-runtime-'+('77' if version=='77b' else '81' if version=='81-concurrent' else version))
 if (runtime/'files.json').exists():copy(runtime/'files.json',out/'sanitizers'/version/'runtime-files.json')
for label,origin in [('pre-lifetime-fix',work/'pool-candidate77-before-lifetime-fix'),('v80',work/'pool-source-80')]:
 archive(origin,out/('sanitizers/'+label+'-sources.tar.gz'))
for version in ['78','81']:
 shutil.copytree(work/('pool-validation-'+version),out/'validation'/('canonical-'+version),dirs_exist_ok=True)
 assert all(row['pass_'] for row in json.loads((work/('pool-validation-'+version)/'checks.json').read_text()))
for name in ['cuda','protocol']:copy(work/('pool-checks81-'+name+'.log'),out/'validation'/(name+'.log'))
copy(work/'pool-checks81.json',out/'validation/pipeline.json')
copy(work/'worker-pool81-build.log',out/'validation/cuda-build.log')
scope=json.loads((root/'docs/evidence/emi03/validation/scope.json').read_text());scope['changed_protected_paths']=subprocess.check_output(['git','diff','--name-only',scope['base'],'--',*scope['protected_paths']],cwd=root,text=True).splitlines();scope['pass']=not scope['changed_protected_paths'];assert scope['pass'];put(out/'validation/scope.json',scope)
for name in ['MODULE.bazel','MODULE.bazel.lock','.bazelversion']:
 p=work/'pinned-profiler'/name
 dest=out/'profiler'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
tool=work/'pinned-profiler-bazel/external/+http_archive+compute_sanitizer_current/compute-sanitizer/compute-sanitizer'
put(out/'profiler/identity.json',{'tool':'NVIDIA Compute Sanitizer','version':subprocess.check_output([str(tool),'--version'],text=True).strip(),'binary_sha256':sha(tool.read_bytes()),'archive_url':'https://developer.download.nvidia.com/compute/cuda/redist/cuda_sanitizer_api/linux-x86_64/cuda_sanitizer_api-linux-x86_64-13.4.92-archive.tar.xz','archive_sha256':'bf5303fe49d8ab871876213a7a2cf9ebe844406a293dbd05cd327f52c976a726','solver_toolchain':'unchanged checksum-pinned CUDA 13.0.2 / GCC 15.2.0','scope':'Correctness instrumentation; no acceptance timing'})
scripts={}
for name in ['pool_dpt81.py','run_pool_dpt81.py','run_pool_checks81.py','run_pool_sanitizers81.py','run_pool_sanitizers81_concurrent.py','run_pool_validation78.py','run_pool_validation81.py','retain_pool81.py']:
 data=(work/name).read_bytes();dest=out/'scripts'/(name+'.gz');dest.parent.mkdir(exist_ok=True);dest.write_bytes(gzip.compress(data,mtime=0));scripts[name]={'bytes':len(data),'sha256':sha(data)}
put(out/'scripts/files.json',scripts)
summary=json.loads((source/'summary.json').read_text());assert summary['dpt_pass'] and summary['audit_pass'] and not summary['acceptance_pass']
assert all(r['pass'] for r in json.loads((work/'pool-sanitizers-81/checks.json').read_text()))
put(out/'checkpoint.json',{'scope':'Owner-pool, DPT and sanitizer development checkpoint','acceptance_pass':False,'dpt_pass':True,'dpt_refinement_checks':len(summary['refinements']),'resource_scope':'Three DPT jobs only, using a 16-owner GPU pool','source_files':len(identity['sources']),'remaining':'Fresh full coupled/ngspice qualification and both 9/36-job performance invocations against the frozen targets'})
print('retained owner-pool checkpoint; full EMI-03 acceptance remains false')
