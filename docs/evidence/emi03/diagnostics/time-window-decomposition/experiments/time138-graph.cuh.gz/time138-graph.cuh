struct WindowGraphState {
 int iterations,refinements,backtrack,error,converged,accepted;
 unsigned long long total_refinements,total_backtracks;
 double previous_residual,residual,update;
 double trace[100][4];
};
__global__ void WindowGraphReset(WindowGraphState *state,TimeData *data,NonlinearWindow window) {
 if(threadIdx.x==0){*state={};state->previous_residual=INFINITY;*data[0].error=0;*data[0].invalid=0;*data[0].nonzero=0;*window.error=0;}
}
__global__ void WindowGraphBeginLinear(WindowGraphState *s,TimeData *data,cudaGraphConditionalHandle loop) {
 if(threadIdx.x==0){s->refinements=0;*data[0].invalid=0;*data[0].nonzero=0;cudaGraphSetConditional(loop,1);}
}
__global__ void WindowGraphClearResidual(TimeData *data) {
 if(threadIdx.x==0){*data[0].invalid=0;*data[0].nonzero=0;}
}
__global__ void WindowGraphLinearDecision(WindowGraphState *s,TimeData *data,cudaGraphConditionalHandle loop,cudaGraphConditionalHandle correct) {
 if(threadIdx.x==0){bool again=false;if(*data[0].error)s->error=*data[0].error;else if(*data[0].invalid||(s->refinements==0&&*data[0].nonzero)){if(s->refinements<4){again=true;++s->refinements;++s->total_refinements;}else s->error=Invalid;}cudaGraphSetConditional(loop,again);cudaGraphSetConditional(correct,again);}
}
__global__ void WindowGraphBeginBacktrack(WindowGraphState *s,cudaGraphConditionalHandle loop) {
 if(threadIdx.x==0){s->backtrack=0;s->accepted=0;cudaGraphSetConditional(loop,s->error?0:1);}
}
__global__ void WindowGraphTrial(const Model *models,const TimeData *data,NonlinearWindow window,WindowGraphState *s) {
 const int at=blockIdx.x*blockDim.x+threadIdx.x,n=models[0].n;
 if(at==0)*window.error=0;
 if(at<n*window.length)window.candidate[at]=window.current[at]+ldexp(1.,-s->backtrack)*(data[0].solution[at]-window.current[at]);
}
__global__ void WindowGraphBacktrackDecision(NonlinearWindow window,WindowGraphState *s,cudaGraphConditionalHandle loop) {
 if(threadIdx.x!=0)return;
 const int error=*window.error;double residual=0,update=0;
 if(!error)for(int i=0;i<window.length;++i){residual=fmax(residual,window.metrics[2*i]);update=fmax(update,window.metrics[2*i+1]);}
 if(error&&error!=Nonfinite)s->error=error;
 if(!error&&(residual<s->previous_residual||residual<=1)){s->accepted=1;s->residual=residual;s->update=update;cudaGraphSetConditional(loop,0);return;}
 if(s->error||s->backtrack==16){if(!s->error)s->error=Nonconvergence;cudaGraphSetConditional(loop,0);return;}
 ++s->backtrack;++s->total_backtracks;cudaGraphSetConditional(loop,1);
}
__global__ void WindowGraphNext(WindowGraphState *s,cudaGraphConditionalHandle loop,cudaGraphConditionalHandle certify) {
 if(threadIdx.x!=0)return;
 if(s->error||!s->accepted){if(!s->error)s->error=Nonconvergence;cudaGraphSetConditional(loop,0);cudaGraphSetConditional(certify,0);return;}
 const int at=s->iterations++;s->trace[at][0]=s->residual;s->trace[at][1]=s->update;s->trace[at][2]=s->backtrack;s->trace[at][3]=s->refinements;
 s->converged=s->residual<=1&&s->update<=1;s->previous_residual=s->residual;
 if(!s->converged&&s->iterations>=100)s->error=Nonconvergence;
 cudaGraphSetConditional(loop,!s->error&&!s->converged);cudaGraphSetConditional(certify,s->converged);
}
__global__ void WindowGraphCommit(const Model *models,NonlinearWindow window,const WindowGraphState *s) {
 const int at=blockIdx.x*blockDim.x+threadIdx.x;
 if(!s->error&&!s->converged&&at<window.length*models[0].n)window.current[at]=window.candidate[at];
}
__global__ void WindowGraphFinish(WindowGraphState *s,NonlinearWindow window) {
 if(threadIdx.x==0&&*window.error){s->error=*window.error;s->converged=0;}
}
class WindowGraph {
public:
 cudaGraph_t graph=nullptr;cudaGraphExec_t executable=nullptr;
 WindowGraph(){CheckCuda(cudaGraphCreate(&graph,0),"window graph create");}
 ~WindowGraph(){if(executable&&cudaGraphExecDestroy(executable)!=cudaSuccess)++emi03_cuda_internal::Statistics().cleanup_failures;if(graph&&cudaGraphDestroy(graph)!=cudaSuccess)++emi03_cuda_internal::Statistics().cleanup_failures;}
 template<class F,class...Args> static void Kernel(cudaGraph_t graph,cudaGraphNode_t &tail,dim3 grid,dim3 block,std::size_t bytes,F function,Args...args) {
  void *arguments[]{static_cast<void*>(&args)...};cudaKernelNodeParams p{};p.func=reinterpret_cast<void*>(function);p.gridDim=grid;p.blockDim=block;p.sharedMemBytes=bytes;p.kernelParams=arguments;
  cudaGraphNode_t next=nullptr;CheckCuda(cudaGraphAddKernelNode(&next,graph,tail?&tail:nullptr,tail?1:0,&p),"window graph kernel");tail=next;
 }
 static cudaGraphConditionalHandle Handle(cudaGraph_t graph,unsigned int initial=0){cudaGraphConditionalHandle h{};CheckCuda(cudaGraphConditionalHandleCreate(&h,graph,initial,cudaGraphCondAssignDefault),"window conditional handle");return h;}
 static cudaGraph_t Conditional(cudaGraph_t graph,cudaGraphNode_t &tail,cudaGraphConditionalHandle handle,cudaGraphConditionalNodeType type){cudaGraphNodeParams p{};p.type=cudaGraphNodeTypeConditional;p.conditional.handle=handle;p.conditional.type=type;p.conditional.size=1;cudaGraphNode_t next=nullptr;CheckCuda(cudaGraphAddNode(&next,graph,tail?&tail:nullptr,nullptr,tail?1:0,&p),"window conditional node");tail=next;return p.conditional.phGraph_out[0];}
 static void Pass(cudaGraph_t graph,cudaGraphNode_t &tail,const Model *models,const Workspace *workspace,TimeData *data,int length,bool correction){
  Kernel(graph,tail,dim3((length+7)/8),dim3(Threads),8*3*185*sizeof(double),TimeWarpIndependent,models,workspace,data,length,correction);bool input_a=true;
  for(int level=0;(1<<level)<length;++level){Kernel(graph,tail,dim3(length),dim3(Threads),0,TimeScan,data,length,level,input_a);input_a=!input_a;}
  Kernel(graph,tail,dim3(length),dim3(Threads),0,TimeRecover,models,data,length,input_a,correction);
 }
 WindowGraphState Run(const Model *models,const Workspace *workspace,TimeData *data,NonlinearWindow window,std::size_t bytes,Allocations &allocation){
  auto *state=allocation.Allocate<WindowGraphState>(1);const int length=window.length;cudaGraphNode_t root_tail=nullptr;
  const auto loop=Handle(graph,1),certify=Handle(graph);
  Kernel(graph,root_tail,1,1,0,WindowGraphReset,state,data,window);
  Kernel(graph,root_tail,dim3((length*185+Threads-1)/Threads),dim3(Threads),0,NonlinearWindowSeed,models,data,window);
  auto body=Conditional(graph,root_tail,loop,cudaGraphCondTypeWhile);cudaGraphNode_t tail=nullptr;
  Kernel(body,tail,dim3(length),dim3(Threads),bytes,NonlinearWindowAffine,models,workspace,data,window);
  Pass(body,tail,models,workspace,data,length,false);
  const auto linear_loop=Handle(body);Kernel(body,tail,1,1,0,WindowGraphBeginLinear,state,data,linear_loop);
  auto linear_body=Conditional(body,tail,linear_loop,cudaGraphCondTypeWhile);cudaGraphNode_t linear_tail=nullptr;
  const auto correct=Handle(linear_body);
  Kernel(linear_body,linear_tail,1,1,0,WindowGraphClearResidual,data);
  Kernel(linear_body,linear_tail,dim3(length),dim3(Threads),0,TimeResidual,models,workspace,data,length);
  Kernel(linear_body,linear_tail,1,1,0,WindowGraphLinearDecision,state,data,linear_loop,correct);
  auto correct_body=Conditional(linear_body,linear_tail,correct,cudaGraphCondTypeIf);cudaGraphNode_t correct_tail=nullptr;Pass(correct_body,correct_tail,models,workspace,data,length,true);
  const auto back=Handle(body);Kernel(body,tail,1,1,0,WindowGraphBeginBacktrack,state,back);
  auto back_body=Conditional(body,tail,back,cudaGraphCondTypeWhile);cudaGraphNode_t back_tail=nullptr;
  Kernel(back_body,back_tail,dim3((length*185+Threads-1)/Threads),dim3(Threads),0,WindowGraphTrial,models,data,window,state);
  Kernel(back_body,back_tail,dim3(length),dim3(Threads),bytes,NonlinearWindowCheck,models,workspace,data,window,false);
  Kernel(back_body,back_tail,1,1,0,WindowGraphBacktrackDecision,window,state,back);
  Kernel(body,tail,1,1,0,WindowGraphNext,state,loop,certify);
  Kernel(body,tail,dim3((length*185+Threads-1)/Threads),dim3(Threads),0,WindowGraphCommit,models,window,state);
  auto certify_body=Conditional(graph,root_tail,certify,cudaGraphCondTypeIf);cudaGraphNode_t certify_tail=nullptr;
  Kernel(certify_body,certify_tail,dim3(length),dim3(Threads),bytes,NonlinearWindowCheck,models,workspace,data,window,true);
  Kernel(graph,root_tail,1,1,0,WindowGraphFinish,state,window);
  CheckCuda(cudaGraphInstantiate(&executable,graph,0),"window graph instantiate");
  const auto start=std::chrono::steady_clock::now();CheckCuda(cudaGraphLaunch(executable,allocation.stream()),"window graph launch");WindowGraphState result{};allocation.Copy(&result,state,sizeof(result),cudaMemcpyDeviceToHost);
  std::cout<<"{\"kind\":\"graph_execution\",\"wall_s\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<",\"iterations\":"<<result.iterations<<",\"linear_refinements\":"<<result.total_refinements<<",\"backtracks\":"<<result.total_backtracks<<",\"error\":"<<result.error<<"}\n";
  return result;
 }
};
