from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'time137c.cu').read_text()
a=s.index('int NonlinearTimeProbe(');s=s[:a]+(w/'time138-graph.cuh').read_text()+'\n'+s[a:]
s=s.replace('const char *fixture, int length) {\n  auto h = ReadNonlinearWindow', 'const char *fixture, int length, bool graph_mode) {\n  auto h = ReadNonlinearWindow')
a=s.index('    for (int iteration = 0; iteration < 100; ++iteration)');b=s.index('    const double seconds =',a)
s=s[:a]+'''    if(graph_mode) {
      WindowGraph graph;auto result=graph.Run(dm,dw,dt,window,bytes,allocation);converged=result.converged;accepted_iterations=result.iterations;
      for(int i=0;i<result.iterations;++i)std::cout<<"{\\"kind\\":\\"graph_iteration\\",\\"iteration\\":"<<i<<",\\"residual\\":"<<result.trace[i][0]<<",\\"update\\":"<<result.trace[i][1]<<",\\"backtracks\\":"<<result.trace[i][2]<<",\\"linear_refinements\\":"<<result.trace[i][3]<<"}\\n";
      if(result.error&&result.error!=Nonconvergence)throw std::runtime_error("graph window failure "+std::to_string(result.error));
    } else {
'''+s[a:b]+'    }\n'+s[b:]
s=s.replace('if (argc != 4)', 'if ((argc != 4 && argc!=5) || (argc==5 && std::string(argv[4])!="--graph"))')
s=s.replace('argv[1], argv[2], std::stoi(argv[3]));', 'argv[1], argv[2], std::stoi(argv[3]),argc==5);')
assert 'bool graph_mode)' in s
(r/'cuda/emi03_time_nonlinear_probe.cu').write_text(s)
