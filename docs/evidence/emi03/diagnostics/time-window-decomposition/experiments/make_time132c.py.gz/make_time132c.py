from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'time132b.cu').read_text()
s=s.replace('double *transfer, *powers, *rhs, *initial, *solution, *residual;', 'double *transfer, *powers, *rhs, *initial, *solution, *residual;\n  double *transfer_certificate;')
a=s.index('__device__ void CachedTimeLinear(');b=s.index('__device__ void LoadTimeFactor',a);f=s[a:b].replace('void CachedTimeLinear(const Model &m, Workspace &w, Shared &s)', 'void IntermediateTimeLinear(const Model &m, Workspace &w, Shared &s, double *certificate)')
assert 'void IntermediateTimeLinear' in f;f=f.replace('component <= 1e-5 &&','')
f=f.replace('        accepted = true;','        if(threadIdx.x==0 && certificate) { certificate[0]=denom==0?0:normalized/denom; certificate[1]=component; }\n        accepted = true;')
f='// Internal transfer/particular solutions are preconditioner work, not accepted\n// timestep states. Full original per-step componentwise certification occurs in\n// TimeResidual and on the independent CPU after coupled recovery.\n'+f
s=s[:b]+f+s[b:]
a=s.index('__global__ void MakeTimeTransfer');b=s.index('__global__ void TimePower',a);f=s[a:b].replace('CachedTimeLinear(m, w, s);','IntermediateTimeLinear(m, w, s, t.transfer_certificate + 2 * col);');s=s[:a]+f+s[b:]
a=s.index('__global__ void TimeIndependent');b=s.index('__global__ void TimeScan',a);f=s[a:b].replace('CachedTimeLinear(m, w, s);','IntermediateTimeLinear(m, w, s, nullptr);');s=s[:a]+f+s[b:]
s=s.replace('  t.transfer = allocation.Allocate<double>(m.n * t.rank);','  t.transfer = allocation.Allocate<double>(m.n * t.rank);\n  t.transfer_certificate = allocation.Allocate<double>(2 * t.rank);')
s=s.replace('    CheckTimeErrors("transfer", data, allocation);','''    CheckTimeErrors("transfer", data, allocation);
    for(std::size_t job=0;job<data.size();++job){std::vector<double> certificate(2*active.size());allocation.Copy(certificate.data(),data[job].transfer_certificate,certificate.size()*sizeof(double),cudaMemcpyDeviceToHost);double norm=0,component=0;for(std::size_t i=0;i<active.size();++i){norm=std::max(norm,certificate[2*i]);component=std::max(component,certificate[2*i+1]);}std::cout<<"{\\"kind\\":\\"internal_transfer\\",\\"case\\":"<<job<<",\\"normwise\\":"<<norm<<",\\"componentwise\\":"<<component<<"}\\n";}
''')
assert 'transfer_certificate = allocation' in s
(r/'cuda/emi03_time_matrix_probe.cu').write_text(s)
