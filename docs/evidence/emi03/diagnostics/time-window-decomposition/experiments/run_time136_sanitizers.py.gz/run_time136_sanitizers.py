from pathlib import Path
import subprocess,time,json,os
w=Path('/home/adam/emi03-work');tool=w/'pinned-profiler-bazel/external/+http_archive+compute_sanitizer_current/compute-sanitizer/compute-sanitizer';args=[str(w/'time136-binary'),str(w/'schur-replay117.txt'),str(w/'time-mass132.txt'),str(w/'time-oracle133.txt'),'--validate-only'];results=[]
for name in ['memcheck','racecheck','synccheck','initcheck']:
 command=[str(tool),'--tool',name,'--error-exitcode','99']
 if name=='racecheck':command+=['--kernel-name','kns=TimeWarpIndependent']
 command+=args
 start=time.monotonic();p=w/f'time136-{name}.log'
 with p.open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,TMPDIR=str(w/'tmp')))
 result={'tool':name,'returncode':r.returncode,'wall_s':time.monotonic()-start,'command':command,'scope':'all TimeWarpIndependent launches' if name=='racecheck' else 'complete validation invocation'};results.append(result);print(json.dumps(result),flush=True)
 (w/'time136-sanitizers.json').write_text(json.dumps(results,indent=2)+'\n')
