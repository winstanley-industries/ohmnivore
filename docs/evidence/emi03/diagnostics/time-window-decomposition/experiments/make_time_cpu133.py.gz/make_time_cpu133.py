from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'selected119b.cu').read_text();common=s[s.index('template <class T> T ProbeChecked'):s.index('std::size_t ProbePrepare')];host=(w/'time132_host.cc').read_text();read=host[:host.index('TimeData PrepareTimeData')]
code='''#include "ohmnivore/solver.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
namespace {
using namespace ohmnivore;
'''+common+read+'''
int Oracle(const char *replay,const char *mass) {
  std::vector<int> active;const auto cases=ReadTime(replay,mass,active);
  std::cout << std::setprecision(17) << "EMI03_TIME_ORACLE_1 " << cases.size() << " 185 512\\n";
  double maximum=0,difference=0;
  for(const auto &h:cases){const auto &a=h.sample.a;const int n=a.rows;
    auto factor=ProbeChecked(SparseRealFactorization::Analyze(a));
    std::vector<double> previous(h.truth.begin(),h.truth.begin()+n),rhs(n);
    std::cout << h.sample.name << " " << h.step << "\\n";
    for(int point=0;point<512;++point){
      for(int row=0;row<n;++row){long double value=h.rhs[point*n+row];
        for(auto j=h.mass.row_offsets[row];j<h.mass.row_offsets[row+1];++j)value+=static_cast<long double>(h.mass.values[j]/h.step)*previous[h.mass.column_indices[j]];
        rhs[row]=static_cast<double>(value);}
      auto solution=ProbeChecked(factor->FactorAndSolveRefined(a,rhs));maximum=std::max(maximum,ProbeChecked(ValidateSparseSolution(a,rhs,solution)));
      for(int row=0;row<n;++row){difference=std::max(difference,std::abs(solution[row]-h.truth[(point+1)*n+row]));if(row)std::cout << ' ';std::cout << solution[row];}
      std::cout << '\\n';previous=std::move(solution);
    }
    const auto stats=factor->statistics();std::cerr << "{\\"case\\":\\""<<h.sample.name<<"\\",\\"solves\\":"<<stats.solves<<",\\"factors\\":"<<stats.numeric_factorizations<<",\\"reuses\\":"<<stats.numeric_reuses<<",\\"refinements\\":"<<stats.iterative_refinement_solves<<"}\\n";
  }
  if(difference>2e-10)throw std::runtime_error("CPU time manufactured differential failure");
  std::cerr<<std::setprecision(17)<<"{\\"original_systems\\":4608,\\"maximum_componentwise\\":"<<maximum<<",\\"manufactured_difference\\":"<<difference<<"}\\n";return 0;
}
} // namespace
int main(int argc,char **argv){try {if(argc!=3)return 2;return Oracle(argv[1],argv[2]);}catch(const std::exception &e){std::cerr<<e.what()<<'\\n';return 1;}}
'''
(r/'cpp/benchmarks/emi03_time_cpu_probe.cc').write_text(code)
p=r/'cpp/BUILD.bazel';s=p.read_text()
if 'name = "emi03_time_cpu_probe"' not in s:
 s+='''
cc_binary(
    name = "emi03_time_cpu_probe",
    testonly = True,
    srcs = ["benchmarks/emi03_time_cpu_probe.cc"],
    tags = ["manual"],
    copts = OHMNIVORE_COPTS,
    deps = [":core"],
)
''';p.write_text(s)
