struct HostTime { ProbeSample sample; CsrMatrix mass; double step; std::vector<double> rhs,truth; };
std::vector<HostTime> ReadTime(const char *replay,const char *mass_path,std::vector<int> &active) {
  auto samples=ReadProbe(replay);std::ifstream in(mass_path);std::string magic;int count=0,n=0,rank=0;in>>magic>>count>>n>>rank;
  if(!in||magic!="EMI03_TIME_MASS_1"||count!=9||n!=185||rank<1||rank>64)throw std::runtime_error("invalid time replay dimensions");
  active.resize(rank);for(int &x:active)in>>x;
  if(!std::is_sorted(active.begin(),active.end())||std::adjacent_find(active.begin(),active.end())!=active.end()||active.front()<0||active.back()>=n)throw std::runtime_error("invalid time state selectors");
  std::vector<HostTime> cases(count);
  for(int job=0;job<count;++job){auto &h=cases[job];h.sample=samples[job*16+4];std::string name;int nnz=0;in>>name>>h.step>>nnz;
    if(!in||name!=h.sample.name||!std::isfinite(h.step)||h.step<=0||nnz<0||nnz>n*n)throw std::runtime_error("invalid time mass record");
    auto &c=h.mass;c.rows=c.columns=n;c.row_offsets.resize(n+1);c.column_indices.resize(nnz);c.values.resize(nnz);
    for(auto &x:c.row_offsets)in>>x;for(auto &x:c.column_indices)in>>x;for(auto &x:c.values)in>>x;
    if(!in)throw std::runtime_error("truncated time mass matrix");
    ProbeChecked(ValidateSparseSolution(c,std::vector<double>(n),std::vector<double>(n)));
    for(std::size_t j=0;j<c.values.size();++j)if(c.values[j]!=0&&!std::binary_search(active.begin(),active.end(),static_cast<int>(c.column_indices[j])))throw std::runtime_error("mass coupling omitted by selectors");
    h.truth.resize(513*n);h.rhs.resize(512*n);
    for(int point=0;point<=512;++point)for(int row=0;row<n;++row)h.truth[point*n+row]=.2*std::sin(.031*point+.047*row);
    for(int point=0;point<512;++point)for(int row=0;row<n;++row){long double value=0;
      for(auto j=h.sample.a.row_offsets[row];j<h.sample.a.row_offsets[row+1];++j)value+=static_cast<long double>(h.sample.a.values[j])*h.truth[(point+1)*n+h.sample.a.column_indices[j]];
      for(auto j=c.row_offsets[row];j<c.row_offsets[row+1];++j)value-=static_cast<long double>(c.values[j]/h.step)*h.truth[point*n+c.column_indices[j]];
      h.rhs[point*n+row]=static_cast<double>(value);}
  }
  std::string extra;if(in>>extra)throw std::runtime_error("time mass trailing data");return cases;
}
TimeData PrepareTimeData(const HostTime &h,const std::vector<int> &active,const Model &m,Allocations &allocation) {
  TimeData t{};t.length=512;t.rank=active.size();t.active=allocation.Upload(active);
  t.mass_rows=allocation.Upload(std::vector<int>(h.mass.row_offsets.begin(),h.mass.row_offsets.end()));t.mass_columns=allocation.Upload(std::vector<int>(h.mass.column_indices.begin(),h.mass.column_indices.end()));t.mass_values=allocation.Upload(h.mass.values);t.step=h.step;
  t.factor=allocation.Allocate<double>(m.factor_nonzeros);t.inverse=allocation.Allocate<double>(m.n);t.equil=allocation.Allocate<double>(m.n);t.inverse_equil=allocation.Allocate<double>(m.n);t.row_norm=allocation.Allocate<double>(m.n);
  t.transfer=allocation.Allocate<double>(m.n*t.rank);t.powers=allocation.Allocate<double>(9*t.rank*t.rank);
  t.rhs=allocation.Upload(h.rhs);t.initial=allocation.Upload(std::vector<double>(h.truth.begin(),h.truth.begin()+m.n));t.solution=allocation.Allocate<double>(512*m.n);t.residual=allocation.Allocate<double>(512*m.n);t.z=allocation.Allocate<double>(512*m.n);t.scan_a=allocation.Allocate<double>(512*t.rank);t.scan_b=allocation.Allocate<double>(512*t.rank);
  t.error=allocation.Upload(std::vector<int>(3));t.invalid=t.error+1;t.nonzero=t.error+2;return t;
}
void CheckTimeErrors(const std::vector<TimeData> &data,Allocations &allocation) {
  for(const auto &t:data){int error=0;allocation.Copy(&error,t.error,sizeof(int),cudaMemcpyDeviceToHost);if(error)throw std::runtime_error("time GPU failure "+std::to_string(error));}
}
void ClearTimeFlags(const std::vector<TimeData> &data,Allocations &allocation,bool errors) {
  for(const auto &t:data)CheckCuda(cudaMemsetAsync(errors?t.error:t.invalid,0,(errors?3:2)*sizeof(int),allocation.stream()),"time flag clear");
}
void TimePass(const Model *models,const Workspace *workspace,TimeData *device,int jobs,int rank,int length,std::size_t bytes,Allocations &allocation,bool correction) {
  TimeIndependent<<<jobs*length,Threads,bytes,allocation.stream()>>>(models,workspace,device,length,correction);CheckCuda(cudaGetLastError(),"time independent launch");
  bool input_a=true;
  for(int level=0;(1<<level)<length;++level){TimeScan<<<jobs*length,Threads,0,allocation.stream()>>>(device,length,level,input_a);CheckCuda(cudaGetLastError(),"time prefix launch");input_a=!input_a;}
  TimeRecover<<<jobs*length,Threads,0,allocation.stream()>>>(models,device,length,input_a,correction);CheckCuda(cudaGetLastError(),"time recovery launch");static_cast<void>(rank);
}
int SolveWindow(const Model *models,const Workspace *workspace,TimeData *device,const std::vector<TimeData> &data,int length,std::size_t bytes,Allocations &allocation) {
  ClearTimeFlags(data,allocation,true);TimePass(models,workspace,device,data.size(),data[0].rank,length,bytes,allocation,false);
  for(int refinement=0;refinement<=4;++refinement){ClearTimeFlags(data,allocation,false);
    TimeResidual<<<data.size()*length,Threads,0,allocation.stream()>>>(models,workspace,device,length);CheckCuda(cudaGetLastError(),"time residual launch");
    bool invalid=false,nonzero=false;
    for(const auto &t:data){int flags[3]{};allocation.Copy(flags,t.error,sizeof(flags),cudaMemcpyDeviceToHost);if(flags[0])throw std::runtime_error("time GPU residual failure "+std::to_string(flags[0]));invalid|=flags[1]!=0;nonzero|=flags[2]!=0;}
    if(!invalid&&(refinement>0||!nonzero))return refinement;
    if(refinement<4)TimePass(models,workspace,device,data.size(),data[0].rank,length,bytes,allocation,true);
  }
  throw std::runtime_error("time window refinement limit");
}
void CheckTimeResult(const std::vector<HostTime> &cases,const std::vector<TimeData> &data,Allocations &allocation,int length,const char *method) {
  double maximum=0,difference=0;std::size_t checked=0;
  for(std::size_t job=0;job<cases.size();++job){const auto &h=cases[job];const int n=h.sample.a.rows;std::vector<double> x(length*n);allocation.Copy(x.data(),data[job].solution,x.size()*sizeof(double),cudaMemcpyDeviceToHost);
    for(int point=0;point<length;++point){const double *previous=point?x.data()+(point-1)*n:h.truth.data();std::vector<double> rhs(n),solution(x.begin()+point*n,x.begin()+(point+1)*n);
      for(int row=0;row<n;++row){long double value=h.rhs[point*n+row];for(auto j=h.mass.row_offsets[row];j<h.mass.row_offsets[row+1];++j)value+=static_cast<long double>(h.mass.values[j]/h.step)*previous[h.mass.column_indices[j]];rhs[row]=static_cast<double>(value);difference=std::max(difference,std::abs(solution[row]-h.truth[(point+1)*n+row]));}
      maximum=std::max(maximum,ProbeChecked(ValidateSparseSolution(h.sample.a,rhs,solution)));++checked;}
  }
  if(difference>2e-10)throw std::runtime_error("time manufactured-state differential mismatch "+std::to_string(difference));
  std::cout<<"{\"kind\":\"time_validation\",\"method\":\""<<method<<"\",\"length\":"<<length<<",\"original_systems\":"<<checked<<",\"componentwise\":"<<maximum<<",\"manufactured_difference\":"<<difference<<"}\n";
}
int TimeProbe(const char *replay,const char *mass,bool validation_only) {
  std::vector<int> active;const auto cases=ReadTime(replay,mass,active);ProbeChecked(BeginEmi03CudaJob("time-window-probe"));
  {HostStaging staging;Allocations allocation(staging);std::vector<Model> models(cases.size());std::vector<Workspace> workspace(cases.size());std::vector<TimeData> data;std::size_t bytes=0;
    for(std::size_t i=0;i<cases.size();++i){bytes=std::max(bytes,ProbePrepare(cases[i].sample,allocation,models[i],workspace[i]));data.push_back(PrepareTimeData(cases[i],active,models[i],allocation));}
    auto *dm=allocation.Upload(models);auto *dw=allocation.Upload(workspace);auto *dt=allocation.Upload(data);
    for(auto kernel:{CacheTimeFactors,SequentialTime}){static_cast<void>(kernel);}
    CheckCuda(cudaFuncSetAttribute(CacheTimeFactors,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"time cache shared");
    CheckCuda(cudaFuncSetAttribute(MakeTimeTransfer,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"time transfer shared");
    CheckCuda(cudaFuncSetAttribute(TimeIndependent,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"time independent shared");
    CheckCuda(cudaFuncSetAttribute(SequentialTime,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"time sequential shared");
    CacheTimeFactors<<<cases.size(),Threads,bytes,allocation.stream()>>>(dm,dw,dt);CheckCuda(cudaGetLastError(),"time factors launch");CheckTimeErrors(data,allocation);
    MakeTimeTransfer<<<cases.size()*active.size(),Threads,bytes,allocation.stream()>>>(dm,dw,dt,active.size());CheckCuda(cudaGetLastError(),"time transfer launch");CheckTimeErrors(data,allocation);
    for(int level=0;level<9;++level){TimePower<<<dim3((active.size()*active.size()+Threads-1)/Threads,cases.size()),Threads,0,allocation.stream()>>>(dt,active.size(),level);CheckCuda(cudaGetLastError(),"time powers launch");}
    CheckTimeErrors(data,allocation);cudaEvent_t begin,end;CheckCuda(cudaEventCreate(&begin),"time event");CheckCuda(cudaEventCreate(&end),"time event");
    for(int length:{8,32,128,512})for(int repetition=-1;repetition<(validation_only?0:9);++repetition)for(int order=0;order<2;++order){const bool parallel=((repetition+1+order)%2)!=0;const char *method=parallel?"prefix":"sequential";ClearTimeFlags(data,allocation,true);CheckCuda(cudaEventRecord(begin,allocation.stream()),"time begin");int refinements=0;
      if(parallel)refinements=SolveWindow(dm,dw,dt,data,length,bytes,allocation);
      else {SequentialTime<<<cases.size(),Threads,bytes,allocation.stream()>>>(dm,dw,dt,length);CheckCuda(cudaGetLastError(),"time sequential launch");}
      CheckCuda(cudaEventRecord(end,allocation.stream()),"time end");CheckCuda(cudaEventSynchronize(end),"time completion");float ms=0;CheckCuda(cudaEventElapsedTime(&ms,begin,end),"time elapsed");CheckTimeErrors(data,allocation);CheckTimeResult(cases,data,allocation,length,method);
      std::cout<<"{\"kind\":\"time_timing\",\"method\":\""<<method<<"\",\"length\":"<<length<<",\"count\":"<<cases.size()<<",\"repetition\":"<<repetition<<",\"device_ms\":"<<ms<<",\"window_refinements\":"<<refinements<<"}\n";
    }
    CheckCuda(cudaEventDestroy(begin),"time event destroy");CheckCuda(cudaEventDestroy(end),"time event destroy");
  }
  const auto ended=ProbeChecked(EndEmi03CudaJob());if(ended.outstanding_device_bytes||ended.cleanup_failures)throw std::runtime_error("time cleanup failure");return 0;
}
} // namespace
} // namespace ohmnivore
int main(int argc,char **argv){try {if(argc<3||argc>4||(argc==4&&std::string(argv[3])!="--validate-only"))return 2;std::cout<<std::setprecision(17);return ohmnivore::TimeProbe(argv[1],argv[2],argc==4);}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}}
