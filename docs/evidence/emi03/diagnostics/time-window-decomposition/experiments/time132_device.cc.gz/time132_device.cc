struct TimeData {
  int length, rank;
  const int *active, *mass_rows, *mass_columns;
  const double *mass_values;
  double step;
  double *factor, *inverse, *equil, *inverse_equil, *row_norm;
  double *transfer, *powers, *rhs, *initial, *solution, *residual;
  double *z, *scan_a, *scan_b;
  int *error, *invalid, *nonzero;
};
// INITIALIZE_HELPER
// CACHED_LINEAR_HELPER
__device__ void LoadTimeFactor(const Model &m, Workspace &w, Shared &s, const TimeData &t) {
  for(int i=threadIdx.x;i<m.factor_nonzeros;i+=Threads)s.factor[i]=t.factor[i];
  for(int i=threadIdx.x;i<m.n;i+=Threads){s.inverse[i]=t.inverse[i];w.equil[i]=t.equil[i];w.inverse_equil[i]=t.inverse_equil[i];w.linear_row_norm[i]=t.row_norm[i];}
  if(threadIdx.x==0){s.sparse_factor=true;s.factor_valid=true;}
  __syncthreads();
}
__global__ void CacheTimeFactors(const Model *models,const Workspace *all,TimeData *data) {
  const int job=blockIdx.x;const auto m=models[job];const auto t=data[job];
  __shared__ Shared s;extern __shared__ double time_storage[];
  InitializeTime(m,all+job,s,time_storage);auto &w=s.runtime;
  for(int i=threadIdx.x;i<m.nnz;i+=Threads)w.jacobian[i]=all[job].jacobian[i];
  __syncthreads();Factor(m,w,s);
  if(threadIdx.x==0&&(!s.sparse_factor||s.error))atomicCAS(t.error,0,s.error?s.error:Invalid);
  if(s.error||!s.sparse_factor)return;
  for(int i=threadIdx.x;i<m.factor_nonzeros;i+=Threads)t.factor[i]=s.factor[i];
  for(int i=threadIdx.x;i<m.n;i+=Threads){t.inverse[i]=s.inverse[i];t.equil[i]=w.equil[i];t.inverse_equil[i]=w.inverse_equil[i];t.row_norm[i]=w.linear_row_norm[i];}
}
__global__ void MakeTimeTransfer(const Model *models,const Workspace *all,TimeData *data,int rank) {
  const int job=blockIdx.x/rank,col=blockIdx.x%rank;const auto m=models[job];const auto t=data[job];
  __shared__ Shared s;extern __shared__ double time_storage[];
  InitializeTime(m,all+job,s,time_storage);auto &w=s.runtime;LoadTimeFactor(m,w,s,t);
  for(int i=threadIdx.x;i<m.nnz;i+=Threads)w.jacobian[i]=all[job].jacobian[i];
  for(int row=threadIdx.x;row<m.n;row+=Threads){double value=0;for(int j=t.mass_rows[row];j<t.mass_rows[row+1];++j)if(t.mass_columns[j]==t.active[col])value=t.mass_values[j]/t.step;w.affine_rhs[row]=value;}
  __syncthreads();CachedTimeLinear(m,w,s);
  if(threadIdx.x==0&&s.error)atomicCAS(t.error,0,s.error);
  for(int row=threadIdx.x;row<m.n&&!s.error;row+=Threads)t.transfer[row*rank+col]=w.solution[row];
}
__global__ void TimePower(TimeData *data,int rank,int level) {
  const int job=blockIdx.y,index=blockIdx.x*blockDim.x+threadIdx.x;auto t=data[job];if(index>=rank*rank)return;
  if(level==0){t.powers[index]=t.transfer[t.active[index/rank]*rank+index%rank];return;}
  const double *before=t.powers+(level-1)*rank*rank;double value=0;
  for(int k=0;k<rank;++k)value=fma(before[(index/rank)*rank+k],before[k*rank+index%rank],value);
  if(!Bounded(value))atomicCAS(t.error,0,Nonfinite);t.powers[level*rank*rank+index]=value;
}
__global__ void TimeIndependent(const Model *models,const Workspace *all,TimeData *data,int length,bool correction) {
  const int job=blockIdx.x/length,point=blockIdx.x%length;const auto m=models[job];const auto t=data[job];
  __shared__ Shared s;extern __shared__ double time_storage[];
  InitializeTime(m,all+job,s,time_storage);auto &w=s.runtime;LoadTimeFactor(m,w,s,t);
  for(int i=threadIdx.x;i<m.nnz;i+=Threads)w.jacobian[i]=all[job].jacobian[i];
  const double *rhs=(correction?t.residual:t.rhs)+point*m.n;
  for(int row=threadIdx.x;row<m.n;row+=Threads)w.affine_rhs[row]=rhs[row];
  __syncthreads();CachedTimeLinear(m,w,s);
  if(threadIdx.x==0&&s.error)atomicCAS(t.error,0,s.error);
  if(!s.error){
    for(int row=threadIdx.x;row<m.n;row+=Threads)t.z[point*m.n+row]=w.solution[row];
    for(int row=threadIdx.x;row<t.rank;row+=Threads){double value=w.solution[t.active[row]];
      if(point==0&&!correction)for(int col=0;col<t.rank;++col)value=fma(t.powers[row*t.rank+col],t.initial[t.active[col]],value);
      t.scan_a[point*t.rank+row]=value;}
  }
}
__global__ void TimeScan(TimeData *data,int length,int level,bool input_a) {
  const int job=blockIdx.x/length,point=blockIdx.x%length;const auto t=data[job];const int stride=1<<level;
  const double *input=input_a?t.scan_a:t.scan_b;double *output=input_a?t.scan_b:t.scan_a;
  __shared__ double before[64];
  if(threadIdx.x<t.rank)before[threadIdx.x]=point>=stride?input[(point-stride)*t.rank+threadIdx.x]:0;
  __syncthreads();
  for(int row=threadIdx.x;row<t.rank;row+=blockDim.x){double value=input[point*t.rank+row];
    if(point>=stride)for(int col=0;col<t.rank;++col)value=fma(t.powers[(level*t.rank+row)*t.rank+col],before[col],value);
    output[point*t.rank+row]=value;if(!Bounded(value))atomicCAS(t.error,0,Nonfinite);}
}
__global__ void TimeRecover(const Model *models,TimeData *data,int length,bool input_a,bool correction) {
  const int job=blockIdx.x/length,point=blockIdx.x%length;const auto t=data[job];const int n=models[job].n;
  const double *boundary=input_a?t.scan_a:t.scan_b;__shared__ double before[64];
  if(threadIdx.x<t.rank)before[threadIdx.x]=point>0?boundary[(point-1)*t.rank+threadIdx.x]:(correction?0:t.initial[t.active[threadIdx.x]]);
  __syncthreads();
  for(int row=threadIdx.x;row<n;row+=blockDim.x){double value=t.z[point*n+row];
    for(int col=0;col<t.rank;++col)value=fma(t.transfer[row*t.rank+col],before[col],value);
    if(correction)value+=t.solution[point*n+row];
    t.solution[point*n+row]=value;if(!Bounded(value))atomicCAS(t.error,0,Nonfinite);}
}
__global__ void TimeResidual(const Model *models,const Workspace *all,TimeData *data,int length) {
  const int job=blockIdx.x/length,point=blockIdx.x%length;const auto m=models[job];const auto t=data[job];
  __shared__ Shared s;if(threadIdx.x==0)s.error=0;__syncthreads();
  const double *previous=point?t.solution+(point-1)*m.n:t.initial,*x=t.solution+point*m.n,*a=all[job].jacobian;
  double component=0,normalized=0,matrix_norm=0,rhs_norm=0,solution_norm=0,nonzero=0;
  for(int row=threadIdx.x;row<m.n;row+=Threads){Sum rhs;rhs.Add(t.rhs[point*m.n+row]);
    for(int j=t.mass_rows[row];j<t.mass_rows[row+1];++j)rhs.Product(t.mass_values[j]/t.step,previous[t.mass_columns[j]]);
    const double effective=rhs.Value();Sum residual;residual.Add(effective);double denominator=fabs(effective);
    for(int j=m.row_offsets[row];j<m.row_offsets[row+1];++j){residual.Product(-a[j],x[m.columns[j]]);denominator+=fabs(a[j]*x[m.columns[j]]);}
    const double value=residual.Value();t.residual[point*m.n+row]=value;
    if(!Bounded(value)||!Bounded(effective)||!Bounded(x[row]))Reject(s,Nonfinite);
    nonzero=PositiveMaximum(nonzero,value!=0?1.:0.);component=PositiveMaximum(component,denominator==0?(value==0?0:1e100):fabs(value)/denominator);
    normalized=PositiveMaximum(normalized,fabs(value)/t.equil[row]);matrix_norm=PositiveMaximum(matrix_norm,t.row_norm[row]);rhs_norm=PositiveMaximum(rhs_norm,fabs(effective)/t.equil[row]);solution_norm=PositiveMaximum(solution_norm,fabs(x[row]));}
  double maxima[]{component,normalized,matrix_norm,rhs_norm,solution_norm,nonzero};ValidationMaxima(maxima,s);
  if(threadIdx.x==0){const double denominator=maxima[2]*maxima[4]+maxima[3];
    if(s.error)atomicCAS(t.error,0,s.error);
    if(maxima[0]>1e-5||(denominator==0?maxima[1]!=0:maxima[1]/denominator>1e-10))atomicExch(t.invalid,1);
    if(maxima[5]!=0)atomicExch(t.nonzero,1);}
}
__global__ void SequentialTime(const Model *models,const Workspace *all,TimeData *data,int length) {
  const int job=blockIdx.x;const auto m=models[job];const auto t=data[job];
  __shared__ Shared s;extern __shared__ double time_storage[];
  InitializeTime(m,all+job,s,time_storage);auto &w=s.runtime;LoadTimeFactor(m,w,s,t);
  for(int i=threadIdx.x;i<m.nnz;i+=Threads)w.jacobian[i]=all[job].jacobian[i];
  for(int row=threadIdx.x;row<m.n;row+=Threads)w.current[row]=t.initial[row];
  __syncthreads();
  for(int point=0;point<length&&!s.error;++point){
    for(int row=threadIdx.x;row<m.n;row+=Threads){Sum rhs;rhs.Add(t.rhs[point*m.n+row]);
      for(int j=t.mass_rows[row];j<t.mass_rows[row+1];++j)rhs.Product(t.mass_values[j]/t.step,w.current[t.mass_columns[j]]);
      w.affine_rhs[row]=rhs.Value();}
    __syncthreads();CachedTimeLinear(m,w,s);
    for(int row=threadIdx.x;row<m.n&&!s.error;row+=Threads){t.solution[point*m.n+row]=w.solution[row];w.current[row]=w.solution[row];}
    __syncthreads();}
  if(threadIdx.x==0&&s.error)atomicCAS(t.error,0,s.error);
}
