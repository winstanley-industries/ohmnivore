struct WindowInput {MnaSystem system;std::vector<double> initial,oracle;double time,step;int length;};
WindowInput ReadNonlinearWindow(const char *deck,const char *fixture,int length) {
 WindowInput h{};std::ifstream d(deck);if(!d)throw std::runtime_error("missing nonlinear deck");const std::string text{std::istreambuf_iterator<char>(d),{}};h.system=ProbeChecked(CompileBehavioralMna(ProbeChecked(ParseBehavioralNetlist(text))));
 std::ifstream in(fixture);std::string magic;int n=0,available=0;in>>magic>>n>>available>>h.time>>h.step;
 if(!in||magic!="EMI03_NONLINEAR_TIME_1"||n!=static_cast<int>(h.system.g.rows)||n!=185||available!=512||length<1||length>available||!std::isfinite(h.time)||!std::isfinite(h.step)||h.step<=0)throw std::runtime_error("invalid nonlinear time fixture");
 h.length=length;h.initial.resize(n);h.oracle.resize(available*n);for(auto *v:{&h.initial,&h.oracle})for(double &x:*v){in>>x;if(!in||!std::isfinite(x))throw std::runtime_error("invalid nonlinear oracle state");}
 std::string extra;if(in>>extra)throw std::runtime_error("nonlinear fixture trailing data");return h;
}
std::size_t PrepareNonlinearWindow(const WindowInput &h,Allocations &allocation,Model &m,Workspace &w) {
 TransientExecutionLimits limits;limits.retain_output_states=false;limits.behavioral_error_estimator=BehavioralErrorEstimator::kDerivativeHistory;limits.accepted_state_observer=[](double,const std::vector<double>&){return Result<bool>::Ok(true);};limits.nonlinear_maximum_iterations=100;
 TranAnalysis analysis{h.step,h.time+512*h.step,0,false};m=Prepare(h.system,analysis,limits,allocation,w);
 auto working=h.system;working.g=ProbeChecked(FormTransientCompanionMatrix(h.system.g,h.system.c,h.step,1));ProbeChecked(RemapBehavioralDescriptors(&working));
 auto linear=ProbeChecked(BuildNonlinearDcLinearization(working,h.initial));auto factor_system=working;factor_system.g=linear.jacobian;PrepareFactorPlan(factor_system,analysis,h.initial,m,allocation);
 w.jacobian=allocation.Allocate<double>(m.nnz);allocation.Copy(w.state,h.initial.data(),m.n*sizeof(double),cudaMemcpyHostToDevice);
 std::size_t bytes=((m.factor_nonzeros+17*m.n+3*m.reactive+2*m.nnz+m.dependency_count+2*m.expression_node_count)*sizeof(double)+m.programs*sizeof(DeviceResult)+m.expression_node_count+7)/8*8+(2*m.factor_nonzeros+m.factor_levels+1)*sizeof(int);bytes=(bytes+7)/8*8;
 // Keep complete expression and structure metadata in the original immutable device arrays.
 m.shared_factor_metadata=false;m.shared_expression_metadata=false;m.shared_structure=false;
 return bytes;
}
void CheckNonlinearOracle(const WindowInput &h,const NonlinearWindow &window,Allocations &allocation) {
 const int n=h.system.g.rows;std::vector<double>x(h.length*n);allocation.Copy(x.data(),window.candidate,x.size()*sizeof(double),cudaMemcpyDeviceToHost);
 auto working=h.system;working.g=ProbeChecked(FormTransientCompanionMatrix(h.system.g,h.system.c,h.step,1));ProbeChecked(RemapBehavioralDescriptors(&working));
 auto factor=ProbeChecked(SparseRealFactorization::Analyze(working.g));double maximum_residual=0,maximum_difference=0;std::vector<double> previous=h.initial;
 for(int point=0;point<h.length;++point){std::vector<double> state(x.begin()+point*n,x.begin()+(point+1)*n);auto source=ProbeChecked(BuildTransientRhs(h.system,h.time+(point+1)*h.step));working.b_dc=ProbeChecked(BuildBackwardEulerRhs(h.system.c,previous,source,h.step));maximum_residual=std::max(maximum_residual,ProbeChecked(ValidateNonlinearResidual(working,state)));auto jac=ProbeChecked(BuildNonlinearDcLinearization(working,state));ProbeChecked(factor->FactorAndSolveRefined(jac.jacobian,std::vector<double>(n)));
  for(int row=0;row<n;++row){double reference=h.oracle[point*n+row];double absolute=row<static_cast<int>(h.system.node_names.size())?1e-7:1e-9;maximum_difference=std::max(maximum_difference,std::abs(state[row]-reference)/(absolute+1e-5*std::max(std::abs(state[row]),std::abs(reference))));}previous=std::move(state);
 }
 if(maximum_residual>1||maximum_difference>1)throw std::runtime_error("nonlinear window CPU differential failure");
 std::cout<<"{\"kind\":\"nonlinear_validation\",\"length\":"<<h.length<<",\"original_systems\":"<<h.length<<",\"maximum_nonlinear_residual\":"<<maximum_residual<<",\"maximum_scaled_cpu_difference\":"<<maximum_difference<<",\"actual_jacobian_rank_checks\":"<<h.length<<"}\n";
}
int NonlinearTimeProbe(const char *deck,const char *fixture,int length){
 auto h=ReadNonlinearWindow(deck,fixture,length);ProbeChecked(BeginEmi03CudaJob("nonlinear-time-window-probe"));bool converged=false;
 {
  HostStaging staging;Allocations allocation(staging);Model m{};Workspace w{};const auto bytes=PrepareNonlinearWindow(h,allocation,m,w);
  HostTime host{};host.sample.a.rows=m.n;host.mass=h.system.c;host.step=h.step;host.truth=h.initial;host.rhs.resize(512*m.n);
  std::vector<int> active;for(std::size_t j=0;j<host.mass.values.size();++j)if(host.mass.values[j]!=0)active.push_back(host.mass.column_indices[j]);std::sort(active.begin(),active.end());active.erase(std::unique(active.begin(),active.end()),active.end());
  int *flags=allocation.Upload(std::vector<int>(3));std::vector<TimeData> data{PrepareTimeData(host,active,m,allocation,flags)};auto *dm=allocation.Upload(std::vector<Model>{m});auto *dw=allocation.Upload(std::vector<Workspace>{w});auto *dt=allocation.Upload(data);
  NonlinearWindow window{};window.time=h.time;window.length=length;window.current=allocation.Allocate<double>(length*m.n);window.candidate=allocation.Allocate<double>(length*m.n);window.metrics=allocation.Allocate<double>(2*length);window.error=allocation.Upload(std::vector<int>(1));window.lu=allocation.Allocate<double>(length*m.n*N);window.permutations=allocation.Allocate<int>(length*m.n);
  for(const auto kernel:{NonlinearWindowInitialJacobian})CheckCuda(cudaFuncSetAttribute(kernel,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"window initial shared");
  CheckCuda(cudaFuncSetAttribute(NonlinearWindowAffine,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"window affine shared");CheckCuda(cudaFuncSetAttribute(NonlinearWindowCheck,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"window check shared");CheckCuda(cudaFuncSetAttribute(CacheTimeFactors,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"window factor shared");CheckCuda(cudaFuncSetAttribute(MakeTimeTransfer,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"window transfer shared");
  NonlinearWindowInitialJacobian<<<1,Threads,bytes,allocation.stream()>>>(dm,dw,dt);CheckCuda(cudaGetLastError(),"window initial Jacobian");CheckTimeErrors("window initial Jacobian",data,allocation);
  CacheTimeFactors<<<1,Threads,bytes,allocation.stream()>>>(dm,dw,dt);CheckCuda(cudaGetLastError(),"window factors");CheckTimeErrors("window factors",data,allocation);
  MakeTimeTransfer<<<active.size(),Threads,bytes,allocation.stream()>>>(dm,dw,dt,active.size());CheckCuda(cudaGetLastError(),"window transfer");CheckTimeErrors("window transfer",data,allocation);
  for(int level=0;level<9;++level){TimePower<<<dim3((active.size()*active.size()+Threads-1)/Threads,1),Threads,0,allocation.stream()>>>(dt,active.size(),level);CheckCuda(cudaGetLastError(),"window powers");}CheckTimeErrors("window powers",data,allocation);
  NonlinearWindowSeed<<<(length*m.n+Threads-1)/Threads,Threads,0,allocation.stream()>>>(dm,dt,window);CheckCuda(cudaGetLastError(),"window seed");
  const auto start=std::chrono::steady_clock::now();double old_residual=std::numeric_limits<double>::infinity();int accepted_iterations=0;
  for(int iteration=0;iteration<100;++iteration){
   NonlinearWindowAffine<<<length,Threads,bytes,allocation.stream()>>>(dm,dw,dt,window);CheckCuda(cudaGetLastError(),"window affine");CheckTimeErrors("window affine",data,allocation);
   int refinements=SolveWindow(dm,dw,dt,data,length,bytes,allocation);bool accepted=false;double residual=0,update=0;int backtrack=0;
   for(;backtrack<=16;++backtrack){CheckCuda(cudaMemsetAsync(window.error,0,sizeof(int),allocation.stream()),"window trial error clear");NonlinearWindowBlend<<<(length*m.n+Threads-1)/Threads,Threads,0,allocation.stream()>>>(dm,dt,window,std::ldexp(1.,-backtrack));CheckCuda(cudaGetLastError(),"window blend");NonlinearWindowCheck<<<length,Threads,bytes,allocation.stream()>>>(dm,dw,dt,window,false);CheckCuda(cudaGetLastError(),"window check");int error=0;allocation.Copy(&error,window.error,sizeof(int),cudaMemcpyDeviceToHost);if(error){if(error!=Nonfinite)throw std::runtime_error("nonlinear trial failure "+std::to_string(error));continue;}
    std::vector<double> metrics(2*length);allocation.Copy(metrics.data(),window.metrics,metrics.size()*sizeof(double),cudaMemcpyDeviceToHost);residual=update=0;for(int k=0;k<length;++k){residual=std::max(residual,metrics[2*k]);update=std::max(update,metrics[2*k+1]);}if(residual<old_residual||residual<=1){accepted=true;break;}
   }
   std::cout<<"{\"kind\":\"nonlinear_iteration\",\"iteration\":"<<iteration<<",\"backtracks\":"<<backtrack<<",\"residual\":"<<residual<<",\"update\":"<<update<<",\"linear_refinements\":"<<refinements<<"}\n";
   if(!accepted)break;++accepted_iterations;
   if(residual<=1&&update<=1){NonlinearWindowCheck<<<length,Threads,bytes,allocation.stream()>>>(dm,dw,dt,window,true);CheckCuda(cudaGetLastError(),"window final certification");int error=0;allocation.Copy(&error,window.error,sizeof(int),cudaMemcpyDeviceToHost);if(error)throw std::runtime_error("nonlinear final certification failure "+std::to_string(error));converged=true;break;}
   CheckCuda(cudaMemcpyAsync(window.current,window.candidate,length*m.n*sizeof(double),cudaMemcpyDeviceToDevice,allocation.stream()),"window accepted iteration");old_residual=residual;
  }
  const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout<<"{\"kind\":\"nonlinear_window\",\"length\":"<<length<<",\"converged\":"<<(converged?"true":"false")<<",\"iterations\":"<<accepted_iterations<<",\"solve_wall_s\":"<<seconds<<"}\n";
  if(converged)CheckNonlinearOracle(h,window,allocation);
 }
 const auto ended=ProbeChecked(EndEmi03CudaJob());if(ended.outstanding_device_bytes||ended.cleanup_failures)throw std::runtime_error("nonlinear window cleanup failure");return converged?0:3;
}
