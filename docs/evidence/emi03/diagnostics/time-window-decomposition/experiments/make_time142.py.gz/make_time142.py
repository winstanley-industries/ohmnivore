from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'time139b.cu').read_text()
a=s.index('int NonlinearTimeProbe(');s=s[:a]+(w/'time142-simple.cuh').read_text()+'\n'+s[a:]
s=s.replace('bool graph_mode, bool comparison)', 'bool graph_mode, bool comparison, bool simple_mode)')
s=s.replace('auto result = graph.Run(dm, dw, dt, window, bytes, allocation, comparison, h);','auto result = simple_mode?CompareSimpleWindow(dm,dw,dt,window,bytes,allocation,data,h,comparison):graph.Run(dm, dw, dt, window, bytes, allocation, comparison, h);')
# inspect formatting-independent span if the call wrapped
if 'simple_mode?CompareSimpleWindow' not in s:
 s=s.replace('auto result =\n          graph.Run(dm, dw, dt, window, bytes, allocation, comparison, h);','auto result = simple_mode?CompareSimpleWindow(dm,dw,dt,window,bytes,allocation,data,h,comparison):graph.Run(dm, dw, dt, window, bytes, allocation, comparison, h);')
assert 'simple_mode?CompareSimpleWindow' in s
s=s.replace('std::string(argv[4]) != "--compare"', 'std::string(argv[4]) != "--compare" && std::string(argv[4]) != "--simple" && std::string(argv[4]) != "--simple-compare"')
s=s.replace('argc == 5 && std::string(argv[4]) == "--compare");', 'argc == 5 && (std::string(argv[4]) == "--compare" || std::string(argv[4]) == "--simple-compare"),argc==5&&(std::string(argv[4])=="--simple"||std::string(argv[4])=="--simple-compare"));')
assert 'bool graph_mode, bool comparison, bool simple_mode)' in s
(r/'cuda/emi03_time_nonlinear_probe.cu').write_text(s)
