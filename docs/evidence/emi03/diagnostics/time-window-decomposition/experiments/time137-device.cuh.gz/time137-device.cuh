struct NonlinearWindow {
 double *current,*candidate,*metrics,*lu;
 int *permutations,*error;
 double time;
 int length;
};
__global__ void NonlinearWindowSeed(const Model *models,const TimeData *data,NonlinearWindow window) {
 int at=blockIdx.x*blockDim.x+threadIdx.x,n=models[0].n;
 if(at<n*window.length)window.current[at]=data[0].initial[at%n];
}
__global__ void NonlinearWindowInitialJacobian(const Model *models,Workspace *all,const TimeData *data) {
 const auto m=models[0];const auto t=data[0];__shared__ Shared s;extern __shared__ double storage[];
 InitializeTime(m,all,s,storage);auto &w=s.runtime;
 for(int row=threadIdx.x;row<m.n;row+=Threads){w.companion_rhs[row]=0;for(int j=m.row_offsets[row];j<m.row_offsets[row+1];++j)w.base[j]=m.g[j]+m.c[j]/t.step;}
 __syncthreads();Assemble(m,w,s,t.initial,true,true);
 for(int j=threadIdx.x;j<m.nnz;j+=Threads)all[0].jacobian[j]=w.jacobian[j];
 if(threadIdx.x==0&&s.error)atomicCAS(t.error,0,s.error);
}
__global__ void NonlinearWindowAffine(const Model *models,const Workspace *all,TimeData *data,NonlinearWindow window) {
 const int point=blockIdx.x;const auto m=models[0];const auto t=data[0];const double *x=window.current+point*m.n;
 __shared__ Shared s;extern __shared__ double storage[];InitializeTime(m,all,s,storage);auto &w=s.runtime;
 Expressions(m,w,s,x,false,true);
 for(int row=threadIdx.x;row<m.n;row+=Threads){
  Sum affine;affine.Add(Rhs(m,row,window.time+(point+1)*t.step));
  for(int j=m.row_offsets[row];j<m.row_offsets[row+1];++j){affine.Product(all[0].jacobian[j]-m.g[j]-m.c[j]/t.step,x[m.columns[j]]);}
  for(int j=m.expression_offsets[row];j<m.expression_offsets[row+1];++j){auto stamp=m.expression_stamps[j];affine.Product(-stamp.coefficient,w.expressions[stamp.program].value);}
  t.rhs[point*m.n+row]=affine.Value();if(!Bounded(affine.Value()))Reject(s,Nonfinite);
 }
 if(threadIdx.x==0&&s.error)atomicCAS(t.error,0,s.error);
}
__global__ void NonlinearWindowBlend(const Model *models,const TimeData *data,NonlinearWindow window,double scale) {
 int at=blockIdx.x*blockDim.x+threadIdx.x,n=models[0].n;
 if(at<n*window.length)window.candidate[at]=window.current[at]+scale*(data[0].solution[at]-window.current[at]);
}
__global__ void NonlinearWindowCheck(const Model *models,const Workspace *all,const TimeData *data,NonlinearWindow window,bool certify) {
 const int point=blockIdx.x;const auto m=models[0];const auto t=data[0];
 Workspace isolated=all[0];isolated.lu=window.lu+point*m.n*N;isolated.permutation=window.permutations+point*m.n;
 __shared__ Shared s;extern __shared__ double storage[];InitializeTime(m,&isolated,s,storage);auto &w=s.runtime;
 const double *x=window.candidate+point*m.n,*old=window.current+point*m.n,*before=point?window.candidate+(point-1)*m.n:t.initial;
 for(int row=threadIdx.x;row<m.n;row+=Threads){
  w.current[row]=old[row];w.proposed[row]=x[row];Sum effective;effective.Add(Rhs(m,row,window.time+(point+1)*t.step));
  for(int j=m.row_offsets[row];j<m.row_offsets[row+1];++j){w.base[j]=m.g[j]+m.c[j]/t.step;effective.Product(m.c[j]/t.step,before[m.columns[j]]);}
  w.companion_rhs[row]=effective.Value();if(!Bounded(x[row])||!Bounded(w.companion_rhs[row]))Reject(s,Nonfinite);
 }
 __syncthreads();Assemble(m,w,s,x,certify,true);
 const double residual=ResidualNorm(m,w,s),update=UpdateNorm(m,w,s);
 if(certify&&!s.error){if(threadIdx.x==0)s.active_scale=1/t.step;Factor(m,w,s);}
 if(threadIdx.x==0){window.metrics[2*point]=residual;window.metrics[2*point+1]=update;if(s.error)atomicCAS(window.error,0,s.error);if(certify&&(residual>1||update>1))atomicCAS(window.error,0,Invalid);}
}
