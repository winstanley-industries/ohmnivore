from pathlib import Path
import subprocess,time,json,os,hashlib
w=Path('/home/adam/emi03-work');root=w/'time-nonlinear137c';root.mkdir(exist_ok=True);results=[]
for folder in sorted((w/'schur-snapshots107').glob('*-*')):
 if not folder.is_dir():continue
 for length in [8,32,128,512]:
  command=[str(w/'time137c-binary'),str(folder/'input.cir'),str(w/'time-nonlinear135'/(folder.name+'.fixture.txt')),str(length)]
  start=time.monotonic();out=root/f'{folder.name}-L{length}.jsonl';err=root/f'{folder.name}-L{length}.err'
  with out.open('w') as stdout,err.open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,TMPDIR=str(w/'tmp')))
  records=[json.loads(line) for line in out.read_text().splitlines()]
  result={'case':folder.name,'length':length,'returncode':r.returncode,'wall_s':time.monotonic()-start,'command':command,'deck_sha256':hashlib.sha256((folder/'input.cir').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(Path(command[2]).read_bytes()).hexdigest(),'terminal':records[-1] if records else None,'error':err.read_text()};results.append(result);print(json.dumps(result),flush=True)
  (root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
