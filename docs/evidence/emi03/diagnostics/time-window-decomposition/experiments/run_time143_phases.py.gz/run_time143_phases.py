from pathlib import Path
import subprocess,json,time,os
w=Path('/home/adam/emi03-work');root=w/'time-phases143';root.mkdir(exist_ok=True);records=[];env=dict(os.environ,TMPDIR=str(w/'tmp'))
for fixture in sorted((w/'time-phases140').glob('*.fixture.txt')):
 for length in [8,32,128,512]:
  mode='--simple-compare' if length==128 else '--simple';cmd=[str(w/'time143-binary'),str(w/'schur-snapshots107/reference-nominal/input.cir'),str(fixture),str(length),mode];name=fixture.name.removesuffix('.fixture.txt');out=root/f'{name}-L{length}.jsonl';err=root/f'{name}-L{length}.err';start=time.monotonic()
  with out.open('w') as stdout,err.open('w') as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=env)
  record={'case':name,'length':length,'mode':mode,'command':cmd,'returncode':r.returncode,'wall_s':time.monotonic()-start,'error':err.read_text()};records.append(record);print(json.dumps(record),flush=True);(root/'results.json').write_text(json.dumps(records,indent=2)+'\n')
