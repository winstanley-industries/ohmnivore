from pathlib import Path
import json,subprocess,os,hashlib,time
w=Path('/home/adam/emi03-work');root=w/'time-phases140';root.mkdir(exist_ok=True);folder=w/'schur-snapshots107/reference-nominal';records=[]
for index in [0,1,3,4,5,6,7]:
 m=json.loads((folder/'matrices.jsonl').read_text().splitlines()[2*index]);name=f'reference-nominal-s{index}';initial=root/(name+'.initial');initial.write_text(f"{m['n']} {m['time_s']:.17g} {m['step_s']:.17g}\n"+' '.join(format(x,'.17g') for x in m['state'])+'\n');out=root/(name+'.fixture.json');err=root/(name+'.fixture.err');cmd=[str(w/'time135-cpu-binary'),str(folder/'input.cir'),str(initial),'512']
 with out.open('w') as stdout,err.open('w') as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=dict(os.environ,TMPDIR=str(w/'tmp')))
 record={'sample':index,'time_s':m['time_s'],'step_s':m['step_s'],'command':cmd,'returncode':r.returncode,'error':err.read_text()};records.append(record);print(json.dumps(record),flush=True)
 if r.returncode==0:
  d=json.loads(out.read_text());out.with_suffix('.txt').write_text(f"EMI03_NONLINEAR_TIME_1 {d['n']} {d['length']} {d['t0']:.17g} {d['h']:.17g}\n"+' '.join(format(x,'.17g') for x in d['initial'])+'\n'+'\n'.join(' '.join(format(x,'.17g') for x in row) for row in d['oracle'])+'\n')
 (root/'generation.json').write_text(json.dumps(records,indent=2)+'\n')
