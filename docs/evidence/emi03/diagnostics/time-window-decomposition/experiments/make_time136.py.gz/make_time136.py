from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'time134.cu').read_text()
s=s.replace('double *transfer_certificate;', 'double *transfer_certificate;\n  unsigned long long *counters;')
a=s.index('__global__ void TimeScan(');s=s[:a]+(w/'time136-warp.cuh').read_text()+'\n'+s[a:]
s=s.replace('TimeIndependent<<<jobs * length, Threads, bytes, allocation.stream()>>>(', 'TimeWarpIndependent<<<jobs * ((length+7)/8), Threads, 8*3*185*sizeof(double), allocation.stream()>>>(')
s=s.replace('static_cast<void>(rank);','static_cast<void>(rank);\n  static_cast<void>(bytes);')
s=s.replace('t.transfer_certificate = allocation.Allocate<double>(2 * t.rank);','t.transfer_certificate = allocation.Allocate<double>(2 * t.rank);\n  t.counters=allocation.Upload(std::vector<unsigned long long>(3));')
s=s.replace('CheckCuda(cudaEventRecord(begin, allocation.stream()), "time begin");','for(const auto &t:data)CheckCuda(cudaMemsetAsync(t.counters,0,3*sizeof(unsigned long long),allocation.stream()),"time counter clear");\n          CheckCuda(cudaEventRecord(begin, allocation.stream()), "time begin");')
s=s.replace('CheckTimeResult(cases, data, allocation, length, method);','''CheckTimeResult(cases, data, allocation, length, method);
          unsigned long long totals[3]{};
          for(const auto &t:data){unsigned long long counts[3]{};allocation.Copy(counts,t.counters,sizeof(counts),cudaMemcpyDeviceToHost);for(int j=0;j<3;++j)totals[j]+=counts[j];}
          std::cout<<"{\\"kind\\":\\"warp_counts\\",\\"method\\":\\""<<method<<"\\",\\"length\\":"<<length<<",\\"solves\\":"<<totals[0]<<",\\"refinements\\":"<<totals[1]<<",\\"dense_retries\\":"<<totals[2]<<"}\\n";
''')
(r/'cuda/emi03_time_matrix_probe.cu').write_text(s)
