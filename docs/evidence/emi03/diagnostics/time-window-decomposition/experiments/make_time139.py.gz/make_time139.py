from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'time138.cu').read_text()
a=s.index('struct WindowGraphState');s=s[:a]+(w/'time139-sequential.cuh').read_text()+'\n'+s[a:]
s=s.replace('Allocations &allocation) {\n    auto *state = allocation.Allocate<WindowGraphState>(1);', 'Allocations &allocation, bool comparison, const WindowInput &input) {\n    auto *state = allocation.Allocate<WindowGraphState>(1);')
a=s.index('    const auto start = std::chrono::steady_clock::now();',s.index('class WindowGraph'));b=s.index('    return result;',a)
s=s[:a]+'''    WindowGraphState result{};
    CheckCuda(cudaFuncSetAttribute(SequentialNonlinearWindow,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"sequential window shared");
    for(int repetition=-1;repetition<(comparison?9:0);++repetition)for(int order=0;order<(comparison?2:1);++order){
      const bool graph_method=!comparison || ((repetition+1+order)%2==0);
      CheckCuda(cudaMemsetAsync(window.error,0,sizeof(int),allocation.stream()),"sequential error clear");
      const auto start=std::chrono::steady_clock::now();
      if(graph_method){CheckCuda(cudaGraphLaunch(executable,allocation.stream()),"window graph launch");allocation.Copy(&result,state,sizeof(result),cudaMemcpyDeviceToHost);}
      else{SequentialNonlinearWindow<<<1,Threads,bytes,allocation.stream()>>>(models,workspace,data,window);CheckCuda(cudaGetLastError(),"sequential nonlinear launch");int error=0;allocation.Copy(&error,window.error,sizeof(int),cudaMemcpyDeviceToHost);if(error)throw std::runtime_error("sequential nonlinear failure "+std::to_string(error));}
      const double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
      std::cout<<"{\\"kind\\":\\"graph_comparison\\",\\"method\\":\\""<<(graph_method?"graph":"sequential")<<"\\",\\"repetition\\":"<<repetition<<",\\"length\\":"<<length<<",\\"wall_s\\":"<<elapsed<<",\\"iterations\\":"<<(graph_method?result.iterations:0)<<",\\"linear_refinements\\":"<<(graph_method?result.total_refinements:0)<<",\\"backtracks\\":"<<(graph_method?result.total_backtracks:0)<<",\\"error\\":"<<(graph_method?result.error:0)<<"}\\n";
      if(comparison&&(graph_method?result.converged:true))CheckNonlinearOracle(input,window,allocation);
    }
    // Leave the graph result in the output for the caller's final certification.
    if(comparison){CheckCuda(cudaGraphLaunch(executable,allocation.stream()),"window graph final replay");allocation.Copy(&result,state,sizeof(result),cudaMemcpyDeviceToHost);}
''' +s[b:]
s=s.replace('bool graph_mode)', 'bool graph_mode, bool comparison)')
s=s.replace('graph.Run(dm, dw, dt, window, bytes, allocation);','graph.Run(dm, dw, dt, window, bytes, allocation,comparison,h);')
s=s.replace('std::string(argv[4]) != "--graph"','std::string(argv[4]) != "--graph" && std::string(argv[4]) != "--compare"')
s=s.replace('argc == 5);','argc == 5,argc==5&&std::string(argv[4])=="--compare");')
assert 'bool comparison, const WindowInput &input)' in s
assert 'bool graph_mode, bool comparison)' in s
(r/'cuda/emi03_time_nonlinear_probe.cu').write_text(s)
