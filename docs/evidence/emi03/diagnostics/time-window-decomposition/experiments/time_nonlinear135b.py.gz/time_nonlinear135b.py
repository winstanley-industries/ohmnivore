from reference.emi03 import ensemble as e
from pathlib import Path
import json,sys
np=e.metrics.np; w=Path('/home/adam/emi03-work');root=w/'time-nonlinear135';out=w/'time-nonlinear135b';out.mkdir(exist_ok=True)
def dense(m,n):
 a=np.zeros((n,n))
 for i in range(n):
  for j in range(m['rows'][i],m['rows'][i+1]):a[i,m['columns'][j]]=m['values'][j]
 return a

def experiment(path,length):
 data=json.loads(path.read_text());n=data['n'];G=dense(data['g'],n);B=dense(data['c'],n)/data['h'];A=dense(data['a'],n);base=G+B
 active=np.array(sorted(set(np.nonzero(B)[1])));equil=abs(A).max(axis=1)
 R=np.linalg.solve(A/equil[:,None],B[:,active]/equil[:,None]);T=R[active,:]
 initial=np.array(data['initial']);source=np.array(data['sources'][:length]);oracle=np.array(data['oracle'][:length]);absolute=np.array([1e-7]*data['node_count']+[1e-9]*(n-data['node_count']))
 reactive=data['reactive'];powers=[T]
 while 2**len(powers)<length:powers.append(powers[-1]@powers[-1])
 def linear(rhs,boundary):
  z=np.linalg.solve(A/equil[:,None],(rhs/equil).T).T;y=z[:,active].copy();y[0]+=T@boundary[active]
  for level,p in enumerate(powers):
   stride=1<<level
   if stride>=length:break
   v=y.copy();v[stride:]+=y[:-stride]@p.T;y=v
  previous=np.vstack([boundary[active],y[:-1]])
  return z+previous@R.T
 def linear_checked(rhs):
  x=linear(rhs,initial)
  for iteration in range(5):
   prev=np.vstack([initial,x[:-1]]).astype(np.longdouble);xx=x.astype(np.longdouble)
   effective=rhs.astype(np.longdouble)+prev@B.astype(np.longdouble).T
   r=effective-xx@A.astype(np.longdouble).T;den=abs(effective)+abs(xx)@abs(A.astype(np.longdouble)).T
   c=float(np.max(np.divide(abs(r),den,out=np.zeros_like(r),where=den!=0)))
   if iteration and c<=1e-5:return x
   if iteration<4:x+=linear(r.astype(float),np.zeros(n))
  raise ValueError('window linear residual')
 def functions(x):
  out=np.zeros_like(x);scale=np.zeros_like(x)
  for program in data['programs']:
   nodes=program['nodes']
   def ev(index,indices):
    op,a,b,c,value,constant=nodes[index]
    if op==0:return np.full(len(indices),value)
    if op==1:return x[indices,a]
    first=ev(a,indices)
    if op==11:
     mask=first!=0;v=np.empty(len(indices));v[mask]=ev(b,indices[mask]);v[~mask]=ev(c,indices[~mask]);return v
    if op==2:v=-first
    elif op==8:v=np.exp(first)
    else:
     second=ev(b,indices)
     if op==3:v=first+second
     elif op==4:v=first-second
     elif op==5:v=first*second
     elif op==6:v=first/second
     elif op==7:v=first**second
     elif op==9:v=(first<second).astype(float)
     elif op==10:v=(first>second).astype(float)
     else:raise ValueError('unknown expression')
    if not np.all(np.isfinite(v)) or np.any(abs(v)>1e100):raise FloatingPointError('expression bound')
    return v
   value=ev(program['root'],np.arange(length))
   for row,coefficient in program['rows']:out[:,row]+=coefficient*value;scale[:,row]+=abs(coefficient*value)
  return out,scale
 def residual(x):
  f,scale=functions(x);before=np.vstack([initial,x[:-1]])
  effective=source.astype(np.longdouble)+before.astype(np.longdouble)@B.astype(np.longdouble).T
  r=(effective-x.astype(np.longdouble)@base.astype(np.longdouble).T-f).astype(float)
  scale+=abs(effective).astype(float)+abs(x)@abs(base).T
  norm=float(np.max(abs(r)/(absolute[::-1] if False else np.array([1e-9]*data['node_count']+[1e-7]*(n-data['node_count']))+1e-5*scale)))
  return r,norm
 def update(x,v):
  norm=float(np.max(abs(v-x)/(absolute+1e-5*np.maximum(abs(v),abs(x)))))
  for a,b,tol in reactive:
   old=(x[:,a] if a>=0 else 0)-(x[:,b] if b>=0 else 0);new=(v[:,a] if a>=0 else 0)-(v[:,b] if b>=0 else 0)
   norm=max(norm,float(np.max(abs(new-old)/(.01*(tol+1e-4*np.maximum(abs(new),abs(old)))))))
  return norm
 x=np.tile(initial,(length,1));history=[];status='iteration_limit'
 with np.errstate(over='raise',divide='raise',invalid='raise'):
  try:
   r,norm=residual(x)
   for it in range(100):
    f,_=functions(x)
    affine=source+x@(A-base).T-f
    correction=linear_checked(affine)-x
    for backtrack in range(17):
     proposed=x+2.**(-backtrack)*correction
     try:
      rr,newnorm=residual(proposed)
      if newnorm<norm or newnorm<=1:break
     except FloatingPointError:continue
    else:status='backtrack_limit';break
    u=update(x,proposed);x=proposed;r=rr;norm=newnorm
    difference=float(np.max(abs(x-oracle)/(absolute+1e-5*np.maximum(abs(x),abs(oracle)))))
    history.append({'iteration':it,'backtracks':backtrack,'update':u,'residual':norm,'oracle_scaled_difference':difference})
    if u<=1 and norm<=1:status='converged';break
  except (FloatingPointError,ValueError) as ex:status=str(ex)
 record={'case':path.stem,'length':length,'status':status,'history':history,'fixed_jacobian':True,'scope':'nonlinear BE window feasibility, fixed schedule and captured initial state; no transient acceptance'}
 print(json.dumps(record),flush=True)
 (out/(path.stem+f'-L{length}-result.json')).write_text(json.dumps(record,indent=2)+'\n')
 if status=='converged':np.save(out/(path.stem+f'-L{length}-state.npy'),x)
 return record
results=[]
for path in sorted(root.glob('*.fixture.json')):
 for length in [8,32,128,512]:results.append(experiment(path,length))
(w/'time-nonlinear135b-result.json').write_text(json.dumps(results,indent=2)+'\n')
