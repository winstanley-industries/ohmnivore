from pathlib import Path
import subprocess,time,json,os
w=Path('/home/adam/emi03-work');tool=w/'pinned-profiler-bazel/external/+http_archive+compute_sanitizer_current/compute-sanitizer/compute-sanitizer';args=[str(w/'time139b-binary'),str(w/'schur-snapshots107/reference-nominal/input.cir'),str(w/'time-nonlinear135/reference-nominal.fixture.txt'),'128','--graph'];results=[]
for name in ['memcheck','racecheck','synccheck','initcheck']:
 command=[str(tool),'--tool',name,'--error-exitcode','99']+args
 start=time.monotonic();p=w/f'time139b-{name}.log'
 with p.open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,TMPDIR=str(w/'tmp')))
 result={'tool':name,'returncode':r.returncode,'wall_s':time.monotonic()-start,'command':command,'scope':'complete nonlinear graph invocation, reference nominal 128-step switching window'};results.append(result);print(json.dumps(result),flush=True)
 (w/'time139b-sanitizers.json').write_text(json.dumps(results,indent=2)+'\n')
