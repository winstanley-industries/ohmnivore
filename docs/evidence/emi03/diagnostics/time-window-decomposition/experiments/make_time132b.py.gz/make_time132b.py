from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'time132.cu').read_text()
s=s.replace('retry < 1','retry < 2')
old='''    if (threadIdx.x == 0)
      Reject(s, Invalid);
    __syncthreads();
  }
'''
new='''    if (retry == 0 && s.sparse_factor) {
      if (threadIdx.x == 0) { s.sparse_factor = false; ++w.progress.linear_retries; }
      __syncthreads();
    } else {
      if (threadIdx.x == 0) Reject(s, Invalid);
      __syncthreads();
    }
  }
'''
assert old in s;s=s.replace(old,new,1)
a=s.index('__global__ void CacheTimeFactors');b=s.index('__global__ void MakeTimeTransfer',a);f=s[a:b];pos=f.rfind('\n}');f=f[:pos]+'''\n  __syncthreads();
  // Cache a complete native-FP64 pivoted fallback for this immutable matrix.
  // Later independent RHS solves only read these factors.
  DenseFactor(m,w,s);
  if(threadIdx.x==0 && s.error)atomicCAS(t.error,0,s.error);
'''+f[pos:];s=s[:a]+f+s[b:]
s=s.replace('void CheckTimeErrors(const std::vector<TimeData> &data,','void CheckTimeErrors(const char *stage, const std::vector<TimeData> &data,')
s=s.replace('"time GPU failure " + std::to_string(error)','std::string(stage) + " time GPU failure " + std::to_string(error)')
s=s.replace('CheckTimeErrors(data, allocation);','CheckTimeErrors("completed", data, allocation);')
s=s.replace('CheckCuda(cudaGetLastError(), "time factors launch");\n    CheckTimeErrors("completed"','CheckCuda(cudaGetLastError(), "time factors launch");\n    CheckTimeErrors("factor cache"')
s=s.replace('CheckCuda(cudaGetLastError(), "time transfer launch");\n    CheckTimeErrors("completed"','CheckCuda(cudaGetLastError(), "time transfer launch");\n    CheckTimeErrors("transfer"')
(r/'cuda/emi03_time_matrix_probe.cu').write_text(s)
