// Each warp owns one RHS and three disjoint vectors. Cached factors are read-only.
__device__ double TimeWarpMax(double value) {
  for(int off=16;off;off/=2)value=fmax(value,__shfl_down_sync(0xffffffff,value,off));
  return __shfl_sync(0xffffffff,value,0);
}
__device__ bool TimeWarpTriangular(const Model &m,const Workspace &w,const TimeData &t,const double *rhs,double *result,double *values,bool dense) {
 const int lane=threadIdx.x%32;bool bad=false;
 if(!dense) {
  for(int level=0;level<m.forward_levels;++level){
   for(int at=m.forward_offsets[level]+lane;at<m.forward_offsets[level+1];at+=32){
    int row=m.forward_rows[at],original=m.row_permutation[row];
    double value=isfinite(t.inverse_equil[original])?rhs[original]*t.inverse_equil[original]:rhs[original]/t.equil[original];
    for(int j=m.factor_rows[row];j<m.factor_diagonal[row];++j)value=fma(-t.factor[j],values[m.factor_columns[j]],value);
    values[row]=value;
   }
   __syncwarp();
  }
  for(int level=0;level<m.backward_levels;++level){
   for(int at=m.backward_offsets[level]+lane;at<m.backward_offsets[level+1];at+=32){
    int row=m.backward_rows[at];double value=values[row];
    for(int j=m.factor_diagonal[row]+1;j<m.factor_rows[row+1];++j)value=fma(-t.factor[j],values[m.factor_columns[j]],value);
    values[row]=value*t.inverse[row];bad|=!Bounded(values[row]);
   }
   __syncwarp();
  }
  for(int row=lane;row<m.n;row+=32)result[m.column_permutation[row]]=values[row];
 } else {
  for(int row=lane;row<m.n;row+=32)values[row]=rhs[w.permutation[row]]/t.equil[w.permutation[row]];
  __syncwarp();
  for(int row=0;row<m.n;++row){double sum=0;for(int col=lane;col<row;col+=32)sum=fma(w.lu[row*N+col],values[col],sum);for(int off=16;off;off/=2)sum+=__shfl_down_sync(0xffffffff,sum,off);if(lane==0)values[row]-=sum;__syncwarp();}
  for(int row=m.n-1;row>=0;--row){double sum=0;for(int col=row+1+lane;col<m.n;col+=32)sum=fma(w.lu[row*N+col],result[col],sum);for(int off=16;off;off/=2)sum+=__shfl_down_sync(0xffffffff,sum,off);if(lane==0){result[row]=(values[row]-sum)/w.lu[row*N+row];bad|=!Bounded(result[row]);}__syncwarp();}
 }
 __syncwarp();return !__any_sync(0xffffffff,bad);
}
__global__ void TimeWarpIndependent(const Model *models,const Workspace *all,TimeData *data,int length,bool correction) {
 const int jobs_per_case=(length+7)/8,job=blockIdx.x/jobs_per_case,point=(blockIdx.x%jobs_per_case)*8+threadIdx.x/32,lane=threadIdx.x%32;
 const auto m=models[job];const auto t=data[job];const auto w=all[job];
 if(point>=length)return;
 extern __shared__ double vectors[];
 double *values=vectors+(threadIdx.x/32)*3*m.n,*x=values+m.n,*residual=x+m.n;
 const double *rhs=(correction?t.residual:t.rhs)+point*m.n;
 bool accepted=false;int error=0;unsigned long long refinements=0,retries=0;
 for(int attempt=0;attempt<2&&!accepted&&!error;++attempt){
  const bool dense=attempt!=0;
  if(dense)++retries;
  if(!TimeWarpTriangular(m,w,t,rhs,x,values,dense)){error=Nonfinite;break;}
  for(int iteration=0;iteration<=4;++iteration){
   double normalized=0,matrix_norm=0,rhs_norm=0,x_norm=0;bool nonzero=false,bad=false;
   for(int row=lane;row<m.n;row+=32){Sum sum;sum.Add(rhs[row]);for(int j=m.row_offsets[row];j<m.row_offsets[row+1];++j)sum.Product(-w.jacobian[j],x[m.columns[j]]);double value=sum.Value();residual[row]=value;bad|=!Bounded(value)||!Bounded(x[row]);nonzero|=value!=0;normalized=fmax(normalized,fabs(value)/t.equil[row]);matrix_norm=fmax(matrix_norm,t.row_norm[row]);rhs_norm=fmax(rhs_norm,fabs(rhs[row])/t.equil[row]);x_norm=fmax(x_norm,fabs(x[row]));}
   __syncwarp();
   if(__any_sync(0xffffffff,bad)){error=Nonfinite;break;}
   normalized=TimeWarpMax(normalized);matrix_norm=TimeWarpMax(matrix_norm);rhs_norm=TimeWarpMax(rhs_norm);x_norm=TimeWarpMax(x_norm);nonzero=__any_sync(0xffffffff,nonzero);
   const double denom=matrix_norm*x_norm+rhs_norm;
   if((iteration>0||!nonzero)&&(denom==0?normalized==0:normalized/denom<=1e-10)){accepted=true;break;}
   if(iteration==4)break;
   if(!TimeWarpTriangular(m,w,t,residual,residual,values,dense)){error=Nonfinite;break;}
   for(int row=lane;row<m.n;row+=32)x[row]+=residual[row];
   ++refinements;__syncwarp();
  }
 }
 if(lane==0){atomicAdd(t.counters,1ULL);atomicAdd(t.counters+1,refinements);atomicAdd(t.counters+2,retries);if(error||!accepted)atomicCAS(t.error,0,error?error:Invalid);}
 if(!error&&accepted){
  for(int row=lane;row<m.n;row+=32)t.z[point*m.n+row]=x[row];
  for(int row=lane;row<t.rank;row+=32){double value=x[t.active[row]];if(point==0&&!correction)for(int col=0;col<t.rank;++col)value=fma(t.powers[row*t.rank+col],t.initial[t.active[col]],value);t.scan_a[point*t.rank+row]=value;}
 }
}
