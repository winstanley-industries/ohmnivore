from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');s=(w/'selected119b.cu').read_text();prefix=s[:s.index('__global__ void SelectedMatrixReplay')]
a=s.index('  if (threadIdx.x == 0) {',s.index('__global__ void SelectedMatrixReplay'));b=s.index('  for (int i = threadIdx.x; i < m.n; i += Threads)\n    w.affine_rhs[i] = workspace->affine_rhs[i];',a)
init='__device__ void InitializeTime(const Model &m,const Workspace *workspace,Shared &s,double *scratch) {\n auto &w=s.runtime;\n'+s[a:b].replace('probe_storage','scratch')+'\n}\n'
h=(r/'cuda/emi03_resident_device.cuh').read_text();a=h.index('__device__ void Linear(');b=h.index('__device__ double ResidualNorm',a);linear=h[a:b].replace('void Linear(', 'void CachedTimeLinear(').replace('  Factor(m, w, s);\n','').replace('retry < 2','retry < 1');a=linear.index('    if (retry == 0 && s.sparse_factor) {');b=linear.index('\n  }\n  if (threadIdx.x == 0 && !s.error)',a);linear=linear[:a]+'''    if(threadIdx.x == 0)Reject(s,Invalid);
    __syncthreads();
'''+linear[b:]
device=(w/'time132_device.cc').read_text().replace('// INITIALIZE_HELPER',init).replace('// CACHED_LINEAR_HELPER',linear)
common=s[s.index('template <class T> T ProbeChecked'):s.index('int MatrixProbe')]
host=(w/'time132_host.cc').read_text().replace('    for(auto kernel:{CacheTimeFactors,SequentialTime}){static_cast<void>(kernel);}\n','')
(r/'cuda/emi03_time_matrix_probe.cu').write_text(prefix+device+common+host)
p=r/'cuda/BUILD.bazel';s=p.read_text()
if 'name = "emi03_time_matrix_probe_impl"' not in s:
 s+='''
cuda_library(
    name = "emi03_time_matrix_probe_impl",
    testonly = True,
    srcs = ["emi03_time_matrix_probe.cu"],
    copts = ["-std=c++20", "--fmad=false", "-lineinfo", "-Xcompiler=-Wall", "-Xcompiler=-Werror", "-Xcompiler=-Wextra"],
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_cuda", "@suitesparse_7_12_3//:klu"],
)
cc_binary(
    name = "emi03_time_matrix_probe",
    testonly = True,
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_time_matrix_probe_impl"],
)
''';p.write_text(s)
