struct WindowIterationStatus { int linear_error,linear_invalid,trial_error; double residual,update; };
__global__ void SimpleWindowReset(TimeData *data,NonlinearWindow window){if(threadIdx.x==0){*data[0].error=0;*data[0].invalid=0;*data[0].nonzero=0;*window.error=0;}}
__global__ void SimpleWindowStatus(const TimeData *data,NonlinearWindow window,WindowIterationStatus *out){
 if(threadIdx.x!=0)return;WindowIterationStatus value{};value.linear_error=*data[0].error;value.linear_invalid=*data[0].invalid;value.trial_error=*window.error;
 for(int i=0;i<window.length;++i){if(!isfinite(window.metrics[2*i])||!isfinite(window.metrics[2*i+1]))value.trial_error=Nonfinite;value.residual=fmax(value.residual,window.metrics[2*i]);value.update=fmax(value.update,window.metrics[2*i+1]);}*out=value;
}
class SimpleWindowGraph:public WindowGraph {
 const Model *models_;const Workspace *workspace_;TimeData *data_;NonlinearWindow window_;std::size_t bytes_;Allocations &allocation_;WindowIterationStatus *status_;
public:
 SimpleWindowGraph(const Model *models,const Workspace *workspace,TimeData *data,NonlinearWindow window,std::size_t bytes,Allocations &allocation):models_(models),workspace_(workspace),data_(data),window_(window),bytes_(bytes),allocation_(allocation){
  status_=allocation.Allocate<WindowIterationStatus>(1);const int length=window.length;cudaGraphNode_t tail=nullptr;
  Kernel(graph,tail,1,1,0,SimpleWindowReset,data,window);
  Kernel(graph,tail,dim3(length),dim3(Threads),bytes,NonlinearWindowAffine,models,workspace,data,window);
  Pass(graph,tail,models,workspace,data,length,false);
  Kernel(graph,tail,dim3(length),dim3(Threads),0,TimeResidual,models,workspace,data,length);
  // One correction is always attempted. The following full residual decides
  // whether another bounded correction is needed; no failed result is accepted.
  Pass(graph,tail,models,workspace,data,length,true);
  Kernel(graph,tail,1,1,0,WindowGraphClearResidual,data);
  Kernel(graph,tail,dim3(length),dim3(Threads),0,TimeResidual,models,workspace,data,length);
  Kernel(graph,tail,dim3((length*185+Threads-1)/Threads),dim3(Threads),0,NonlinearWindowBlend,models,data,window,1.);
  Kernel(graph,tail,dim3(length),dim3(Threads),bytes,NonlinearWindowCheck,models,workspace,data,window,false);
  Kernel(graph,tail,1,1,0,SimpleWindowStatus,data,window,status_);
  CheckCuda(cudaGraphInstantiate(&executable,graph,0),"simple window instantiate");
 }
 WindowIterationStatus ReadStatus(){WindowIterationStatus value{};allocation_.Copy(&value,status_,sizeof(value),cudaMemcpyDeviceToHost);return value;}
 WindowIterationStatus Trial(double scale){
  CheckCuda(cudaMemsetAsync(window_.error,0,sizeof(int),allocation_.stream()),"simple trial clear");
  NonlinearWindowBlend<<<(window_.length*185+Threads-1)/Threads,Threads,0,allocation_.stream()>>>(models_,data_,window_,scale);CheckCuda(cudaGetLastError(),"simple trial blend");
  NonlinearWindowCheck<<<window_.length,Threads,bytes_,allocation_.stream()>>>(models_,workspace_,data_,window_,false);CheckCuda(cudaGetLastError(),"simple trial check");
  SimpleWindowStatus<<<1,1,0,allocation_.stream()>>>(data_,window_,status_);CheckCuda(cudaGetLastError(),"simple status");return ReadStatus();
 }
 WindowGraphState Solve(const std::vector<TimeData> &host_data){
  WindowGraphState state{};state.previous_residual=INFINITY;
  NonlinearWindowSeed<<<(window_.length*185+Threads-1)/Threads,Threads,0,allocation_.stream()>>>(models_,data_,window_);CheckCuda(cudaGetLastError(),"simple window seed");
  for(int iteration=0;iteration<100;++iteration){
   CheckCuda(cudaGraphLaunch(executable,allocation_.stream()),"simple iteration launch");auto status=ReadStatus();int refinements=1;++state.total_refinements;
   while(!status.linear_error&&status.linear_invalid&&refinements<4){
    TimePass(models_,workspace_,data_,1,host_data[0].rank,window_.length,bytes_,allocation_,true);ClearTimeFlags(host_data,allocation_,false);
    TimeResidual<<<window_.length,Threads,0,allocation_.stream()>>>(models_,workspace_,data_,window_.length);CheckCuda(cudaGetLastError(),"simple extra residual");status=Trial(1);++refinements;++state.total_refinements;
   }
   if(status.linear_error||status.linear_invalid){state.error=status.linear_error?status.linear_error:Invalid;break;}
   bool accepted=false;int backtrack=0;
   for(;backtrack<=16;++backtrack){
    if(backtrack){status=Trial(std::ldexp(1.,-backtrack));++state.total_backtracks;}
    if(status.trial_error){if(status.trial_error!=Nonfinite){state.error=status.trial_error;break;}continue;}
    if(status.residual<state.previous_residual||status.residual<=1){accepted=true;break;}
   }
   if(!accepted){if(!state.error)state.error=Nonconvergence;break;}
   const int at=state.iterations++;state.trace[at][0]=state.residual=status.residual;state.trace[at][1]=state.update=status.update;state.trace[at][2]=backtrack;state.trace[at][3]=refinements;state.previous_residual=status.residual;
   if(status.residual<=1&&status.update<=1){
    NonlinearWindowCheck<<<window_.length,Threads,bytes_,allocation_.stream()>>>(models_,workspace_,data_,window_,true);CheckCuda(cudaGetLastError(),"simple final certification");int error=0;allocation_.Copy(&error,window_.error,sizeof(int),cudaMemcpyDeviceToHost);state.error=error;state.converged=!error;break;
   }
   CheckCuda(cudaMemcpyAsync(window_.current,window_.candidate,window_.length*185*sizeof(double),cudaMemcpyDeviceToDevice,allocation_.stream()),"simple iteration commit");
  }
  if(!state.converged&&!state.error)state.error=Nonconvergence;return state;
 }
};
WindowGraphState CompareSimpleWindow(const Model *models,const Workspace *workspace,TimeData *data,NonlinearWindow window,std::size_t bytes,Allocations &allocation,const std::vector<TimeData> &host_data,const WindowInput &input,bool comparison){
 SimpleWindowGraph graph(models,workspace,data,window,bytes,allocation);WindowGraphState result{};
 CheckCuda(cudaFuncSetAttribute(SequentialNonlinearWindow,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes),"simple sequential shared");
 for(int repetition=-1;repetition<(comparison?9:0);++repetition)for(int order=0;order<(comparison?2:1);++order){
  const bool parallel=!comparison||((repetition+1+order)%2==0);CheckCuda(cudaMemsetAsync(window.error,0,sizeof(int),allocation.stream()),"simple comparison clear");const auto start=std::chrono::steady_clock::now();
  if(parallel)result=graph.Solve(host_data);
  else{SequentialNonlinearWindow<<<1,Threads,bytes,allocation.stream()>>>(models,workspace,data,window);CheckCuda(cudaGetLastError(),"simple sequential launch");int error=0;allocation.Copy(&error,window.error,sizeof(int),cudaMemcpyDeviceToHost);if(error)throw std::runtime_error("simple sequential failure "+std::to_string(error));}
  const double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout<<"{\"kind\":\"graph_comparison\",\"method\":\""<<(parallel?"simple_graph":"sequential")<<"\",\"repetition\":"<<repetition<<",\"length\":"<<window.length<<",\"wall_s\":"<<elapsed<<",\"iterations\":"<<(parallel?result.iterations:0)<<",\"linear_refinements\":"<<(parallel?result.total_refinements:0)<<",\"backtracks\":"<<(parallel?result.total_backtracks:0)<<",\"error\":"<<(parallel?result.error:0)<<"}\n";
  if(comparison&&(parallel?result.converged:true))CheckNonlinearOracle(input,window,allocation);
 }
 if(comparison)result=graph.Solve(host_data);return result;
}
