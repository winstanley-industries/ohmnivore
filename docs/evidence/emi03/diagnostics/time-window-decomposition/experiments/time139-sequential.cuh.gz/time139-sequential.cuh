__global__ void SequentialNonlinearWindow(const Model *models,const Workspace *all,const TimeData *data,NonlinearWindow window) {
 const auto m=models[0];const auto t=data[0];Workspace isolated=all[0];isolated.lu=window.lu;isolated.permutation=window.permutations;isolated.factored_jacobian=window.factored;
 __shared__ Shared s;extern __shared__ double nonlinear_sequential_storage[];InitializeTime(m,&isolated,s,nonlinear_sequential_storage);auto &w=s.runtime;
 for(int row=threadIdx.x;row<m.n;row+=Threads)w.state[row]=t.initial[row];
 __syncthreads();
 for(int point=0;point<window.length&&!s.error;++point){
  Step(m,w,s,w.state,window.time+point*t.step,window.time+(point+1)*t.step,t.step,true,false,w.full);
  for(int row=threadIdx.x;row<m.n;row+=Threads){window.candidate[point*m.n+row]=w.full[row];w.state[row]=w.full[row];}
  __syncthreads();
 }
 if(threadIdx.x==0&&s.error)atomicCAS(window.error,0,s.error);
}
