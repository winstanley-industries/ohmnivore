from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore')
resident=(r/'cuda/emi03_resident.cu').read_text();a=resident.index('Model Prepare(');b=resident.index('\n} // namespace',a)
s='''// Fixed-schedule nonlinear window research; never linked into the simulator.
#define main MatrixResearchMain
#include "cuda/emi03_time_matrix_probe.cu"
#undef main
#include <iterator>
namespace ohmnivore { namespace {
'''+resident[a:b]+'\n'+(w/'time137-device.cuh').read_text()+'\n'+(w/'time137-host.cc').read_text()+'''
} }
int main(int argc,char **argv){try{if(argc!=4)return 2;std::cout<<std::setprecision(17);return ohmnivore::NonlinearTimeProbe(argv[1],argv[2],std::stoi(argv[3]));}catch(const std::exception &e){std::cerr<<e.what()<<'\\n';return 1;}}
'''
(r/'cuda/emi03_time_nonlinear_probe.cu').write_text(s)
p=r/'cuda/BUILD.bazel';s=p.read_text()
if 'name = "emi03_time_nonlinear_probe_impl"' not in s:
 s+='''
cuda_library(
    name = "emi03_time_nonlinear_probe_impl",
    testonly = True,
    srcs = ["emi03_time_nonlinear_probe.cu"],
    hdrs = ["emi03_time_matrix_probe.cu"],
    copts = ["-std=c++20", "--fmad=false", "-lineinfo", "-Xcompiler=-Wall", "-Xcompiler=-Werror", "-Xcompiler=-Wextra"],
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_cuda", "@suitesparse_7_12_3//:klu"],
)
cc_binary(
    name = "emi03_time_nonlinear_probe",
    testonly = True,
    tags = ["manual"],
    target_compatible_with = CUDA_SANITIZER_COMPATIBILITY,
    deps = [":emi03_time_nonlinear_probe_impl"],
)
''';p.write_text(s)
import json
for p in (w/'time-nonlinear135').glob('*.fixture.json'):
 d=json.loads(p.read_text());out=p.with_suffix('.txt')
 out.write_text(f"EMI03_NONLINEAR_TIME_1 {d['n']} {d['length']} {d['t0']:.17g} {d['h']:.17g}\n"+' '.join(format(x,'.17g') for x in d['initial'])+'\n'+'\n'.join(' '.join(format(x,'.17g') for x in row) for row in d['oracle'])+'\n')
