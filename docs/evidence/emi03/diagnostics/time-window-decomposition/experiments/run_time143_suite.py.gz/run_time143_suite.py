from pathlib import Path
import subprocess,json,time,os
w=Path('/home/adam/emi03-work');root=w/'time-nonlinear143';root.mkdir(exist_ok=True);records=[];env=dict(os.environ,TMPDIR=str(w/'tmp'))
for folder in sorted((w/'schur-snapshots107').glob('*-*')):
 if not folder.is_dir():continue
 for length in [8,32,128,512]:
  mode='--simple-compare' if length==128 else '--simple';cmd=[str(w/'time143-binary'),str(folder/'input.cir'),str(w/'time-nonlinear135'/(folder.name+'.fixture.txt')),str(length),mode]
  out=root/f'{folder.name}-L{length}.jsonl';err=root/f'{folder.name}-L{length}.err';start=time.monotonic()
  with out.open('w') as stdout,err.open('w') as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=env)
  record={'case':folder.name,'length':length,'mode':mode,'command':cmd,'returncode':r.returncode,'wall_s':time.monotonic()-start,'error':err.read_text()};records.append(record);print(json.dumps(record),flush=True);(root/'results.json').write_text(json.dumps(records,indent=2)+'\n')
