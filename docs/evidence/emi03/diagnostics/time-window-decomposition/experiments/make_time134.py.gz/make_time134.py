from pathlib import Path
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore')
s=(w/'time132c.cu').read_text()
s=s.replace('std::vector<double> rhs, truth;', 'std::vector<double> rhs, truth, oracle;')
pos=s.index('TimeData PrepareTimeData')
s=s[:pos]+'''void ReadTimeOracle(const char *path, std::vector<HostTime> &cases) {
  std::ifstream input(path);
  std::string magic; int jobs=0,n=0,length=0;
  input>>magic>>jobs>>n>>length;
  if(!input || magic!="EMI03_TIME_ORACLE_1" || jobs!=static_cast<int>(cases.size()) || n!=185 || length!=512)
    throw std::runtime_error("invalid independent CPU time oracle");
  for(auto &h:cases) {
    std::string name; double step=0; input>>name>>step;
    if(!input || name!=h.sample.name || step!=h.step) throw std::runtime_error("CPU time oracle identity mismatch");
    h.oracle.resize(n*length);
    for(double &v:h.oracle) { input>>v; if(!input || !std::isfinite(v)) throw std::runtime_error("invalid CPU time oracle state"); }
  }
  std::string extra; if(input>>extra) throw std::runtime_error("CPU time oracle trailing data");
}
''' + s[pos:]
s=s.replace('const Model &m, Allocations &allocation) {\n  TimeData t{};', 'const Model &m, Allocations &allocation, int *flags) {\n  TimeData t{};')
s=s.replace('t.error = allocation.Upload(std::vector<int>(3));','t.error = flags;')
a=s.index('void CheckTimeErrors(');b=s.index('void TimePass(',a)
s=s[:a]+'''void CheckTimeErrors(const char *stage, const std::vector<TimeData> &data, Allocations &allocation) {
  int error=0; allocation.Copy(&error,data.front().error,sizeof(int),cudaMemcpyDeviceToHost);
  if(error) throw std::runtime_error(std::string(stage)+" time GPU failure "+std::to_string(error));
}
void ClearTimeFlags(const std::vector<TimeData> &data, Allocations &allocation,bool errors) {
  const auto &t=data.front();
  CheckCuda(cudaMemsetAsync(errors?t.error:t.invalid,0,(errors?3:2)*sizeof(int),allocation.stream()),"time flag clear");
}
''' +s[b:]
s=s.replace('for (const auto &t : data) {\n      int flags[3]{};', '{\n      const auto &t=data.front();\n      int flags[3]{};')
s=s.replace('double maximum = 0, difference = 0;\n  std::size_t checked', 'double maximum = 0, difference = 0, oracle_difference=0;\n  std::size_t checked')
s=s.replace('std::abs(solution[row] - h.truth[(point + 1) * n + row]));','std::abs(solution[row] - h.truth[(point + 1) * n + row]));\n        oracle_difference=std::max(oracle_difference,std::abs(solution[row]-h.oracle[point*n+row]));')
s=s.replace('if (difference > 2e-10)', 'if (difference > 2e-10 || oracle_difference>2e-10)')
s=s.replace('<< ",\\\"manufactured_difference\\\":" << difference << "}\\n";', '<< ",\\\"manufactured_difference\\\":" << difference << ",\\\"klu_difference\\\":"<<oracle_difference<<"}\\n";')
s=s.replace('int TimeProbe(const char *replay, const char *mass, bool validation_only)', 'int TimeProbe(const char *replay, const char *mass, const char *oracle, bool validation_only)')
s=s.replace('const auto cases = ReadTime(replay, mass, active);', 'auto cases = ReadTime(replay, mass, active);\n  ReadTimeOracle(oracle,cases);')
s=s.replace('std::size_t bytes = 0;\n    for', 'std::size_t bytes = 0;\n    int *flags=allocation.Upload(std::vector<int>(3));\n    for')
s=s.replace('PrepareTimeData(cases[i], active, models[i], allocation)', 'PrepareTimeData(cases[i], active, models[i], allocation,flags)')
s=s.replace('if (argc < 3 || argc > 4 ||\n        (argc == 4 && std::string(argv[3]) != "--validate-only"))', 'if (argc < 4 || argc > 5 ||\n        (argc == 5 && std::string(argv[4]) != "--validate-only"))')
s=s.replace('TimeProbe(argv[1], argv[2], argc == 4)', 'TimeProbe(argv[1], argv[2], argv[3],argc == 5)')
assert 'klu_difference' in s
(r/'cuda/emi03_time_matrix_probe.cu').write_text(s)
