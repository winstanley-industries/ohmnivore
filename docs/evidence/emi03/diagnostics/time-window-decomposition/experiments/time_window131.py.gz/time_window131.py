from reference.emi03 import ensemble as e
from pathlib import Path
import json
np=e.metrics.np;w=Path('/home/adam/emi03-work')
exec((w/'analyze_structure.py').read_text().split('@lru_cache(None)')[0])
# An exact column-selector factorization C = U V^T: no rank truncation.
active=np.array(sorted({j for (i,j),value in c.items() if value!=0}));C=np.zeros((size,size))
for (i,j),value in c.items():C[i,j]=value
records=[]
for folder in sorted((w/'schur-snapshots107').glob('*-*')):
 if not folder.is_dir():continue
 m=json.loads((folder/'matrices.jsonl').read_text().splitlines()[4]);assert m['alpha']==1
 A=np.zeros((size,size))
 for i in range(size):A[i,np.array(m['columns'][m['rows'][i]:m['rows'][i+1]])]=m['values'][m['rows'][i]:m['rows'][i+1]]
 B=C/m['step_s'];scale=abs(A).max(axis=1);R=np.linalg.solve(A/scale[:,None],B[:,active]/scale[:,None]);T=R[active,:];rho=float(max(abs(np.linalg.eigvals(T))))
 for length in [8,32,128,512]:
  states=np.sin(np.arange(length+1)[:,None]*.031+np.arange(size)[None,:]*.047)*.2
  aa=A.astype(np.longdouble);bb=B.astype(np.longdouble);xx=states.astype(np.longdouble)
  rhs=(xx[1:]@aa.T-xx[:-1]@bb.T).astype(float);initial=states[0]
  def window_solve(rhs,initial):
   z=np.linalg.solve(A/scale[:,None],(rhs/scale).T).T
   y=z[:,active].copy();y[0]+=T@initial[active];power=T.copy();stride=1
   while stride<length:
    updated=y.copy();updated[stride:]+=y[:-stride]@power.T;y=updated;power=power@power;stride*=2
   prior=np.vstack([initial[active],y[:-1]])
   return z+prior@R.T
  def check(x):
   all_x=np.vstack([initial,x]).astype(np.longdouble);res=rhs.astype(np.longdouble)-all_x[1:]@aa.T+all_x[:-1]@bb.T
   den=abs(rhs.astype(np.longdouble))+abs(all_x[1:])@abs(aa).T+abs(all_x[:-1])@abs(bb).T
   component=float(np.max(np.divide(abs(res),den,out=np.zeros_like(res),where=den!=0)))
   matrix_norm=float(np.max((abs(aa).sum(axis=1)+abs(bb).sum(axis=1))/scale));solution_norm=float(np.max(abs(all_x)));rhs_norm=float(np.max(abs(rhs)/scale));normwise=float(np.max(abs(res)/scale)/(matrix_norm*solution_norm+rhs_norm))
   return res.astype(float),normwise,component
  x=window_solve(rhs,initial);history=[]
  for attempt in range(5):
   residual,norm,comp=check(x);history.append({'normwise':norm,'componentwise':comp,'error_to_manufactured':float(np.max(abs(x-states[1:])))})
   if not np.any(residual) or (attempt>0 and norm<=1e-10 and comp<=1e-5):break
   if attempt<4:x+=window_solve(residual,np.zeros(size))
  record={'case':folder.name,'length':length,'time_s':m['time_s'],'step_s':m['step_s'],'transfer_dimension':len(active),'spectral_radius':rho,'status':'pass' if norm<=1e-10 and comp<=1e-5 else 'failure','history':history};records.append(record);print(json.dumps(record),flush=True)
result={'scope':'Offline constant-Jacobian backward-Euler block recurrence feasibility on captured coupled Jacobians; manufactured RHS, original block residual, no nonlinear trajectories or GPU timing','active_columns':active.tolist(),'records':records}
(w/'time-window131.json').write_text(json.dumps(result,indent=2)+'\n')
