from pathlib import Path
import gzip,hashlib,json,re,statistics,subprocess
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');out=r/'docs/evidence/emi03/diagnostics/time-window-decomposition';out.mkdir(parents=True,exist_ok=True)
entries=[]
def keep(p,relative):
 data=p.read_bytes();target=out/(str(relative)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,compresslevel=6,mtime=0));entries.append({'original':str(p),'artifact':str(target.relative_to(out)),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest(),'stored_bytes':target.stat().st_size,'stored_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
for p in sorted(w.iterdir()):
 if not p.is_file():continue
 if not (p.name.startswith(('time','make_time','run_time','prepare_time')) and re.search(r'13[1-9]|14[0-4]',p.name)):continue
 if p.name.endswith('binary'):continue
 if p.name.startswith('time144-'):continue
 if p.suffix not in ['.py','.cu','.cuh','.cc','.json','.jsonl','.txt','.log','.err','.bazel','.ncu-repz']:continue
 keep(p,Path('experiments')/p.name)
for folder in ['time-structures131b','time-nonlinear135','time-nonlinear135b','time-nonlinear137c','time-nonlinear139b','time-phases140','time-nonlinear143','time-phases143']:
 for p in sorted((w/folder).rglob('*')):
  if p.is_file():keep(p,Path('experiments')/folder/p.relative_to(w/folder))
keep(w/'schur-replay117.txt',Path('inputs/schur-replay117.txt'))
for p in [r/'cpp/BUILD.bazel',r/'cuda/BUILD.bazel',r/'cpp/benchmarks/emi03_schur_probe.cc',r/'cpp/benchmarks/emi03_time_cpu_probe.cc',r/'cpp/benchmarks/emi03_time_nonlinear_fixture.cc',r/'cuda/emi03_time_matrix_probe.cu',r/'cuda/emi03_time_probe_common.cuh',r/'cuda/emi03_time_nonlinear_probe.cu',r/'cuda/emi03_conditional_graph_probe.cu']:
 keep(p,Path('source-at-validation')/p.relative_to(r))
binaries=[]
for p in sorted(w.glob('time*-binary')):
 if re.search(r'13[1-9]|14[0-3]',p.name):binaries.append({'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
summary={'scope':'Time-window matrix and fixed-schedule nonlinear GPU research, not EMI-03 full transient acceptance','acceptance_pass':False,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'binaries':binaries,'artifacts':entries}
(out/'artifact-index.json').write_text(json.dumps(summary,indent=2)+'\n')
rows=[]
for folder in ['time-nonlinear143','time-phases143']:
 for item in json.loads((w/folder/'results.json').read_text()):
  data=[json.loads(x) for x in (w/folder/f"{item['case']}-L{item['length']}.jsonl").read_text().splitlines()]
  record=dict(item);record.pop('command');record['terminal']=data[-1] if data else None
  timings={m:[x['wall_s'] for x in data if x['kind']=='graph_comparison' and x['method']==m and x['repetition']>=0] for m in ['simple_graph','sequential']}
  if all(len(v)==9 for v in timings.values()):record['median_s']={m:statistics.median(v) for m,v in timings.items()};record['sequential_over_parallel']=record['median_s']['sequential']/record['median_s']['simple_graph']
  rows.append(record)
(out/'nonlinear-results.json').write_text(json.dumps({'windows':rows,'passes':sum(x['returncode']==0 for x in rows),'rejections':sum(x['returncode']==3 for x in rows),'unexpected_failures':sum(x['returncode'] not in [0,3] for x in rows),'distinct_validated_states':sum(x['length'] for x in rows if x['returncode']==0)},indent=2)+'\n')
print(json.dumps({'artifacts':len(entries),'stored_bytes':sum(x['stored_bytes'] for x in entries),'largest_bytes':max(x['stored_bytes'] for x in entries)}))
