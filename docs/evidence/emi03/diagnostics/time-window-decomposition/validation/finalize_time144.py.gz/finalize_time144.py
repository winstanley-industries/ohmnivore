from pathlib import Path
import json,gzip,hashlib
w=Path('/home/adam/emi03-work');r=Path('/home/adam/code/ohmnivore');root=r/'docs/evidence/emi03/diagnostics/time-window-decomposition';index=json.loads((root/'artifact-index.json').read_text())
validation=json.loads((w/'time-validation144/results.json').read_text())
for row in validation:
 if row['name']=='selected-cuda-tests':row['superseded_by']='selected-cuda-tests-corrected';row['failure_class']='incorrect diagnostic target labels; no tests ran'
for name,needle in [('selected-cuda-tests-corrected','6 tests pass.'),('lockfile-tests','40 tests pass.')]:
 log=(w/'time-validation144'/f'{name}.log').read_text();assert needle in log;validation.append({'name':name,'pass':True,'log':f'{name}.log'})
assert all(row['pass'] or row.get('superseded_by') for row in validation)
(w/'time-validation144/final-results.json').write_text(json.dumps(validation,indent=2)+'\n')
paths=list((w/'time-validation144').glob('*'))+[w/'time144-lint.log',w/'validate_time144.py',w/'archive_time144.py',w/'finalize_time144.py',w/'time144-validation.log']
for p in paths:
 if not p.is_file():continue
 data=p.read_bytes();relative=Path('validation')/p.relative_to(w);target=root/(str(relative)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,compresslevel=6,mtime=0));entry={'original':str(p),'artifact':str(target.relative_to(root)),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest(),'stored_bytes':target.stat().st_size,'stored_sha256':hashlib.sha256(target.read_bytes()).hexdigest()};index['artifacts']=[x for x in index['artifacts'] if x['artifact']!=entry['artifact']]+[entry]
index['validation_summary']={'all_final_stages_pass':True,'retained_tooling_failures':1,'ordinary_tests':40,'selected_cuda_tests':6,'cpu_oracle_byte_identity':True,'cpu_asan_and_ubsan_fixture_runs_pass':True,'explicit_cuda_sanitizer_incompatibility_checks':6,'no_production_solver_change':True}
(root/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
for row in index['artifacts']:
 data=(root/row['artifact']).read_bytes();assert len(data)==row['stored_bytes'] and hashlib.sha256(data).hexdigest()==row['stored_sha256'];decoded=gzip.decompress(data);assert len(decoded)==row['original_bytes'] and hashlib.sha256(decoded).hexdigest()==row['original_sha256']
print(json.dumps({'verified_artifacts':len(index['artifacts']),'stored_bytes':sum(x['stored_bytes'] for x in index['artifacts']),'validation':index['validation_summary']}))
