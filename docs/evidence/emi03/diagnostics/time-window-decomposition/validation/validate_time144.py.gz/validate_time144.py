from pathlib import Path
import subprocess,json,time,os,hashlib
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=w/'time-validation144';out.mkdir(exist_ok=True);env=dict(os.environ,TMPDIR=str(w/'tmp'));records=[]
def run(name,args,expected=0):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(name+'.log')).read_text();okay=p.returncode==0 if expected==0 else p.returncode!=0 and 'incompatible' in text
 item={'name':name,'command':args,'returncode':p.returncode,'expected':'success' if expected==0 else 'sanitizer incompatibility','pass':okay,'wall_s':time.monotonic()-start};records.append(item);print(json.dumps(item),flush=True);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
 return okay
cpu=['//cpp:emi03_schur_probe','//cpp:emi03_time_cpu_probe','//cpp:emi03_time_nonlinear_fixture'];cuda=['//cuda:emi03_time_matrix_probe','//cuda:emi03_time_nonlinear_probe','//cuda:emi03_conditional_graph_probe']
run('cpu-probes',['bazel','build','-c','opt','--jobs=1',*cpu])
# Recompiled formatted CPU source must reproduce the retained independent oracle byte for byte.
with (out/'oracle.txt').open('w') as stdout,(out/'oracle.log').open('w') as stderr:p=subprocess.run([str(r/'bazel-out/k8-opt/bin/cpp/emi03_time_cpu_probe'),str(w/'schur-replay117.txt'),str(w/'time-mass132.txt')],cwd=r,env=env,stdout=stdout,stderr=stderr)
match=p.returncode==0 and (out/'oracle.txt').read_bytes()==(w/'time-oracle133.txt').read_bytes();records.append({'name':'formatted-cpu-oracle-identity','returncode':p.returncode,'pass':match,'sha256':hashlib.sha256((out/'oracle.txt').read_bytes()).hexdigest()});(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print('formatted CPU oracle identity',match,flush=True)
run('cuda-probes',['bazel','build','-c','opt','--config=cuda','--jobs=1',*cuda])
run('selected-cuda-tests',['bazel','test','-c','opt','--config=cuda','--jobs=1','--local_test_jobs=1','//:cuda_smoke_test','//cuda:emi03_cuda_test','//cuda:emi03_resident_test','//cuda:emi03_resident_linkage_test','//cuda:emi03_linkage_test','//cuda:emi03_reduction_test'])
run('build-all',['bazel','build','--jobs=4','//...'])
run('test-all',['bazel','test','--jobs=4','--local_test_jobs=4','//...'])
for config in ['asan','ubsan']:
 run(config+'-cpu-probes',['bazel','build',f'--config={config}','--jobs=4',*cpu])
 # Use the build-selected link while this configuration is current.
 run(config+'-nonlinear-reference',[str(r/'bazel-bin/cpp/emi03_time_nonlinear_fixture'),str(w/'schur-snapshots107/reference-nominal/input.cir'),str(w/'time-nonlinear135/reference-nominal.initial'),'512'])
 for target in cuda:run(config+'-'+target.split(':')[-1],['bazel','build','--config=cuda',f'--config={config}',target],1)
run('diff-check',['git','diff','--check'])
if not all(x['pass'] for x in records):raise SystemExit(1)
