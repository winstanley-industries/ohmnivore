from pathlib import Path
import os,subprocess
r=Path('/home/adam/code/ohmnivore/bazel-out/k8-opt/bin/reference/emi03/ensemble.runfiles').resolve();w=Path('/home/adam/emi03-work')
env=dict(os.environ,RUNFILES_DIR=str(r),TMPDIR=str(w/'tmp'),PYTHONPATH=':'.join([str(r/'_main'),str(r/'rules_python+'),str(next(r.glob('rules_python++pip+*'))/'site-packages')]))
raise SystemExit(subprocess.call([str(next(r.glob('rules_python++python+*/bin/python3'))),str(w/'pool_dpt89.py')],env=env))
