from reference.emi03 import ensemble as e
from pathlib import Path
import gzip,io,json,statistics,subprocess,tarfile,tempfile
r=Path('/home/adam/code/ohmnivore');out=r/'docs/evidence/emi03/diagnostics/resident-hardware-counters';base=r/'docs/evidence/emi03/diagnostics/resident-owner-pool';np=e.metrics.np
variants=[];raw_count=0;wave_count=0
for v in range(85,91):
 p=out/('variant-'+str(v));identity=json.loads((p/'identity.json').read_text())
 with tempfile.TemporaryDirectory(prefix='counter-source-audit-') as tmp:
  path=Path(tmp)
  with tarfile.open(fileobj=io.BytesIO((base/'sources.tar.gz').read_bytes()),mode='r:gz') as tar:
   for member in tar:
    assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
    target=path/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
  subprocess.run(['git','apply','--check',str(p/'source.patch')],cwd=path,check=True)
  subprocess.run(['git','apply',str(p/'source.patch')],cwd=path,check=True)
  for name,h in identity['sources'].items():assert e.study.sha((path/name).read_bytes())==h,name
 assert '[  PASSED  ] 10 tests.' in (p/'tests.log').read_text()
 variants.append(v)
for name in ['resident-block-screen87','resident-amd88','resident-prefetch90','resident-coupled20us89']:
 p=out/name;records=json.loads((p/'records.json').read_text());long=name=='resident-coupled20us89';stop=(20 if long else 1.03)*1e-6;grid=np.linspace(0,stop,40001 if long else 2061)
 for row in records:
  folder=p/row['lane'] if long else p/(row['lane']+'-'+str(row['trial'])+('-profile' if row.get('profile') else ''))
  raw=gzip.decompress((folder/'output.raw.gz').read_bytes());assert e.study.sha(raw)==row['raw_sha256'];raw_count+=1
  table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,stop,625e-12);assert len(table)==row['points']
  if row['lane']=='cpu':reference={n:np.interp(grid,table[:,0],table[:,i]) for i,n in enumerate(e.circuits.STUDY_NAMES)}
  else:
   compared={n:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[n],n.startswith('v('),400) for i,n in enumerate(e.circuits.STUDY_NAMES) if n!='time'}
   assert compared==row['waveforms'] and all(x['pass'] for x in compared.values());wave_count+=1
   gpu=json.loads((folder/'stats.json.gpu.json').read_text());e.validate_gpu_telemetry(gpu,gpu['job_id'])
 assert not json.loads((p/'summary.json').read_text())['acceptance_pass']
 if not long:
  summary=json.loads((p/'summary.json').read_text())
  medians={lane:statistics.median(x['wall_s'] for x in records if x['lane']==lane and x['trial']>=0 and not x.get('profile')) for lane in {x['lane'] for x in records if x['lane']!='cpu'}}
  assert medians==summary['median_request_wall_s']
refinements=[]
for name in ['pool-dpt-88','pool-dpt-89']:
 p=out/name;summary=json.loads((p/'summary.json').read_text());identity=json.loads((p/'identity.json').read_text());refs=[]
 for n,h in identity['sources'].items():assert e.study.sha((p/'sources'/n).read_bytes())==h,n
 for lane in ['cpu','gpu']:
  rows=summary['results'][lane]['jobs'];by={x['level']:x for x in rows};assert set(by)=={0,1,2}
  for row in rows:
   table=e.study.restore(p/lane,row);raw_count+=1
   assert e.metrics.dpt(table,row['sample_step_s'])==row['metrics'] and row['metrics']['pass']
   if lane=='gpu':
    cpu={x['level']:x for x in summary['results']['cpu']['jobs']}[row['level']]
    compared=e.compare_pair(table,row,e.study.restore(p/'cpu',cpu),cpu)
    assert compared==row['cpu_validation'] and compared['pass'];wave_count+=1
    e.validate_gpu_telemetry(row['gpu'],row['request_input'])
  for level in [1,2]:refs.append(e.study.dpt_compare(by[level-1]['metrics'],by[level]['metrics'],f'{lane}-q{level-1}-q{level}'))
  for dt in e.study.selected_manifest('emi01-v2')['dpt_sample_steps_s'][:2]:refs.append(e.study.dpt_compare(e.metrics.dpt(e.study.restore(p/lane,by[2]),dt),by[2]['metrics'],f'{lane}-output-{dt}'))
  workers=json.loads((p/(lane+'-workers.json')).read_text());resources=json.loads((p/(lane+'-resources.json')).read_text())
  assert e.audit_resources(resources,rows,workers,lane=='gpu');e.audit_worker_affinity(workers,lane=='gpu',16 if lane=='gpu' else 1)
 assert refs==summary['refinements'] and len(refs)==8 and all(x['pass'] for x in refs)
 assert not summary['acceptance_pass'];refinements.extend(refs)
p=out/'resident-full-counters84';profile=json.loads((p/'profile.json').read_text())
assert profile['exit_code']==0 and '41 passes' in (p/'ncu.log').read_text()
assert e.study.sha((p/'input.cir').read_bytes())==profile['input_sha256']
raw=gzip.decompress((p/'output.raw.gz').read_bytes());table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);raw_count+=1
cpu=gzip.decompress((out/'resident-prefetch90/cpu--1/output.raw.gz').read_bytes());ct=e.signals.parse_raw(cpu,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);grid=np.linspace(0,1.03*1e-6,2061)
profile_checks={n:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),np.interp(grid,ct[:,0],ct[:,i]),n.startswith('v('),400) for i,n in enumerate(e.circuits.STUDY_NAMES) if n!='time'}
assert all(x['pass'] for x in profile_checks.values());wave_count+=1
base_identity=json.loads((base/'identity.json').read_text());assert profile['source_identity']['sources']==base_identity['sources']
e.study.write_json(out/'audit.json',{'pass':True,'acceptance_pass':False,'source_variants':variants,'raw_trajectories':raw_count,'gpu_waveform_comparisons':wave_count,'dpt_refinements':len(refinements),'hardware_profile_waveforms':profile_checks,'scope':'Source, raw waveform, DPT metric/refinement, resource and identity reconstruction; all six candidates rejected; no full EMI-03 qualification'})
print('Audit passes:',raw_count,'trajectories,',wave_count,'GPU comparisons,',len(refinements),'DPT refinements;',len(variants),'source variants.',flush=True)
