from pathlib import Path
import gzip,hashlib,json,shutil
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-hardware-counters';out.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
for name in ['resident-full-counters84','resident-block-screen87','resident-amd88','pool-dpt-88','pool-dpt-89','resident-coupled20us89','resident-prefetch90']:
 source=w/name;target=out/name;target.mkdir();raws={}
 for p in source.rglob('*'):
  if not p.is_file():continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw' or p.name in ['source.csv','metrics.csv']:
   b=p.read_bytes();q=Path(str(q)+'.gz');q.write_bytes(gzip.compress(b,mtime=0))
   if p.suffix=='.raw':raws[str(q.relative_to(target))]={'raw_bytes':len(b),'raw_sha256':sha(b)}
  else:shutil.copy2(p,q)
 if raws:(target/'raw-files.json').write_text(json.dumps(raws,indent=2)+'\n')
 log=w/(name+'.log')
 if log.exists():shutil.copy2(log,target/'run.log')
for v in range(85,91):
 source=w/('block-'+str(v));target=out/('variant-'+str(v));target.mkdir()
 for name in ['identity.json','source.patch','tests.log']:
  shutil.copy2(source/name,target/name)
 # Correct the generic freezer's scope label in a separate explanatory record;
 # the original identity is preserved byte-for-byte.
 (target/'scope.json').write_text(json.dumps({'acceptance_pass':False,'scope':{85:'128-thread block',86:'64-thread block',87:'32-thread block',88:'AMD symbolic ordering',89:'AMD initially, COLAMD on numerical plan refresh',90:'Ordered triangular operand prefetch, width four'}[v]},indent=2)+'\n')
for name in ['profile_resident84.py','screen_blocks87.py','run_screen_blocks87.py','amd88.py','run_amd88.py','pool_dpt88.py','run_pool_dpt88.py','pool_dpt89.py','run_pool_dpt89.py','coupled20us89.py','run_coupled20us89.py','prefetch90.py','run_prefetch90.py','freeze_block_variant.py','retain_counters90.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
for name in ['resident-block128-85-build.log','resident-block64-86-build.log','resident-block32-87-build.log','resident-amd88-build.log','resident-ordering89-build.log','resident-prefetch90-build.log']:
 shutil.copy2(w/name,out/name)
shutil.copy2(w/'hardware-profile-70/input.cir',out/'resident-full-counters84/input.cir')
print(out)
