from reference.emi03 import ensemble as e
from pathlib import Path
import gzip,io,json,os,subprocess,tarfile,tempfile
r=Path('/home/adam/code/ohmnivore');out=r/'docs/evidence/emi03/diagnostics/resident-factor-dependencies';base=r/'docs/evidence/emi03/diagnostics/resident-owner-pool';np=e.metrics.np
checks=[]
for variant in ['static91','static92','warprow93']:
 p=out/variant;identity=json.loads((p/'identity.json').read_text())
 with tempfile.TemporaryDirectory(prefix='screening-audit-') as tmp:
  path=Path(tmp)
  with tarfile.open(fileobj=io.BytesIO(gzip.decompress((base/'sources.tar.gz').read_bytes()))) as tar:
   for member in tar:
    assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
    target=path/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
  patch=path/'candidate.patch';patch.write_bytes(gzip.decompress((p/'candidate.patch.gz').read_bytes()))
  subprocess.run(['git','apply','--check',str(patch)],cwd=path,check=True);subprocess.run(['git','apply',str(patch)],cwd=path,check=True)
  for name,h in identity['sources'].items():assert e.study.sha((path/name).read_bytes())==h,name
 grid=np.linspace(0,1.03*1e-6,2061);records=json.loads((p/'records.json').read_text())
 for row in records:
  folder=p/(row['lane']+'-'+str(row['trial'])+('-profile' if row['profile'] else ''))
  raw=gzip.decompress((folder/'output.raw.gz').read_bytes());assert e.study.sha(raw)==row['raw_sha256']
  table=e.signals.parse_raw(raw,e.circuits.STUDY_NAMES,1.03*1e-6,625e-12);assert len(table)==row['points']
  if row['lane']=='cpu':reference={name:np.interp(grid,table[:,0],table[:,i]) for i,name in enumerate(e.circuits.STUDY_NAMES)}
  else:
   compared={name:e.metrics._waveform_check(np.interp(grid,table[:,0],table[:,i]),reference[name],name.startswith('v('),400) for i,name in enumerate(e.circuits.STUDY_NAMES) if name!='time'}
   assert compared==row['waveforms'] and all(c['pass'] for c in compared.values())
   gpu=json.loads((folder/'stats.json.gpu.json').read_text());e.validate_gpu_telemetry(gpu,gpu['job_id'])
  checks.append(str(folder.relative_to(out)))
 summary=json.loads((p/'summary.json').read_text());assert not summary['acceptance_pass']
e.study.write_json(out/'audit.json',{'pass':True,'acceptance_pass':False,'source_variants':3,'raw_trajectories':len(checks),'gpu_waveform_checks':30,'checked':checks,'scope':'Exact trial-source and short raw/waveform reconstruction only; all three candidates rejected'})
print('Three source variants and all 33 trajectories reconstructed; 30 GPU waveform comparisons pass. All three performance trials rejected.')
