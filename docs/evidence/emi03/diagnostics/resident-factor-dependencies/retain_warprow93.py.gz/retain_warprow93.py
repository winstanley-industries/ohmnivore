from pathlib import Path
import gzip,shutil
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-factor-dependencies';target=out/'warprow93';target.mkdir(exist_ok=False)
for p in (w/'resident-warprow93').rglob('*'):
 if not p.is_file():continue
 q=target/p.relative_to(w/'resident-warprow93');q.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.raw':q.with_suffix('.raw.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 else:shutil.copy2(p,q)
for name in ['identity.json','source.patch','tests.log']:shutil.copy2(w/'block-93'/name,target/('frozen-'+name))
for suffix in ['-build.log','.log']:shutil.copy2(w/('resident-warprow93'+suffix),target/('build.log' if suffix=='-build.log' else 'run.log'))
for name in ['warprow93.py','run_warprow93.py','retain_warprow93.py']:(out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
