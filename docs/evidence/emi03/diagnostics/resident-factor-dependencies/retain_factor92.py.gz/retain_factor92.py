from pathlib import Path
import gzip,hashlib,json,shutil
r=Path('/home/adam/code/ohmnivore');w=Path('/home/adam/emi03-work');out=r/'docs/evidence/emi03/diagnostics/resident-factor-dependencies';out.mkdir(exist_ok=False)
for v in [91,92]:
 source=w/('resident-static'+str(v));target=out/('static'+str(v));target.mkdir()
 for p in source.rglob('*'):
  if not p.is_file():continue
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.raw':q.with_suffix('.raw.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copy2(p,q)
 for name in ['identity.json','source.patch','tests.log']:shutil.copy2(w/('block-'+str(v))/name,target/('frozen-'+name))
 for suffix in ['-build.log','.log']:shutil.copy2(w/('resident-static'+str(v)+suffix),target/('build.log' if suffix=='-build.log' else 'run.log'))
for name in ['static91.py','run_static91.py','static92.py','run_static92.py','freeze_factor_variant.py','retain_factor92.py']:(out/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
print(out)
